# ASTRO Edition — alterações principais

Esta edição mantém mensagens tradicionais do Discord: embed clássico, selects e botões comuns. Não utiliza Components V2 no carrinho, no PIX ou no `/apps`.

## Fluxo de compra

- O select público responde imediatamente, evitando “o aplicativo não respondeu”.
- O carrinho privado usa o layout da referência com valores em `inline code`.
- Períodos: 1 dia por R$ 1,00; 7 dias por R$ 3,99; 15 dias por R$ 5,99; 30 dias por R$ 8,99; 365 dias por R$ 79,99.
- Adicionais: Suporte Prioritário, Remover Anúncio e QRCode Personalizável, todos por R$ 4,00.
- O PIX mantém somente “Copiar Código QR” e “Cancelar”.

## `/apps`

- Painel clássico com nome, vencimento, estado, ID, plano e licença.
- Botões Iniciar, Reiniciar e Parar.
- Select com renovação, nome, BIO, token criptografado, pessoa de confiança, equipe, servidores, transferência, licença e exclusão.
- Tokens nunca são mostrados novamente nem registrados em logs.

## Bot de Vendas

Copie `integration-examples/sales-bot-manager-client.ts` para o Bot de Vendas. Após o pagamento aprovado, chame `releaseApprovedPurchase`. A operação é idempotente e libera aplicação e licença automaticamente.
