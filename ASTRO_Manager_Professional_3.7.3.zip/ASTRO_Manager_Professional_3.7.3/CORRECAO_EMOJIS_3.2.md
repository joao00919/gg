# Correção 3.2 — Invalid emoji

O erro `COMPONENT_INVALID_EMOJI` ocorria porque os valores colados no `.env` usavam um número no campo de nome do emoji, por exemplo:

```env
CUSTOM_EMOJI_CART=<:1243275863827546224:1527389252315385876>
```

O Discord aceita o ID como identidade do emoji, mas rejeitou o nome enviado dentro de select menus e botões.

## Correções

- emojis personalizados em componentes agora são enviados somente pelo ID;
- emojis do carrinho, carregamento e confirmação são normalizados para nomes válidos;
- componentes críticos do carrinho usam emojis Unicode seguros (`$`, `🔧`, `➜`, `📋`);
- o emoji personalizado do carrinho continua aparecendo no título do embed;
- valores padrão:

```env
CUSTOM_EMOJI_LOADING=<a:astro_loading:1527386782776164392>
CUSTOM_EMOJI_CART=<:astro_cart:1527389252315385876>
CUSTOM_EMOJI_CART_OPENED=<:astro_cart_opened:1527388353044156546>
```

Assim, um emoji inacessível ou com nome incorreto não impede o painel do carrinho de ser enviado.
