# Análise das referências visuais e do vídeo

As imagens e o vídeo enviados foram usados para reconstruir o fluxo. Os arquivos originais não são redistribuídos neste projeto.

## Elementos observados

### Central de Comandos

- mensagem pública com título, explicação e lista dos comandos;
- banner abaixo do texto;
- botão link para dashboard;
- comandos com opção `app` e autocomplete.

### Central de Compras

- apresentação dos produtos;
- banner;
- select “Escolha o bot que deseja adquirir”;
- botão link de preview;
- produtos agrupados por finalidade.

### Abertura do carrinho

- resposta ephemeral “Iniciando verificações necessárias...”;
- criação de tópico privado;
- resposta final com “Carrinho aberto com sucesso!”;
- somente botão link “Ir para carrinho”.

### Carrinho

- produto, plano e valor total no cabeçalho;
- seleção de período;
- seleção múltipla de adicionais;
- atualização do total;
- botões “Finalizar Compra” e “Cancelar Compra”.

### PIX

- edição da mensagem para processamento;
- título e instruções de pagamento;
- QR Code grande, branco e preto;
- somente “Copiar Código QR” e “Cancelar”;
- identificação automática do pagamento.

### Gerenciamento

- `/apps app:<autocomplete>`;
- nome da aplicação e vencimento;
- estado online/offline;
- ID da aplicação, plano e link;
- start, restart e stop;
- select de configurações, equipe, servidores e transferência;
- compra de adicionais;
- renovação rápida e personalizada.

## Decisões de implementação

- as telas principais usam mensagens tradicionais do Discord, com embeds, selects, botões e attachments, conforme as capturas;
- marca, banners, links e emojis vêm do `.env`;
- textos foram recriados, não copiados como ativos proprietários;
- o fluxo foi preservado, mas a identidade “Vision Applications” é independente;
- o botão de verificação manual não existe.
