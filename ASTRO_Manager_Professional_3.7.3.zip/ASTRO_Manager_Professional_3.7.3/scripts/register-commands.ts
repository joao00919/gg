import { REST, Routes } from 'discord.js';
import { getEnv } from '../src/config/env.js';
import { commandPayloads } from '../src/bot/commands/definitions.js';

const mode = process.argv[2];
if (mode !== 'dev' && mode !== 'global') throw new Error('Use dev ou global.');
const env = getEnv();
const rest = new REST({ version: '10' }).setToken(env.MANAGER_BOT_TOKEN);
const route =
  mode === 'dev'
    ? Routes.applicationGuildCommands(env.MANAGER_CLIENT_ID, env.MANAGER_GUILD_ID)
    : Routes.applicationCommands(env.MANAGER_CLIENT_ID);
await rest.put(route, { body: commandPayloads });
process.stdout.write(
  `Comandos ${mode === 'dev' ? 'do servidor' : 'globais'} registrados: ${commandPayloads.length}.\n`,
);
