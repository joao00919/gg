import { createHmac } from 'node:crypto';
import { getEnv } from '../src/config/env.js';

const env = getEnv();
const timestamp = String(Date.now());
const body = '';
const secret = env.SALES_BOT_API_KEY.length > 0 ? env.SALES_BOT_API_KEY : env.INTERNAL_API_KEY;
const signature = createHmac('sha256', secret)
  .update(`${timestamp}.${body}`)
  .digest('base64url');
const host = env.API_HOST === '0.0.0.0' ? '127.0.0.1' : env.API_HOST;
const baseUrl = env.MANAGER_PUBLIC_API_URL.trim() || `http://${host}:${env.API_PORT}`;
const response = await fetch(`${baseUrl}/internal/v1/integration/status`, {
  headers: {
    'x-api-key': env.INTERNAL_API_KEY,
    'x-timestamp': timestamp,
    'x-signature': signature,
  },
});
const text = await response.text();
if (!response.ok) {
  throw new Error(`Integração indisponível (${response.status}): ${text}`);
}
console.log(text);
