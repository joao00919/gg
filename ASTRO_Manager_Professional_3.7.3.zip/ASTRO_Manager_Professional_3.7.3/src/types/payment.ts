export type TerminalPaymentStatus = 'APPROVED' | 'CANCELLED' | 'EXPIRED' | 'REJECTED' | 'REFUNDED';
export type ProviderPaymentStatus = 'CREATED' | 'PENDING' | TerminalPaymentStatus | 'ERROR';

export interface CreatePixPaymentInput {
  amountInCents: number;
  currency: string;
  idempotencyKey: string;
  expiresAt: Date;
  webhookUrl?: string;
  description: string;
}

export interface PixPayment {
  externalPaymentId: string;
  status: ProviderPaymentStatus;
  amountInCents: number;
  currency: string;
  qrCodeText: string;
  qrCodeImage: Buffer;
  createdAt: Date;
  expiresAt: Date;
  providerPayloadSafe: Record<string, unknown>;
}

export interface PaymentStatusResult {
  externalPaymentId: string;
  status: ProviderPaymentStatus;
  amountInCents: number;
  currency: string;
  approvedAt?: Date;
  providerPayloadSafe: Record<string, unknown>;
}

export interface CancelPaymentResult {
  externalPaymentId: string;
  status: ProviderPaymentStatus;
  supported: boolean;
}

export interface WebhookValidationInput {
  rawBody: Buffer;
  headers: Record<string, string | string[] | undefined>;
  payload: unknown;
}

export interface ValidatedWebhook {
  externalEventId: string;
  externalPaymentId: string;
  valid: boolean;
}

export interface PaymentProvider {
  readonly name: string;
  createPixPayment(input: CreatePixPaymentInput): Promise<PixPayment>;
  getPayment(externalPaymentId: string): Promise<PaymentStatusResult>;
  cancelPayment(externalPaymentId: string): Promise<CancelPaymentResult>;
  validateWebhook(input: WebhookValidationInput): Promise<ValidatedWebhook>;
}
