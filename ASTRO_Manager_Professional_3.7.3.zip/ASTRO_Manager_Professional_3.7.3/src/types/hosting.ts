export type HostingState = 'ONLINE' | 'OFFLINE' | 'SUSPENDED' | 'ERROR' | 'UNKNOWN';

export interface HostingStatus {
  state: HostingState;
  version?: string;
  updatedAt: Date;
}

export interface RestartResult {
  accepted: boolean;
  state: HostingState;
  message: string;
}

export interface HostingProvider {
  readonly name: string;
  getStatus(applicationId: string): Promise<HostingStatus>;
  restartApplication(applicationId: string): Promise<RestartResult>;
  suspendApplication(applicationId: string): Promise<void>;
  activateApplication(applicationId: string): Promise<void>;
  getLogs(applicationId: string, limit: number): Promise<string[]>;
}
