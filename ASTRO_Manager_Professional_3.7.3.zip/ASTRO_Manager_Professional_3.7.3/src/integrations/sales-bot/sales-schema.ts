import { z } from 'zod';

const discordId = z.string().regex(/^\d{17,20}$/);

const flatPurchaseSchema = z
  .object({
    idempotencyKey: z.string().min(8).max(200),
    buyerDiscordId: discordId,
    buyerUsername: z.string().min(1).max(100).optional(),
    applicationName: z.string().min(1).max(100),
    discordApplicationId: discordId.optional(),
    linkedGuildId: discordId.optional(),
    planId: z.string().uuid().optional(),
    planSlug: z.string().min(1).max(100).optional(),
    periodDays: z.number().int().positive().max(3650),
    paymentExternalId: z.string().min(1).max(255),
    amountInCents: z.number().int().min(50),
    currency: z.string().length(3).default('BRL'),
    paymentProvider: z.string().min(1).max(50).default('sales-bot'),
    autoActivate: z.boolean().default(true),
    hostingExternalId: z.string().max(255).optional(),
    version: z.string().max(100).optional(),
  })
  .refine((input) => Boolean(input.planId ?? input.planSlug), {
    message: 'Informe planId ou planSlug.',
    path: ['planSlug'],
  });

const nestedPurchaseSchema = z.object({
  idempotencyKey: z.string().min(8).max(200),
  buyer: z.object({
    discordId,
    username: z.string().min(1).max(100).optional(),
  }),
  product: z.object({ name: z.string().min(1).max(100) }),
  plan: z.object({
    id: z.string().uuid().optional(),
    slug: z.string().min(1).max(100).optional(),
  }),
  periodDays: z.number().int().positive().max(3650),
  amountInCents: z.number().int().min(50),
  currency: z.string().length(3).default('BRL'),
  payment: z.object({
    externalId: z.string().min(1).max(255),
    status: z.literal('APPROVED'),
    provider: z.string().min(1).max(50),
  }),
  initialConfig: z
    .object({
      discordApplicationId: discordId.optional(),
      guildId: discordId.optional(),
      hostingExternalId: z.string().max(255).optional(),
      version: z.string().max(100).optional(),
      autoActivate: z.boolean().default(true),
    })
    .optional(),
});

export const salesPurchaseSchema = z.union([flatPurchaseSchema, nestedPurchaseSchema]).transform((input) => {
  if ('buyerDiscordId' in input) return input;
  return {
    idempotencyKey: input.idempotencyKey,
    buyerDiscordId: input.buyer.discordId,
    buyerUsername: input.buyer.username,
    applicationName: input.product.name,
    discordApplicationId: input.initialConfig?.discordApplicationId,
    linkedGuildId: input.initialConfig?.guildId,
    planId: input.plan.id,
    planSlug: input.plan.slug,
    periodDays: input.periodDays,
    paymentExternalId: input.payment.externalId,
    amountInCents: input.amountInCents,
    currency: input.currency,
    paymentProvider: input.payment.provider,
    autoActivate: input.initialConfig?.autoActivate ?? true,
    hostingExternalId: input.initialConfig?.hostingExternalId,
    version: input.initialConfig?.version,
  };
});

export type SalesPurchaseInput = z.infer<typeof salesPurchaseSchema>;
