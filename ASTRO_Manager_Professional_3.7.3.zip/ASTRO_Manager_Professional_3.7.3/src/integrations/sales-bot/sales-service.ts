import { Prisma, type PrismaClient } from '@prisma/client';
import type { AuditService } from '../../services/audit/audit-service.js';
import { generateLicenseKey } from '../../services/licenses/license-service.js';
import type { NotificationService } from '../../services/notifications/notification-service.js';
import { addDays } from '../../utils/time.js';
import { DomainError } from '../../utils/errors.js';

import type { SalesPurchaseInput } from './sales-schema.js';

export class SalesIntegrationService {
  public constructor(
    private readonly prisma: PrismaClient,
    private readonly audit: AuditService,
    private readonly notifications?: NotificationService,
  ) {}

  public async provision(input: SalesPurchaseInput) {
    const existing = await this.prisma.payment.findUnique({
      where: { idempotencyKey: input.idempotencyKey },
      include: { application: { include: { license: true } } },
    });
    if (existing?.applicationId && existing.application) {
      return {
        applicationId: existing.applicationId,
        paymentId: existing.id,
        licenseId: existing.application.license?.id,
        status: existing.application.status,
        licenseStatus: existing.application.license?.status,
        expiresAt: existing.application.license?.expiresAt,
        idempotent: true,
      };
    }

    const result = await this.prisma.$transaction(
      async (tx) => {
        const plan = input.planId
          ? await tx.plan.findUniqueOrThrow({ where: { id: input.planId } })
          : input.planSlug
            ? await tx.plan.findUniqueOrThrow({ where: { slug: input.planSlug } })
            : (() => {
                throw new DomainError('Informe planId ou planSlug.', 'PLAN_REFERENCE_REQUIRED');
              })();
        const user = await tx.user.upsert({
          where: { discordId: input.buyerDiscordId },
          update: { username: input.buyerUsername },
          create: { discordId: input.buyerDiscordId, username: input.buyerUsername },
        });
        const approvedAt = new Date();
        const expiresAt = addDays(approvedAt, input.periodDays);
        const generated = generateLicenseKey();
        const application = await tx.application.create({
          data: {
            ownerId: user.id,
            planId: plan.id,
            name: input.applicationName,
            discordApplicationId: input.discordApplicationId,
            linkedGuildId: input.linkedGuildId,
            status: input.autoActivate ? 'ONLINE' : 'PENDING_SETUP',
            hostingExternalId: input.hostingExternalId,
            version: input.version,
          },
        });
        const license = await tx.license.create({
          data: {
            applicationId: application.id,
            planId: plan.id,
            keyPrefix: generated.prefix,
            keyHash: generated.hash,
            status: 'ACTIVE',
            activatedAt: approvedAt,
            expiresAt,
            serverLimit: plan.serverLimit,
          },
        });
        if (input.linkedGuildId) {
          await tx.applicationInstance.create({
            data: { applicationId: application.id, guildId: input.linkedGuildId, active: true },
          });
        }
        await tx.subscription.create({
          data: {
            applicationId: application.id,
            planId: plan.id,
            active: true,
            startedAt: approvedAt,
            endsAt: expiresAt,
          },
        });
        const cart = await tx.cart.create({
          data: {
            userId: user.id,
            applicationId: application.id,
            planId: plan.id,
            kind: 'NEW_APPLICATION',
            periodDays: input.periodDays,
            baseAmountInCents: input.amountInCents,
            amountInCents: input.amountInCents,
            status: 'COMPLETED',
            guildId: input.linkedGuildId ?? '0',
            expiresAt: approvedAt,
          },
        });
        const payment = await tx.payment.create({
          data: {
            externalPaymentId: input.paymentExternalId,
            userId: user.id,
            applicationId: application.id,
            cartId: cart.id,
            amountInCents: input.amountInCents,
            currency: input.currency.toUpperCase(),
            status: 'APPROVED',
            provider: input.paymentProvider,
            idempotencyKey: input.idempotencyKey,
            expiresAt: approvedAt,
            approvedAt,
          },
        });
        await tx.paymentEvent.create({
          data: {
            paymentId: payment.id,
            type: 'SALES_BOT_APPROVED',
            payloadSafe: {
              source: 'sales-bot',
              planSlug: plan.slug,
              autoActivate: input.autoActivate,
            } as Prisma.InputJsonValue,
          },
        });
        await tx.auditLog.create({
          data: {
            actorType: 'SALES_BOT',
            action: 'SALES_PURCHASE_PROVISION',
            entityType: 'Application',
            entityId: application.id,
            metadataSafe: { paymentId: payment.id, planSlug: plan.slug },
          },
        });
        return { application, license, payment };
      },
      { isolationLevel: Prisma.TransactionIsolationLevel.Serializable },
    );

    await this.audit.record({
      actorType: 'SALES_BOT',
      action: 'SALES_PURCHASE_COMPLETED',
      entityType: 'Application',
      entityId: result.application.id,
      metadataSafe: { paymentId: result.payment.id },
    });
    if (this.notifications) {
      await this.notifications
        .sendDiscord(
          input.buyerDiscordId,
          'APPLICATION_RELEASED',
          `✓ Sua compra foi aprovada e a aplicação **${result.application.name}** já foi liberada. Use \`/apps\` para gerenciar.`,
        )
        .catch(() => undefined);
    }

    return {
      applicationId: result.application.id,
      paymentId: result.payment.id,
      licenseId: result.license.id,
      status: result.application.status,
      licenseStatus: result.license.status,
      expiresAt: result.license.expiresAt,
      idempotent: false,
    };
  }
}
