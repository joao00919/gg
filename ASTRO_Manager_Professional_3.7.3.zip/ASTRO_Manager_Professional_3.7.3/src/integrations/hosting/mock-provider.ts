import type { HostingProvider, HostingStatus, RestartResult } from '../../types/hosting.js';

export class MockHostingProvider implements HostingProvider {
  public readonly name = 'mock';
  private readonly states = new Map<string, HostingStatus>();

  public async getStatus(applicationId: string): Promise<HostingStatus> {
    return this.states.get(applicationId) ?? { state: 'OFFLINE', updatedAt: new Date() };
  }

  public async restartApplication(applicationId: string): Promise<RestartResult> {
    const status: HostingStatus = { state: 'ONLINE', version: 'mock-1.0.0', updatedAt: new Date() };
    this.states.set(applicationId, status);
    return { accepted: true, state: status.state, message: 'Reinicialização concluída.' };
  }

  public async suspendApplication(applicationId: string): Promise<void> {
    this.states.set(applicationId, { state: 'SUSPENDED', updatedAt: new Date() });
  }

  public async activateApplication(applicationId: string): Promise<void> {
    this.states.set(applicationId, { state: 'ONLINE', updatedAt: new Date() });
  }

  public async getLogs(applicationId: string, limit: number): Promise<string[]> {
    return [`[${new Date().toISOString()}] Aplicação ${applicationId} usando provedor mock.`].slice(
      0,
      limit,
    );
  }
}
