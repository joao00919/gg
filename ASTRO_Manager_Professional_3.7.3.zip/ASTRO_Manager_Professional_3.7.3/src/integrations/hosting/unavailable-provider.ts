import type { HostingProvider, HostingStatus, RestartResult } from '../../types/hosting.js';
import { DomainError } from '../../utils/errors.js';

export class UnavailableHostingProvider implements HostingProvider {
  public constructor(public readonly name: string) {}

  private fail(): never {
    throw new DomainError(
      `O provedor de hospedagem ${this.name} ainda não foi configurado.`,
      'HOSTING_CONFIG',
    );
  }

  public async getStatus(_applicationId: string): Promise<HostingStatus> {
    return this.fail();
  }

  public async restartApplication(_applicationId: string): Promise<RestartResult> {
    return this.fail();
  }

  public async suspendApplication(_applicationId: string): Promise<void> {
    return this.fail();
  }

  public async activateApplication(_applicationId: string): Promise<void> {
    return this.fail();
  }

  public async getLogs(_applicationId: string, _limit: number): Promise<string[]> {
    return this.fail();
  }
}
