import { createHmac } from 'node:crypto';
import type { Env } from '../../config/env.js';
import type { HostingProvider, HostingStatus, RestartResult } from '../../types/hosting.js';
import { DomainError } from '../../utils/errors.js';

interface SalesApiResponse {
  state?: HostingStatus['state'];
  version?: string;
  updatedAt?: string;
  accepted?: boolean;
  message?: string;
  logs?: string[];
}

export class SalesBotHostingProvider implements HostingProvider {
  public readonly name = 'sales-api';
  private readonly baseUrl: string;

  public constructor(private readonly env: Env) {
    this.baseUrl = env.SALES_BOT_API_URL.replace(/\/$/, '');
    if (!this.baseUrl || !env.SALES_BOT_API_KEY) {
      throw new DomainError(
        'Configure SALES_BOT_API_URL e SALES_BOT_API_KEY para controlar o bot hospedado na Shard.',
        'SALES_API_CONFIG',
      );
    }
  }

  private async request(path: string, init: RequestInit = {}): Promise<SalesApiResponse> {
    const method = (init.method ?? 'GET').toUpperCase();
    const body = typeof init.body === 'string' ? init.body : '';
    const timestamp = String(Date.now());
    const signature = createHmac('sha256', this.env.SALES_BOT_API_KEY)
      .update(`${timestamp}.${method}.${path}.${body}`)
      .digest('base64url');

    const response = await fetch(`${this.baseUrl}${path}`, {
      ...init,
      headers: {
        'content-type': 'application/json',
        'x-api-key': this.env.SALES_BOT_API_KEY,
        'x-timestamp': timestamp,
        'x-signature': signature,
        ...(init.headers ?? {}),
      },
      signal: AbortSignal.timeout(10_000),
    });

    const text = await response.text();
    let data: SalesApiResponse = {};
    if (text) {
      try {
        data = JSON.parse(text) as SalesApiResponse;
      } catch {
        throw new DomainError('A API privada da Shard retornou uma resposta inválida.', 'SALES_API_INVALID');
      }
    }
    if (!response.ok) {
      throw new DomainError(
        data.message ?? `A API privada da Shard recusou a operação (${response.status}).`,
        'SALES_API_ERROR',
        response.status,
      );
    }
    return data;
  }

  public async getStatus(applicationId: string): Promise<HostingStatus> {
    const data = await this.request(`/internal/v1/applications/${encodeURIComponent(applicationId)}/status`);
    return {
      state: data.state ?? 'UNKNOWN',
      version: data.version,
      updatedAt: data.updatedAt ? new Date(data.updatedAt) : new Date(),
    };
  }

  public async restartApplication(applicationId: string): Promise<RestartResult> {
    const data = await this.request(
      `/internal/v1/applications/${encodeURIComponent(applicationId)}/restart`,
      { method: 'POST', body: '{}' },
    );
    return {
      accepted: data.accepted ?? true,
      state: data.state ?? 'ONLINE',
      message: data.message ?? 'Reinicialização enviada para a Shard.',
    };
  }

  public async suspendApplication(applicationId: string): Promise<void> {
    await this.request(`/internal/v1/applications/${encodeURIComponent(applicationId)}/suspend`, {
      method: 'POST',
      body: '{}',
    });
  }

  public async activateApplication(applicationId: string): Promise<void> {
    await this.request(`/internal/v1/applications/${encodeURIComponent(applicationId)}/activate`, {
      method: 'POST',
      body: '{}',
    });
  }

  public async getLogs(applicationId: string, limit: number): Promise<string[]> {
    const safeLimit = Math.max(1, Math.min(200, Math.trunc(limit)));
    const data = await this.request(
      `/internal/v1/applications/${encodeURIComponent(applicationId)}/logs?limit=${safeLimit}`,
    );
    return Array.isArray(data.logs) ? data.logs : [];
  }
}
