import type { Env } from '../../config/env.js';
import type { HostingProvider } from '../../types/hosting.js';
import { MockHostingProvider } from './mock-provider.js';
import { SalesBotHostingProvider } from './sales-api-provider.js';
import { UnavailableHostingProvider } from './unavailable-provider.js';

export function createHostingProvider(env: Env): HostingProvider {
  if (env.HOSTING_PROVIDER === 'mock') return new MockHostingProvider();
  if (env.HOSTING_PROVIDER === 'sales-api') return new SalesBotHostingProvider(env);
  return new UnavailableHostingProvider(env.HOSTING_PROVIDER);
}
