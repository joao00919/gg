import type {
  CancelPaymentResult,
  CreatePixPaymentInput,
  PaymentProvider,
  PaymentStatusResult,
  PixPayment,
  ValidatedWebhook,
  WebhookValidationInput,
} from '../../types/payment.js';
import { DomainError } from '../../utils/errors.js';

export class ManualPixProvider implements PaymentProvider {
  public readonly name = 'manual';

  public async createPixPayment(_input: CreatePixPaymentInput): Promise<PixPayment> {
    throw new DomainError(
      'O PIX manual precisa ser criado por um administrador.',
      'MANUAL_PAYMENT_REQUIRED',
    );
  }

  public async getPayment(_externalPaymentId: string): Promise<PaymentStatusResult> {
    throw new DomainError(
      'Pagamentos manuais não possuem consulta automática.',
      'MANUAL_PAYMENT_REQUIRED',
    );
  }

  public async cancelPayment(externalPaymentId: string): Promise<CancelPaymentResult> {
    return { externalPaymentId, status: 'CANCELLED', supported: true };
  }

  public async validateWebhook(_input: WebhookValidationInput): Promise<ValidatedWebhook> {
    return { externalEventId: '', externalPaymentId: '', valid: false };
  }
}
