import QRCode from 'qrcode';
import { z } from 'zod';
import type {
  CancelPaymentResult,
  CreatePixPaymentInput,
  PaymentProvider,
  PaymentStatusResult,
  PixPayment,
  ValidatedWebhook,
  WebhookValidationInput,
} from '../../types/payment.js';
import { DomainError } from '../../utils/errors.js';
import { sha256 } from '../../utils/crypto.js';
import { normalizePaymentStatus } from './status.js';

const createSchema = z.object({
  id: z.string().min(1),
  status: z.unknown(),
  amount: z.coerce.number().int().positive(),
  copyPaste: z.string().min(1),
  qrCodeBase64: z.string().optional(),
  expiresAt: z.coerce.date(),
  fee: z.coerce.number().optional(),
  storeId: z.string().optional(),
});

const statusSchema = z.object({
  id: z.string().min(1),
  status: z.unknown(),
  amount: z.coerce.number().int().positive(),
  createdAt: z.coerce.date().optional(),
  fee: z.coerce.number().optional(),
  storeId: z.string().optional(),
});

export interface PromisseProviderOptions {
  apiUrl: string;
  accessToken: string;
  webhookSecret: string;
}

export class PromissePaymentProvider implements PaymentProvider {
  public readonly name = 'promisse';

  public constructor(private readonly options: PromisseProviderOptions) {}

  public async createPixPayment(input: CreatePixPaymentInput): Promise<PixPayment> {
    if (!this.options.accessToken)
      throw new DomainError('PAYMENT_ACCESS_TOKEN não foi configurado.', 'PAYMENT_CONFIG');
    const body: Record<string, unknown> = { amount: input.amountInCents };
    if (input.webhookUrl) body.webhook = input.webhookUrl;

    const response = await fetch(`${this.options.apiUrl}/transactions`, {
      method: 'POST',
      headers: {
        Authorization: this.options.accessToken,
        'Content-Type': 'application/json',
        'Idempotency-Key': input.idempotencyKey,
      },
      body: JSON.stringify(body),
      signal: AbortSignal.timeout(15_000),
    });
    if (!response.ok) {
      throw new DomainError(
        'Não foi possível gerar o pagamento neste momento.',
        'PAYMENT_PROVIDER_ERROR',
        502,
      );
    }

    const parsed = createSchema.parse(await response.json());
    const qrCodeImage = parsed.qrCodeBase64
      ? decodeBase64Png(parsed.qrCodeBase64)
      : await QRCode.toBuffer(parsed.copyPaste, {
          type: 'png',
          width: 900,
          margin: 4,
          errorCorrectionLevel: 'M',
        });

    return {
      externalPaymentId: parsed.id,
      status: normalizePaymentStatus(parsed.status),
      amountInCents: parsed.amount,
      currency: input.currency,
      qrCodeText: parsed.copyPaste,
      qrCodeImage,
      createdAt: new Date(),
      expiresAt: parsed.expiresAt,
      providerPayloadSafe: { fee: parsed.fee, storeId: parsed.storeId },
    };
  }

  public async getPayment(externalPaymentId: string): Promise<PaymentStatusResult> {
    const response = await fetch(
      `${this.options.apiUrl}/transactions/${encodeURIComponent(externalPaymentId)}`,
      {
        headers: { Authorization: this.options.accessToken },
        signal: AbortSignal.timeout(15_000),
      },
    );
    if (!response.ok)
      throw new DomainError(
        'O provedor de pagamento está indisponível.',
        'PAYMENT_PROVIDER_ERROR',
        502,
      );
    const parsed = statusSchema.parse(await response.json());
    return {
      externalPaymentId: parsed.id,
      status: normalizePaymentStatus(parsed.status),
      amountInCents: parsed.amount,
      currency: 'BRL',
      providerPayloadSafe: { fee: parsed.fee, storeId: parsed.storeId },
    };
  }

  public async cancelPayment(externalPaymentId: string): Promise<CancelPaymentResult> {
    return { externalPaymentId, status: 'CANCELLED', supported: false };
  }

  public async validateWebhook(input: WebhookValidationInput): Promise<ValidatedWebhook> {
    const payload = input.payload as Record<string, unknown> | null;
    const externalPaymentId = extractPaymentId(payload);
    const eventHeader = input.headers['x-webhook-event-id'];
    const eventValue = Array.isArray(eventHeader) ? eventHeader[0] : eventHeader;
    const routeSecret = input.headers['x-vision-webhook-secret'];
    const routeValue = Array.isArray(routeSecret) ? routeSecret[0] : routeSecret;
    const secretValid = !this.options.webhookSecret || routeValue === this.options.webhookSecret;
    return {
      externalEventId: eventValue?.length ? eventValue : sha256(input.rawBody),
      externalPaymentId,
      valid: Boolean(externalPaymentId) && secretValid,
    };
  }
}

function decodeBase64Png(value: string): Buffer {
  const payload = value.includes(',') ? value.split(',')[1] : value;
  if (!payload)
    throw new DomainError('O provedor retornou um QR Code inválido.', 'INVALID_QR', 502);
  return Buffer.from(payload, 'base64');
}

function extractPaymentId(payload: Record<string, unknown> | null): string {
  if (!payload) return '';
  const candidates = [payload.id, payload.transactionId, payload.paymentId];
  const data = payload.data;
  if (data && typeof data === 'object') {
    const nested = data as Record<string, unknown>;
    candidates.push(nested.id, nested.transactionId, nested.paymentId);
  }
  return (
    candidates.find(
      (candidate): candidate is string => typeof candidate === 'string' && candidate.length > 0,
    ) ?? ''
  );
}
