import type { ProviderPaymentStatus } from '../../types/payment.js';

export function normalizePaymentStatus(value: unknown): ProviderPaymentStatus {
  const raw =
    typeof value === 'string' || typeof value === 'number' || typeof value === 'boolean'
      ? String(value)
      : '';
  const status = raw.trim().toUpperCase();
  if (['PAID', 'APPROVED', 'COMPLETED', 'SUCCESS'].includes(status)) return 'APPROVED';
  if (['PENDING', 'CREATED', 'WAITING_PAYMENT', 'PROCESSING'].includes(status)) return 'PENDING';
  if (['CANCELLED', 'CANCELED'].includes(status)) return 'CANCELLED';
  if (status === 'EXPIRED') return 'EXPIRED';
  if (['REJECTED', 'FAILED'].includes(status)) return 'REJECTED';
  if (['REFUNDED', 'CHARGED_BACK'].includes(status)) return 'REFUNDED';
  return 'ERROR';
}
