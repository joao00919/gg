import type { Env } from '../../config/env.js';
import type { PaymentProvider } from '../../types/payment.js';
import { ManualPixProvider } from './manual-provider.js';
import { MockPaymentProvider } from './mock-provider.js';
import { PromissePaymentProvider } from './promisse-provider.js';

export function createPaymentProvider(env: Env): PaymentProvider {
  if (env.PAYMENT_PROVIDER === 'mock') return new MockPaymentProvider();
  if (env.PAYMENT_PROVIDER === 'manual') return new ManualPixProvider();
  return new PromissePaymentProvider({
    apiUrl: env.PAYMENT_API_URL,
    accessToken: env.PAYMENT_ACCESS_TOKEN,
    webhookSecret: env.PAYMENT_WEBHOOK_SECRET,
  });
}
