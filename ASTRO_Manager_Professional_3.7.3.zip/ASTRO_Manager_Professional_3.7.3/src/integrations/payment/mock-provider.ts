import QRCode from 'qrcode';
import type {
  CancelPaymentResult,
  CreatePixPaymentInput,
  PaymentProvider,
  PaymentStatusResult,
  PixPayment,
  ProviderPaymentStatus,
  ValidatedWebhook,
  WebhookValidationInput,
} from '../../types/payment.js';
import { randomToken, sha256 } from '../../utils/crypto.js';

export class MockPaymentProvider implements PaymentProvider {
  public readonly name = 'mock';
  private readonly payments = new Map<string, PaymentStatusResult>();

  public async createPixPayment(input: CreatePixPaymentInput): Promise<PixPayment> {
    const externalPaymentId = `mock_${randomToken(10)}`;
    const qrCodeText = `000201MOCKPIX${externalPaymentId}${input.amountInCents}`;
    const qrCodeImage = await QRCode.toBuffer(qrCodeText, { width: 900, margin: 4 });
    this.payments.set(externalPaymentId, {
      externalPaymentId,
      status: 'PENDING',
      amountInCents: input.amountInCents,
      currency: input.currency,
      providerPayloadSafe: { mode: 'mock' },
    });
    return {
      externalPaymentId,
      status: 'PENDING',
      amountInCents: input.amountInCents,
      currency: input.currency,
      qrCodeText,
      qrCodeImage,
      createdAt: new Date(),
      expiresAt: input.expiresAt,
      providerPayloadSafe: { mode: 'mock' },
    };
  }

  public async getPayment(externalPaymentId: string): Promise<PaymentStatusResult> {
    const payment = this.payments.get(externalPaymentId);
    if (!payment) throw new Error('Pagamento mock inexistente.');
    return payment;
  }

  public async cancelPayment(externalPaymentId: string): Promise<CancelPaymentResult> {
    this.setStatus(externalPaymentId, 'CANCELLED');
    return { externalPaymentId, status: 'CANCELLED', supported: true };
  }

  public async validateWebhook(input: WebhookValidationInput): Promise<ValidatedWebhook> {
    const payload = input.payload as Record<string, unknown>;
    const externalPaymentId =
      typeof payload.externalPaymentId === 'string' ? payload.externalPaymentId : '';
    return {
      externalEventId: sha256(input.rawBody),
      externalPaymentId,
      valid: Boolean(externalPaymentId),
    };
  }

  public setStatus(externalPaymentId: string, status: ProviderPaymentStatus): void {
    const payment = this.payments.get(externalPaymentId);
    if (!payment) throw new Error('Pagamento mock inexistente.');
    this.payments.set(externalPaymentId, {
      ...payment,
      status,
      approvedAt: status === 'APPROVED' ? new Date() : undefined,
    });
  }
}
