import type { PrismaClient } from '@prisma/client';
import type { Env } from '../config/env.js';
import type { Logger } from '../config/logger.js';
import type { NotificationService } from '../services/notifications/notification-service.js';
import { calculateRenewalExpiry } from '../utils/time.js';
import { formatMoney } from '../utils/money.js';

export class WalletAutoRenewJob {
  private timer?: NodeJS.Timeout;
  private running = false;

  public constructor(
    private readonly prisma: PrismaClient,
    private readonly notifications: NotificationService,
    private readonly env: Env,
    private readonly logger: Logger,
  ) {}

  public start(): void {
    if (this.timer) return;
    this.timer = setInterval(() => void this.tick(), this.env.LICENSE_JOB_INTERVAL_MS);
    this.timer.unref();
    void this.tick();
  }

  public stop(): void {
    if (this.timer) clearInterval(this.timer);
    this.timer = undefined;
  }

  public async tick(now = new Date()): Promise<void> {
    if (this.running) return;
    this.running = true;
    try {
      const threshold = new Date(now.getTime() + this.env.WALLET_AUTO_RENEW_LEAD_HOURS * 3_600_000);
      const applications = await this.prisma.application.findMany({
        where: {
          autoRenew: true,
          deletedAt: null,
          license: {
            is: {
              autoRenew: true,
              status: { in: ['ACTIVE', 'EXPIRING'] },
              expiresAt: { lte: threshold },
            },
          },
        },
        include: {
          owner: { include: { wallet: true } },
          license: true,
          plan: { include: { prices: { where: { active: true }, orderBy: { periodDays: 'asc' } } } },
        },
      });

      for (const application of applications) {
        if (!application.license) continue;
        const price = application.plan.prices.find(
          (item) => item.periodDays === application.autoRenewPeriodDays,
        ) ?? application.plan.prices.find(
          (item) => item.periodDays === this.env.DEFAULT_PLAN_PERIOD_DAYS,
        ) ?? application.plan.prices[0];
        if (!price) continue;

        const amountInCents = Math.max(50, price.amountInCents - price.discountInCents);
        const reference = `ASTRO_AUTO_RENEW:${application.id}:${application.license.expiresAt.toISOString()}:${price.periodDays}`;
        const alreadyProcessed = await this.prisma.walletTransaction.findUnique({ where: { reference } });
        if (alreadyProcessed) continue;

        if (!application.owner.wallet || application.owner.wallet.balanceInCents < amountInCents) {
          const recentNotice = await this.prisma.notification.findFirst({
            where: {
              userId: application.ownerId,
              type: 'ASTRO_WALLET_INSUFFICIENT',
              createdAt: { gte: new Date(now.getTime() - 12 * 3_600_000) },
            },
          });
          if (!recentNotice) {
            await this.notifications.sendDiscord(
              application.owner.discordId,
              'ASTRO_WALLET_INSUFFICIENT',
              `A renovação automática de **${application.name}** não foi concluída. Saldo necessário na ASTRO WALLET: **${formatMoney(amountInCents)}**.`,
            );
          }
          continue;
        }

        try {
          const result = await this.prisma.$transaction(async (tx) => {
            const duplicate = await tx.walletTransaction.findUnique({ where: { reference } });
            if (duplicate) return null;
            const wallet = await tx.wallet.findUnique({ where: { userId: application.ownerId } });
            if (!wallet || wallet.balanceInCents < amountInCents) return null;
            const currentLicense = await tx.license.findUnique({ where: { applicationId: application.id } });
            if (!currentLicense?.autoRenew) return null;

            const newBalance = wallet.balanceInCents - amountInCents;
            const newExpiry = calculateRenewalExpiry(
              currentLicense.expiresAt,
              now,
              price.periodDays,
            );
            await tx.wallet.update({
              where: { id: wallet.id },
              data: { balanceInCents: newBalance },
            });
            await tx.walletTransaction.create({
              data: {
                walletId: wallet.id,
                applicationId: application.id,
                type: 'AUTO_RENEW',
                amountInCents: -amountInCents,
                balanceAfterInCents: newBalance,
                reference,
                description: `Renovação automática de ${application.name} por ${price.periodDays} dias`,
              },
            });
            await tx.license.update({
              where: { id: currentLicense.id },
              data: { status: 'ACTIVE', expiresAt: newExpiry, autoRenew: true },
            });
            await tx.application.update({
              where: { id: application.id },
              data: {
                autoRenew: true,
                autoRenewPeriodDays: price.periodDays,
                status: application.status === 'EXPIRED' || application.status === 'SUSPENDED'
                  ? 'OFFLINE'
                  : application.status,
              },
            });
            await tx.applicationAddon.updateMany({
              where: { applicationId: application.id, status: 'ACTIVE' },
              data: { expiresAt: newExpiry },
            });
            await tx.auditLog.create({
              data: {
                actorType: 'SYSTEM',
                action: 'ASTRO_WALLET_AUTO_RENEWED',
                entityType: 'Application',
                entityId: application.id,
                metadataSafe: {
                  amountInCents,
                  periodDays: price.periodDays,
                  previousExpiry: currentLicense.expiresAt.toISOString(),
                  newExpiry: newExpiry.toISOString(),
                },
              },
            });
            return { newExpiry, newBalance };
          }, { isolationLevel: 'Serializable' });

          if (result) {
            await this.notifications.sendDiscord(
              application.owner.discordId,
              'ASTRO_WALLET_AUTO_RENEWED',
              `A aplicação **${application.name}** foi renovada automaticamente por **${price.periodDays} dias** usando **${formatMoney(amountInCents)}** da ASTRO WALLET. Saldo restante: **${formatMoney(result.newBalance)}**.`,
            );
          }
        } catch (error) {
          this.logger.warn({ err: error, applicationId: application.id }, 'Falha na renovação automática pela ASTRO WALLET');
        }
      }
    } finally {
      this.running = false;
    }
  }
}
