import type { PrismaClient } from '@prisma/client';
import type { Env } from '../config/env.js';
import type { Logger } from '../config/logger.js';
import type { PaymentService } from '../services/payments/payment-service.js';
import type { PaymentMessageService } from '../bot/messages/payment-message-service.js';

export class PaymentPollingJob {
  private timer?: NodeJS.Timeout;
  private running = false;

  public constructor(
    private readonly prisma: PrismaClient,
    private readonly payments: PaymentService,
    private readonly messages: PaymentMessageService,
    private readonly env: Env,
    private readonly logger: Logger,
  ) {}

  public start(): void {
    if (this.timer) return;
    this.timer = setInterval(() => void this.tick(), this.env.PAYMENT_POLL_INTERVAL_MS);
    this.timer.unref();
    void this.tick();
  }

  public stop(): void {
    if (this.timer) clearInterval(this.timer);
    this.timer = undefined;
  }

  public async tick(): Promise<void> {
    if (this.running) return;
    this.running = true;
    try {
      const expiredIds = await this.payments.expireDue();
      await Promise.all(expiredIds.map(async (id) => this.messages.refresh(id)));
      const pending = await this.prisma.payment.findMany({
        where: {
          status: 'PENDING',
          pollAttempts: { lt: this.env.PAYMENT_POLL_MAX_ATTEMPTS },
          expiresAt: { gt: new Date() },
        },
        select: { id: true },
      });
      for (const payment of pending) {
        try {
          const updated = await this.payments.sync(payment.id);
          await this.messages.refresh(updated.id);
        } catch (error) {
          this.logger.warn(
            { err: error, paymentId: payment.id },
            'Falha temporária ao consultar pagamento',
          );
        }
      }
    } finally {
      this.running = false;
    }
  }
}
