import type { PrismaClient } from '@prisma/client';
import type { Env } from '../config/env.js';
import type { Logger } from '../config/logger.js';
import type { HostingProvider } from '../types/hosting.js';
import type { NotificationService } from '../services/notifications/notification-service.js';

const DAY = 86_400_000;

export class LicenseExpirationJob {
  private timer?: NodeJS.Timeout;
  private running = false;

  public constructor(
    private readonly prisma: PrismaClient,
    private readonly hosting: HostingProvider,
    private readonly notifications: NotificationService,
    private readonly env: Env,
    private readonly logger: Logger,
  ) {}

  public start(): void {
    if (this.timer) return;
    this.timer = setInterval(() => void this.tick(), this.env.LICENSE_JOB_INTERVAL_MS);
    this.timer.unref();
    void this.tick();
  }

  public stop(): void {
    if (this.timer) clearInterval(this.timer);
    this.timer = undefined;
  }

  public async tick(now = new Date()): Promise<void> {
    if (this.running) return;
    this.running = true;
    try {
      const licenses = await this.prisma.license.findMany({
        where: { status: { in: ['ACTIVE', 'EXPIRING'] } },
        include: { application: { include: { owner: true } } },
      });
      for (const license of licenses) {
        const remaining = license.expiresAt.getTime() - now.getTime();
        if (remaining <= 0) {
          await this.prisma.$transaction([
            this.prisma.license.update({ where: { id: license.id }, data: { status: 'EXPIRED' } }),
            this.prisma.application.update({
              where: { id: license.applicationId },
              data: { status: 'EXPIRED' },
            }),
            this.prisma.auditLog.create({
              data: {
                actorType: 'SYSTEM',
                action: 'LICENSE_EXPIRED',
                entityType: 'License',
                entityId: license.id,
              },
            }),
          ]);
          try {
            await this.hosting.suspendApplication(license.applicationId);
          } catch (error) {
            this.logger.warn(
              { err: error, applicationId: license.applicationId },
              'Falha ao suspender aplicação vencida',
            );
          }
          await this.notifications.sendDiscord(
            license.application.owner.discordId,
            'LICENSE_EXPIRED',
            `A licença de **${license.application.name}** venceu e a aplicação foi suspensa.`,
          );
          continue;
        }
        if (remaining <= 7 * DAY && license.status !== 'EXPIRING') {
          await this.prisma.license.update({
            where: { id: license.id },
            data: { status: 'EXPIRING' },
          });
          await this.notifications.sendDiscord(
            license.application.owner.discordId,
            'LICENSE_EXPIRING',
            `A licença de **${license.application.name}** vence em breve. Use /apps para renovar.`,
          );
        }
      }
    } finally {
      this.running = false;
    }
  }
}
