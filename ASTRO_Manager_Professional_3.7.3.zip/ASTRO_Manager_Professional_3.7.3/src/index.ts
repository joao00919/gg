import { createServer } from 'node:http';
import { getEnv } from './config/env.js';
import { buildBrand } from './config/brand.js';
import { createLogger } from './config/logger.js';
import { prisma } from './database/prisma.js';
import { retryDatabaseOperation } from './database/retry.js';
import { createPaymentProvider } from './integrations/payment/factory.js';
import { createHostingProvider } from './integrations/hosting/factory.js';
import { AuditService } from './services/audit/audit-service.js';
import { PlanService } from './services/plans/plan-service.js';
import { CartService } from './services/carts/cart-service.js';
import { PaymentService } from './services/payments/payment-service.js';
import { ApplicationService } from './services/applications/application-service.js';
import { LicenseService } from './services/licenses/license-service.js';
import { TransferService } from './services/transfers/transfer-service.js';
import { LogService } from './services/logs/log-service.js';
import { SessionService } from './services/sessions/session-service.js';
import { NotificationService } from './services/notifications/notification-service.js';
import { DeploymentService } from './services/deployments/deployment-service.js';
import { SalesIntegrationService } from './integrations/sales-bot/sales-service.js';
import { createManagerClient, bindManagerClient } from './bot/client/manager-client.js';
import { PaymentMessageService } from './bot/messages/payment-message-service.js';
import { createApi } from './api/app.js';
import { PaymentPollingJob } from './jobs/payment-polling-job.js';
import { LicenseExpirationJob } from './jobs/license-expiration-job.js';
import { WalletAutoRenewJob } from './jobs/wallet-auto-renew-job.js';
import { WalletService } from './services/wallets/wallet-service.js';
import type { AppContext } from './context.js';

const env = getEnv();
const logger = createLogger(env);
const brand = buildBrand(env);

const databaseRetryOptions = (operation: string) => ({
  attempts: env.DATABASE_STARTUP_RETRIES,
  baseDelayMs: env.DATABASE_RETRY_BASE_MS,
  maxDelayMs: env.DATABASE_RETRY_MAX_MS,
  operation,
  onRetry: ({ attempt, attempts, delayMs, error }: {
    attempt: number;
    attempts: number;
    delayMs: number;
    error: unknown;
  }) => {
    logger.warn(
      { err: error, attempt, attempts, retryInMs: delayMs, operation },
      'Banco de dados temporariamente indisponível; nova tentativa agendada',
    );
  },
});

await retryDatabaseOperation(
  () => prisma.$connect(),
  databaseRetryOptions('conexão inicial com PostgreSQL'),
);
logger.info('Conexão com PostgreSQL estabelecida');

const paymentProvider = createPaymentProvider(env);
const hostingProvider = createHostingProvider(env);
const audit = new AuditService(prisma);
const plans = new PlanService(prisma);
const carts = new CartService(prisma, plans);
const payments = new PaymentService(prisma, paymentProvider, env, audit, logger);
const applications = new ApplicationService(prisma, hostingProvider, audit);
const licenses = new LicenseService(prisma, audit);
const transfers = new TransferService(prisma, audit);
const logs = new LogService(hostingProvider);
const sessions = new SessionService(prisma, env.CUSTOM_ID_SECRET);
const client = createManagerClient();
const notifications = new NotificationService(prisma, logger, client);
const deployments = new DeploymentService(prisma, hostingProvider, audit);
const sales = new SalesIntegrationService(prisma, audit, notifications);
const wallets = new WalletService(prisma);
const paymentMessages = new PaymentMessageService(
  prisma,
  client,
  brand,
  logger,
  env.CART_DELETE_DELAY_SECONDS,
);

const context: AppContext = {
  env,
  logger,
  brand,
  prisma,
  paymentProvider,
  hostingProvider,
  audit,
  plans,
  carts,
  payments,
  applications,
  licenses,
  transfers,
  logs,
  sessions,
  notifications,
  deployments,
  sales,
  paymentMessages,
  wallets,
  client,
};

bindManagerClient(client, context);
let firstSeedAttempt = true;
await retryDatabaseOperation(
  async () => {
    if (!firstSeedAttempt) {
      await prisma.$disconnect().catch(() => undefined);
      await prisma.$connect();
    }
    firstSeedAttempt = false;
    await plans.seedDefaults();
  },
  databaseRetryOptions('cadastro dos planos padrão'),
);
logger.info('Planos padrão sincronizados');

const api = createApi(context);
const server = createServer(api);
server.listen(env.API_PORT, env.API_HOST, () => {
  logger.info({ host: env.API_HOST, port: env.API_PORT }, 'API HTTP iniciada');
});

const paymentJob = new PaymentPollingJob(prisma, payments, paymentMessages, env, logger);
const walletAutoRenewJob = new WalletAutoRenewJob(prisma, notifications, env, logger);
const licenseJob = new LicenseExpirationJob(prisma, hostingProvider, notifications, env, logger);
paymentJob.start();
walletAutoRenewJob.start();
licenseJob.start();

await client.login(env.MANAGER_BOT_TOKEN);

let shuttingDown = false;
async function shutdown(signal: string): Promise<void> {
  if (shuttingDown) return;
  shuttingDown = true;
  logger.info({ signal }, 'Encerrando aplicação');
  paymentJob.stop();
  walletAutoRenewJob.stop();
  licenseJob.stop();
  await client.destroy();
  await new Promise<void>((resolve) => server.close(() => resolve()));
  await prisma.$disconnect();
}

for (const signal of ['SIGINT', 'SIGTERM'] as const) {
  process.once(signal, () => {
    void shutdown(signal).finally(() => process.exit(0));
  });
}

process.on('unhandledRejection', (reason) => {
  logger.error({ err: reason }, 'Promise rejeitada sem tratamento');
});
process.on('uncaughtException', (error) => {
  logger.fatal({ err: error }, 'Exceção não tratada');
  void shutdown('uncaughtException').finally(() => process.exit(1));
});
