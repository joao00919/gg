import {
  ChannelType,
  MessageFlags,
  PermissionFlagsBits,
  type ButtonInteraction,
  type ChatInputCommandInteraction,
  type Guild,
  type GuildTextBasedChannel,
  type StringSelectMenuInteraction,
} from 'discord.js';
import type { CartKind } from '@prisma/client';
import type { AppContext } from '../../context.js';
import { DomainError } from '../../utils/errors.js';
import { cartOpenedPanel } from '../panels/action-panels.js';
import { cartPanel, type PurchaseCartView } from '../panels/payment-panel.js';

export type CartInteraction =
  | ChatInputCommandInteraction
  | StringSelectMenuInteraction
  | ButtonInteraction;

export interface OpenCartInput {
  kind: CartKind;
  planId: string;
  applicationId?: string;
  periodDays: number;
  preselectedAddonIds?: string[];
  responseMode: 'reply' | 'update';
}

export async function openCartFlow(
  interaction: CartInteraction,
  context: AppContext,
  input: OpenCartInput,
): Promise<void> {
  if (!interaction.guild || !interaction.guildId) {
    throw new DomainError('O carrinho precisa ser aberto dentro do servidor.', 'GUILD_REQUIRED');
  }

  // Confirma a interação sem publicar mensagens intermediárias.
  if (!interaction.replied && !interaction.deferred) {
    await interaction.deferReply({ flags: MessageFlags.Ephemeral });
  }

  let cart: Awaited<ReturnType<AppContext['carts']['create']>> | undefined;
  let channel: GuildTextBasedChannel | undefined;
  let cartMessage: Awaited<ReturnType<GuildTextBasedChannel['send']>> | undefined;

  try {
    cart = await context.carts.create({
      discordUserId: interaction.user.id,
      username: interaction.user.username,
      guildId: interaction.guildId,
      planId: input.planId,
      periodDays: input.periodDays,
      applicationId: input.applicationId,
      kind: input.kind,
      expiresAt: new Date(Date.now() + context.env.PAYMENT_EXPIRATION_MINUTES * 60_000),
    });
    if (input.preselectedAddonIds?.length) {
      await context.carts.updateAddons(cart.id, interaction.user.id, input.preselectedAddonIds);
    }

    channel = await createPrivateCartChannel(interaction.guild, interaction, context);

    const session = await context.sessions.create(
      interaction.user.id,
      'CART',
      'Cart',
      cart.id,
      context.env.PAYMENT_EXPIRATION_MINUTES,
    );
    const view = await buildCartView(context, cart.id, interaction.user.id);

    cartMessage = await channel.send({
      ...cartPanel(context.brand, view, session, context.sessions),
      content: `<@${interaction.user.id}>`,
      allowedMentions: { users: [interaction.user.id] },
    });
    await context.carts.attachChannel(cart.id, channel.id, cartMessage.id);
    await interaction.editReply(cartOpenedPanel(context.brand, cartMessage.url));
  } catch (error) {
    context.logger.error(
      {
        err: error,
        cartId: cart?.id,
        channelId: channel?.id,
        discordUserId: interaction.user.id,
      },
      'Falha ao concluir abertura do carrinho',
    );

    if (!cartMessage && channel) {
      await channel.delete('Falha ao publicar o painel inicial do carrinho').catch(() => undefined);
    }

    if (cartMessage) {
      await cartMessage
        .edit({
          content: `${context.brand.emojis.error ?? '✕'} Não foi possível carregar este carrinho. Tente novamente em alguns instantes.`,
          embeds: [],
          components: [],
        })
        .catch(() => undefined);
    }

    if (cart) {
      await context.carts.cancel(cart.id, interaction.user.id).catch(() => undefined);
    }

    throw error;
  }
}

export async function buildCartView(
  context: AppContext,
  cartId: string,
  discordUserId: string,
): Promise<PurchaseCartView> {
  const cart = await context.carts.getOwned(cartId, discordUserId);
  const storePlan = await context.plans.getStorePlan(cart.planId);
  return {
    id: cart.id,
    kind: cart.kind,
    periodDays: cart.periodDays,
    amountInCents: cart.amountInCents,
    expiresAt: cart.expiresAt,
    application: cart.application,
    plan: { ...cart.plan, prices: storePlan.prices },
    addons: cart.addons,
    availableAddons: storePlan.addons.map((item) => item.addon),
  };
}

async function createPrivateCartChannel(
  guild: Guild,
  interaction: CartInteraction,
  context: AppContext,
): Promise<GuildTextBasedChannel> {
  const parent = context.env.CART_PARENT_CHANNEL_ID
    ? await guild.channels.fetch(context.env.CART_PARENT_CHANNEL_ID)
    : interaction.channel;
  const safeUsername = interaction.user.username
    .toLowerCase()
    .normalize('NFD')
    .replace(/[\u0300-\u036f]/g, '')
    .replace(/[^a-z0-9-]/g, '-')
    .replace(/-+/g, '-')
    .slice(0, 30);
  const name = `🛒・${safeUsername || 'cliente'}・${interaction.user.id}`.slice(0, 100);

  if (parent?.type === ChannelType.GuildText) {
    const botMember = guild.members.me ?? (await guild.members.fetchMe());
    const permissions = parent.permissionsFor(botMember);
    const requiredPermissions = [
      [PermissionFlagsBits.ViewChannel, 'Ver canal'],
      [PermissionFlagsBits.SendMessages, 'Enviar mensagens'],
      [PermissionFlagsBits.CreatePrivateThreads, 'Criar tópicos privados'],
      [PermissionFlagsBits.SendMessagesInThreads, 'Enviar mensagens em tópicos'],
      [PermissionFlagsBits.ManageThreads, 'Gerenciar tópicos'],
    ] as const;
    const missing = requiredPermissions
      .filter(([permission]) => !permissions.has(permission))
      .map(([, label]) => label);
    if (missing.length) {
      throw new DomainError(
        `O bot não possui as permissões necessárias no canal de carrinhos: ${missing.join(', ')}.`,
        'CART_CHANNEL_PERMISSIONS',
        403,
      );
    }

    const thread = await parent.threads.create({
      name,
      type: ChannelType.PrivateThread,
      invitable: false,
      reason: `Carrinho de ${interaction.user.tag}`,
    });
    await thread.members.add(interaction.user.id);
    return thread;
  }

  const permissionOverwrites = [
    { id: guild.roles.everyone.id, deny: [PermissionFlagsBits.ViewChannel] },
    {
      id: interaction.user.id,
      allow: [
        PermissionFlagsBits.ViewChannel,
        PermissionFlagsBits.SendMessages,
        PermissionFlagsBits.ReadMessageHistory,
        PermissionFlagsBits.AttachFiles,
      ],
    },
    {
      id: interaction.client.user.id,
      allow: [
        PermissionFlagsBits.ViewChannel,
        PermissionFlagsBits.SendMessages,
        PermissionFlagsBits.ReadMessageHistory,
        PermissionFlagsBits.ManageChannels,
        PermissionFlagsBits.ManageMessages,
        PermissionFlagsBits.AttachFiles,
      ],
    },
    ...context.env.ADMIN_ROLE_IDS.map((id) => ({
      id,
      allow: [
        PermissionFlagsBits.ViewChannel,
        PermissionFlagsBits.SendMessages,
        PermissionFlagsBits.ReadMessageHistory,
      ],
    })),
  ];
  const channel = await guild.channels.create({
    name,
    type: ChannelType.GuildText,
    parent: parent?.type === ChannelType.GuildCategory ? parent.id : undefined,
    permissionOverwrites,
    reason: `Carrinho privado de ${interaction.user.tag}`,
  });
  return channel;
}
