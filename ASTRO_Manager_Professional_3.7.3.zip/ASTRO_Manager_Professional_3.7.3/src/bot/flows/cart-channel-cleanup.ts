import { ChannelType, type Client } from 'discord.js';
import type { Logger } from '../../config/logger.js';

function wait(milliseconds: number): Promise<void> {
  if (milliseconds <= 0) return Promise.resolve();
  return new Promise((resolve) => setTimeout(resolve, milliseconds));
}

/**
 * Exclui o tópico/canal privado de um carrinho encerrado.
 * Se o Discord negar a exclusão de um tópico, tenta bloqueá-lo e arquivá-lo
 * para impedir novas mensagens e evitar carrinhos abandonados ativos.
 */
export async function deleteCartChannel(
  client: Client,
  channelId: string,
  logger: Logger,
  reason: string,
  delaySeconds = 0,
): Promise<boolean> {
  await wait(Math.max(0, delaySeconds) * 1000);

  try {
    const channel = await client.channels.fetch(channelId);
    if (!channel) return true;

    if (channel.isThread()) {
      try {
        await channel.delete(reason);
        return true;
      } catch (error) {
        logger.warn({ err: error, channelId }, 'Falha ao excluir tópico; aplicando bloqueio e arquivo');
        await channel.setLocked(true, reason).catch(() => undefined);
        await channel.setArchived(true, reason).catch(() => undefined);
        return false;
      }
    }

    if (channel.type === ChannelType.GuildText) {
      await channel.delete(reason);
      return true;
    }

    logger.warn({ channelId, channelType: channel.type }, 'Canal do carrinho não possui tipo excluível');
    return false;
  } catch (error) {
    logger.warn({ err: error, channelId }, 'Não foi possível excluir o canal do carrinho');
    return false;
  }
}
