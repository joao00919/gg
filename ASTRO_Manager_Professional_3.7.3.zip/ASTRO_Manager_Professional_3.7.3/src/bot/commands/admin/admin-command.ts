import {
  type AutocompleteInteraction,
  type ChatInputCommandInteraction,
} from 'discord.js';
import type { AppContext } from '../../../context.js';
import { isAdministrator } from '../../guards/admin-guard.js';
import { addDays, calculateRenewalExpiry, formatDateTime } from '../../../utils/time.js';
import { generateLicenseKey } from '../../../services/licenses/license-service.js';
import { DomainError } from '../../../utils/errors.js';
import { formatMoney } from '../../../utils/money.js';

interface ResolvedDiscordUser {
  id: string;
  username: string;
}

export async function handleAdminCommand(
  interaction: ChatInputCommandInteraction,
  context: AppContext,
): Promise<void> {
  if (!isAdministrator(interaction, context.env)) {
    throw new DomainError('Você não possui permissão administrativa.', 'ADMIN_FORBIDDEN', 403);
  }

  const group = interaction.options.getSubcommandGroup(false);
  const action = interaction.options.getSubcommand();
  await interaction.deferReply({ flags: 64 });

  if (!group) {
    if (action === 'painel') return replyPanel(interaction, context);
    if (action === 'sincronizar') {
      const results = await context.payments.recoverPending();
      await interaction.editReply(
        `Sincronização concluída. ${results.length} pagamento(s) consultado(s).`,
      );
      return;
    }
    if (action === 'diagnostico') {
      await context.prisma.$queryRaw`SELECT 1`;
      await interaction.editReply(
        `Diagnóstico concluído. Banco conectado; provedor PIX: ${context.paymentProvider.name}; hospedagem: ${context.hostingProvider.name}.`,
      );
      return;
    }
    if (action === 'integracao') {
      const plans = await context.prisma.plan.findMany({
        where: { active: true, deletedAt: null },
        select: { id: true, slug: true, name: true },
        orderBy: { displayOrder: 'asc' },
      });
      const base =
        context.env.MANAGER_PUBLIC_API_URL.trim() ||
        `http://${context.env.API_HOST === '0.0.0.0' ? 'SEU_HOST' : context.env.API_HOST}:${context.env.API_PORT}`;
      await interaction.editReply(
        [
          '**Vinculação simplificada — Bot de Vendas → Astro Manager**',
          `Endpoint: \`${base}/internal/v1/purchases\``,
          'Método: `POST`',
          'Headers obrigatórios: `x-api-key`, `x-timestamp`, `x-signature` e `content-type: application/json`.',
          '',
          '**Planos disponíveis**',
          ...plans.map((plan) => `• \`${plan.slug}\` — ${plan.name} (ID: \`${plan.id}\`)`),
          '',
          'Quando o Bot de Vendas informa uma compra aprovada, o Manager cria ou atualiza o cliente, entrega a aplicação, ativa a licença e libera o gerenciamento no `/apps`.',
          'A chave privada não é exibida no Discord. Use o arquivo `docs/SALES_BOT_API.md` para copiar o cliente de integração pronto.',
        ].join('\n'),
      );
      return;
    }
  }

  if (group === 'aplicacao') return handleApplicationAdmin(interaction, context, action);
  if (group === 'licenca') return handleLicenseAdmin(interaction, context, action);
  if (group === 'pagamento') return handlePaymentAdmin(interaction, context, action);
  if (group === 'cliente') return handleCustomerAdmin(interaction, context, action);
  if (group === 'wallet') return handleWalletAdmin(interaction, context, action);
  if (group === 'plano') return handlePlanAdmin(interaction, context, action);
  throw new DomainError('Ação administrativa desconhecida.', 'ADMIN_ACTION_UNKNOWN');
}

export async function handleAdminAutocomplete(
  interaction: AutocompleteInteraction,
  context: AppContext,
): Promise<void> {
  if (!isAdministrator(interaction, context.env)) {
    await interaction.respond([]);
    return;
  }

  const focused = interaction.options.getFocused(true);
  const query = focused.value.trim();

  if (focused.name === 'plano') {
    const plans = await context.prisma.plan.findMany({
      where: {
        active: true,
        deletedAt: null,
        ...(query
          ? {
              OR: [
                { name: { contains: query, mode: 'insensitive' as const } },
                { slug: { contains: query, mode: 'insensitive' as const } },
              ],
            }
          : {}),
      },
      orderBy: { displayOrder: 'asc' },
      take: 25,
    });
    await interaction.respond(
      plans.map((plan) => ({
        name: `${plan.name} — ${plan.slug}`.slice(0, 100),
        value: plan.id,
      })),
    );
    return;
  }

  await interaction.respond([]);
}

async function replyPanel(
  interaction: ChatInputCommandInteraction,
  context: AppContext,
): Promise<void> {
  const [users, applications, activeLicenses, pendingPayments, plans] = await Promise.all([
    context.prisma.user.count({ where: { deletedAt: null } }),
    context.prisma.application.count({ where: { deletedAt: null } }),
    context.prisma.license.count({ where: { status: { in: ['ACTIVE', 'EXPIRING'] } } }),
    context.prisma.payment.count({ where: { status: { in: ['CREATED', 'PENDING'] } } }),
    context.prisma.plan.count({ where: { active: true, deletedAt: null } }),
  ]);
  await interaction.editReply(
    [
      '**Central Administrativa — Astro Applications**',
      `Clientes: **${users}**`,
      `Aplicações: **${applications}**`,
      `Licenças ativas: **${activeLicenses}**`,
      `Pagamentos pendentes: **${pendingPayments}**`,
      `Planos ativos: **${plans}**`,
      '',
      'Atalhos: `/admin aplicacao entregar`, `/admin pagamento aprovar`, `/admin plano listar` e `/admin diagnostico`.',
    ].join('\n'),
  );
}

async function handleApplicationAdmin(
  interaction: ChatInputCommandInteraction,
  context: AppContext,
  action: string,
): Promise<void> {
  if (action === 'criar' || action === 'entregar') {
    const target = await resolveDiscordUser(interaction, 'cliente', 'usuario_id');
    const planInput = interaction.options.getString('plano', true);
    const plan = await resolvePlan(context, planInput);
    const days = interaction.options.getInteger('dias', true);
    const requestedName = interaction.options.getString('nome')?.trim();
    const name = (requestedName?.length ? requestedName : `${plan.name} - ${target.username}`).slice(
      0,
      100,
    );

    const user = await context.prisma.user.upsert({
      where: { discordId: target.id },
      update: { username: target.username, deletedAt: null },
      create: { discordId: target.id, username: target.username },
    });
    const generated = generateLicenseKey();
    const expiresAt = addDays(new Date(), days);
    const application = await context.prisma.$transaction(async (tx) => {
      const created = await tx.application.create({
        data: { ownerId: user.id, planId: plan.id, name, status: 'OFFLINE' },
      });
      await tx.license.create({
        data: {
          applicationId: created.id,
          planId: plan.id,
          keyPrefix: generated.prefix,
          keyHash: generated.hash,
          status: 'ACTIVE',
          activatedAt: new Date(),
          expiresAt,
          serverLimit: plan.serverLimit,
        },
      });
      return created;
    });

    await context.audit.record({
      actorId: interaction.user.id,
      actorType: 'ADMIN',
      action: 'ADMIN_APPLICATION_DELIVER',
      entityType: 'Application',
      entityId: application.id,
      metadataSafe: { customerDiscordId: target.id, planId: plan.id, days },
    });

    await interaction.client.users
      .fetch(target.id)
      .then((customer) =>
        customer.send(
          `${context.brand.emojis.app ?? '🤖'} Seu bot **${application.name}** foi liberado na ${context.brand.name}. Use \`/apps\` no servidor para gerenciar. Licença válida até ${formatDateTime(expiresAt)}.`,
        ),
      )
      .catch(() => undefined);

    await interaction.editReply(
      [
        `${context.brand.emojis.success ?? '✓'} Bot entregue com sucesso.`,
        `Cliente: <@${target.id}> (\`${target.id}\`)`,
        `Aplicação: **${application.name}**`,
        `ID da aplicação: \`${application.id}\``,
        `Plano: **${plan.name}**`,
        `Licença até: **${formatDateTime(expiresAt)}**`,
        `Chave exibida somente nesta resposta: \`${generated.key}\``,
      ].join('\n'),
    );
    return;
  }

  const id = interaction.options.getString('id', true);
  const application = await context.prisma.application.findUnique({
    where: { id },
    include: { owner: true, plan: true, license: true },
  });
  if (!application) {
    throw new DomainError('Aplicação não encontrada.', 'APPLICATION_NOT_FOUND', 404);
  }

  if (action === 'consultar') {
    await interaction.editReply(
      `**${application.name}**\nID: \`${application.id}\`\nDono: <@${application.owner.discordId}>\nPlano: ${application.plan.name}\nStatus: ${application.status}\nLicença: ${application.license?.status ?? 'Ausente'}`,
    );
    return;
  }
  if (action === 'editar') {
    const name = interaction.options.getString('nome', true).trim().slice(0, 100);
    await context.prisma.application.update({ where: { id }, data: { name } });
    await interaction.editReply('Aplicação editada com sucesso.');
    return;
  }
  if (action === 'suspender') {
    await context.hostingProvider.suspendApplication(id);
    await context.prisma.application.update({ where: { id }, data: { status: 'SUSPENDED' } });
    await interaction.editReply('Aplicação suspensa.');
    return;
  }
  if (action === 'ativar') {
    await context.hostingProvider.activateApplication(id);
    await context.prisma.application.update({ where: { id }, data: { status: 'ONLINE' } });
    await interaction.editReply('Aplicação ativada.');
    return;
  }
  if (action === 'excluir') {
    await context.hostingProvider.suspendApplication(id);
    await context.prisma.application.update({
      where: { id },
      data: { status: 'DELETED', deletedAt: new Date() },
    });
    await interaction.editReply('Aplicação excluída logicamente.');
    return;
  }
  if (action === 'reiniciar') {
    const result = await context.hostingProvider.restartApplication(id);
    await context.prisma.application.update({
      where: { id },
      data: { status: result.accepted ? 'ONLINE' : 'ERROR', lastRestartAt: new Date() },
    });
    await interaction.editReply(result.message);
    return;
  }

  throw new DomainError('Ação de aplicação desconhecida.', 'ADMIN_APPLICATION_ACTION_UNKNOWN');
}

async function handleLicenseAdmin(
  interaction: ChatInputCommandInteraction,
  context: AppContext,
  action: string,
): Promise<void> {
  const applicationId = interaction.options.getString('aplicacao', true);
  const application = await context.prisma.application.findUnique({
    where: { id: applicationId },
    include: { plan: true, license: true },
  });
  if (!application) {
    throw new DomainError('Aplicação não encontrada.', 'APPLICATION_NOT_FOUND', 404);
  }

  if (action === 'criar') {
    const days = interaction.options.getInteger('dias', true);
    const generated = generateLicenseKey();
    await context.prisma.license.upsert({
      where: { applicationId },
      update: {
        keyPrefix: generated.prefix,
        keyHash: generated.hash,
        status: 'ACTIVE',
        activatedAt: new Date(),
        expiresAt: addDays(new Date(), days),
        serverLimit: application.plan.serverLimit,
      },
      create: {
        applicationId,
        planId: application.planId,
        keyPrefix: generated.prefix,
        keyHash: generated.hash,
        status: 'ACTIVE',
        activatedAt: new Date(),
        expiresAt: addDays(new Date(), days),
        serverLimit: application.plan.serverLimit,
      },
    });
    await interaction.editReply(`Licença criada. Chave exibida uma única vez: \`${generated.key}\``);
    return;
  }
  if (!application.license) {
    throw new DomainError('Licença não encontrada.', 'LICENSE_NOT_FOUND', 404);
  }
  if (action === 'renovar') {
    const days = interaction.options.getInteger('dias', true);
    const next = calculateRenewalExpiry(application.license.expiresAt, new Date(), days);
    await context.prisma.license.update({
      where: { id: application.license.id },
      data: { status: 'ACTIVE', expiresAt: next },
    });
    await interaction.editReply(`Licença renovada até ${formatDateTime(next)}.`);
    return;
  }

  const status = action === 'suspender' ? 'SUSPENDED' : action === 'ativar' ? 'ACTIVE' : 'REVOKED';
  await context.prisma.license.update({ where: { id: application.license.id }, data: { status } });
  await context.prisma.application.update({
    where: { id: applicationId },
    data: { status: status === 'ACTIVE' ? 'OFFLINE' : 'SUSPENDED' },
  });
  await interaction.editReply(`Licença atualizada para ${status}.`);
}

async function handlePaymentAdmin(
  interaction: ChatInputCommandInteraction,
  context: AppContext,
  action: string,
): Promise<void> {
  if (action === 'aprovar') {
    const payment = await resolvePaymentForApproval(interaction, context);
    const updated = await context.payments.approveManually(payment.id, interaction.user.id);
    await context.paymentMessages.refresh(updated.id);
    await interaction.editReply(
      [
        `${context.brand.emojis.success ?? '✓'} Pedido aprovado manualmente.`,
        `Cliente: <@${payment.user.discordId}> (\`${payment.user.discordId}\`)`,
        `Pagamento: \`${updated.id}\``,
        `Status: **${updated.status}**`,
        updated.applicationId ? `Aplicação liberada: \`${updated.applicationId}\`` : 'Aplicação atualizada.',
      ].join('\n'),
    );
    return;
  }

  const id = interaction.options.getString('id', true);
  const payment = await context.prisma.payment.findUnique({
    where: { id },
    include: { user: true },
  });
  if (!payment) throw new DomainError('Pagamento não encontrado.', 'PAYMENT_NOT_FOUND', 404);

  if (action === 'consultar') {
    await interaction.editReply(
      `Pagamento \`${id}\`\nCliente: <@${payment.user.discordId}>\nStatus: ${payment.status}\nValor: R$ ${(payment.amountInCents / 100).toFixed(2).replace('.', ',')}\nProvedor: ${payment.provider}`,
    );
    return;
  }
  if (action === 'sincronizar') {
    const updated = await context.payments.sync(id);
    await context.paymentMessages.refresh(updated.id);
    await interaction.editReply(`Pagamento sincronizado com o provedor. Status: **${updated.status}**.`);
    return;
  }

  if (!['CREATED', 'PENDING'].includes(payment.status)) {
    throw new DomainError('O pagamento não pode ser cancelado.', 'PAYMENT_FINAL');
  }
  if (payment.externalPaymentId) {
    await context.paymentProvider.cancelPayment(payment.externalPaymentId);
  }
  await context.prisma.$transaction([
    context.prisma.payment.update({
      where: { id },
      data: { status: 'CANCELLED', cancelledAt: new Date() },
    }),
    context.prisma.cart.update({ where: { id: payment.cartId }, data: { status: 'CANCELLED' } }),
  ]);
  await context.paymentMessages.refresh(id);
  await interaction.editReply(
    `${context.brand.emojis.paymentCancelled ?? '✕'} Pagamento cancelado e carrinho encerrado.`,
  );
}

async function handleCustomerAdmin(
  interaction: ChatInputCommandInteraction,
  context: AppContext,
  action: string,
): Promise<void> {
  if (action === 'consultar') {
    const user = interaction.options.getUser('usuario', true);
    const record = await context.prisma.user.findUnique({
      where: { discordId: user.id },
      include: { applications: { where: { deletedAt: null } } },
    });
    await interaction.editReply(
      record
        ? `Cliente ${user.username}: ${record.applications.length} aplicação(ões).`
        : 'Cliente ainda não registrado.',
    );
    return;
  }

  const applicationId = interaction.options.getString('aplicacao', true);
  const newOwner = interaction.options.getUser('novo-proprietario', true);
  const application = await context.prisma.application.findUnique({
    where: { id: applicationId },
    include: { owner: true },
  });
  if (!application) {
    throw new DomainError('Aplicação não encontrada.', 'APPLICATION_NOT_FOUND', 404);
  }
  await context.transfers.transfer(applicationId, application.owner.discordId, newOwner.id);
  await interaction.editReply(`Aplicação transferida para <@${newOwner.id}>.`);
}

async function handleWalletAdmin(
  interaction: ChatInputCommandInteraction,
  context: AppContext,
  action: string,
): Promise<void> {
  const target = await resolveDiscordUser(interaction, 'usuario', 'usuario_id');
  if (action === 'saldo') {
    const wallet = await context.wallets.getSummary(target.id, target.username);
    await interaction.editReply(
      `${context.brand.emojis.wallet ?? '💳'} ASTRO WALLET de <@${target.id}>: **${formatMoney(wallet.balanceInCents)}**.`,
    );
    return;
  }

  const value = interaction.options.getNumber('valor', true);
  const amountInCents = Math.round(value * 100);
  const providedReason = interaction.options.getString('motivo')?.trim();
  const reason = providedReason && providedReason.length > 0
    ? providedReason
    : (action === 'adicionar' ? 'Crédito administrativo' : 'Débito administrativo');
  const signedAmount = action === 'adicionar' ? amountInCents : -amountInCents;
  const wallet = await context.wallets.adjust(
    target.id,
    signedAmount,
    interaction.user.id,
    reason,
    action === 'adicionar' ? 'CREDIT' : 'DEBIT',
  );
  await interaction.editReply(
    [
      `${context.brand.emojis.wallet ?? '💳'} ASTRO WALLET atualizada.`,
      `Cliente: <@${target.id}> (\`${target.id}\`)`,
      `Movimentação: **${signedAmount >= 0 ? '+' : '-'}${formatMoney(Math.abs(signedAmount))}**`,
      `Saldo atual: **${formatMoney(wallet.balanceInCents)}**`,
      `Motivo: ${reason}`,
    ].join('\n'),
  );
}

async function handlePlanAdmin(
  interaction: ChatInputCommandInteraction,
  context: AppContext,
  action: string,
): Promise<void> {
  if (action === 'listar') {
    const plans = await context.prisma.plan.findMany({
      where: { deletedAt: null },
      include: { prices: { where: { active: true }, orderBy: { periodDays: 'asc' } } },
      orderBy: { displayOrder: 'asc' },
    });
    await interaction.editReply(
      plans.length
        ? plans
            .map(
              (plan) =>
                `**${plan.name}** — slug: \`${plan.slug}\` — ID: \`${plan.id}\` — ${plan.active ? 'ativo' : 'inativo'}\n${plan.prices.map((price) => `  • ${price.label}: R$ ${(price.amountInCents / 100).toFixed(2)}`).join('\n')}`,
            )
            .join('\n\n')
        : 'Nenhum plano cadastrado.',
    );
    return;
  }
  if (action === 'criar') {
    const name = interaction.options.getString('nome', true);
    const description = interaction.options.getString('descricao', true);
    const serverLimit = interaction.options.getInteger('servidores', true);
    const plan = await context.prisma.plan.create({
      data: {
        slug: name
          .toLowerCase()
          .normalize('NFD')
          .replace(/[\u0300-\u036f]/g, '')
          .replace(/[^a-z0-9]+/g, '-')
          .replace(/^-|-$/g, ''),
        name,
        description,
        features: [description],
        serverLimit,
      },
    });
    await interaction.editReply(
      `Plano criado: \`${plan.id}\`. Configure os preços no Prisma Studio ou pela API administrativa.`,
    );
    return;
  }

  const id = interaction.options.getString('id', true);
  if (action === 'editar') {
    const description = interaction.options.getString('descricao', true);
    await context.prisma.plan.update({ where: { id }, data: { description } });
    await interaction.editReply('Plano editado.');
    return;
  }
  await context.prisma.plan.update({ where: { id }, data: { active: action === 'ativar' } });
  await interaction.editReply(`Plano ${action === 'ativar' ? 'ativado' : 'desativado'}.`);
}

async function resolvePlan(context: AppContext, input: string) {
  const value = input.trim();
  const plan = await context.prisma.plan.findFirst({
    where: {
      active: true,
      deletedAt: null,
      OR: [
        { id: value },
        { slug: { equals: value, mode: 'insensitive' } },
        { name: { equals: value, mode: 'insensitive' } },
      ],
    },
  });
  if (!plan) {
    throw new DomainError(
      'Plano não encontrado. Use o autocomplete e selecione um plano ativo.',
      'PLAN_NOT_FOUND',
      404,
    );
  }
  return plan;
}

async function resolveDiscordUser(
  interaction: ChatInputCommandInteraction,
  userOptionName: string,
  idOptionName: string,
): Promise<ResolvedDiscordUser> {
  const selected = interaction.options.getUser(userOptionName);
  if (selected) return { id: selected.id, username: selected.username };

  const raw = interaction.options.getString(idOptionName)?.trim() ?? '';
  const id = raw.replace(/^<@!?/, '').replace(/>$/, '');
  if (!/^\d{17,20}$/.test(id)) {
    throw new DomainError(
      'Informe o cliente usando a opção de usuário ou um ID válido do Discord.',
      'DISCORD_USER_REQUIRED',
    );
  }

  const fetched = await interaction.client.users.fetch(id).catch(() => undefined);
  return { id, username: fetched?.username ?? `usuario-${id.slice(-6)}` };
}

async function resolvePaymentForApproval(
  interaction: ChatInputCommandInteraction,
  context: AppContext,
) {
  const directId = interaction.options.getString('id')?.trim();
  if (directId) {
    const payment = await context.prisma.payment.findUnique({
      where: { id: directId },
      include: { user: true },
    });
    if (!payment) throw new DomainError('Pagamento não encontrado.', 'PAYMENT_NOT_FOUND', 404);
    return payment;
  }

  const selected = interaction.options.getUser('usuario');
  const rawId = interaction.options.getString('usuario_id')?.trim() ?? '';
  const discordId = selected?.id ?? rawId.replace(/^<@!?/, '').replace(/>$/, '');
  if (!/^\d{17,20}$/.test(discordId)) {
    throw new DomainError(
      'Informe o ID do pagamento, selecione o cliente ou digite o ID do usuário.',
      'PAYMENT_TARGET_REQUIRED',
    );
  }

  const payment = await context.prisma.payment.findFirst({
    where: {
      user: { discordId },
      status: { in: ['CREATED', 'PENDING', 'ERROR'] },
    },
    include: { user: true },
    orderBy: { createdAt: 'desc' },
  });
  if (!payment) {
    throw new DomainError(
      'Nenhum pedido pendente foi encontrado para este usuário.',
      'PAYMENT_NOT_FOUND',
      404,
    );
  }
  return payment;
}
