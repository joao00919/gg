import { SlashCommandBuilder } from 'discord.js';

export const commandBuilders = [
  new SlashCommandBuilder()
    .setName('apps')
    .setDescription('Gerencie uma das suas aplicações.')
    .addStringOption((option) =>
      option
        .setName('app')
        .setDescription('Aplicação que você deseja gerenciar.')
        .setRequired(true)
        .setAutocomplete(true),
    ),
  new SlashCommandBuilder()
    .setName('renovar')
    .setDescription('Renove uma aplicação ativa.')
    .addStringOption((option) =>
      option
        .setName('app')
        .setDescription('Aplicação que você deseja renovar.')
        .setRequired(true)
        .setAutocomplete(true),
    ),
  new SlashCommandBuilder()
    .setName('restore')
    .setDescription('Recupere uma aplicação perdida ou inativa.')
    .addStringOption((option) =>
      option
        .setName('app')
        .setDescription('Aplicação que você deseja restaurar.')
        .setRequired(true)
        .setAutocomplete(true),
    ),
  new SlashCommandBuilder()
    .setName('imagem_url')
    .setDescription('Gera uma URL permanente para uma imagem enviada ao Discord.')
    .addAttachmentOption((option) =>
      option.setName('imagem').setDescription('Imagem que será publicada.').setRequired(true),
    ),
  new SlashCommandBuilder()
    .setName('painel')
    .setDescription('Publica um painel público do Manager.')
    .addStringOption((option) =>
      option
        .setName('tipo')
        .setDescription('Painel que será publicado neste canal.')
        .setRequired(true)
        .addChoices(
          { name: 'Central de comandos', value: 'comandos' },
          { name: 'Loja de bots', value: 'bots' },
        ),
    ),
  new SlashCommandBuilder()
    .setName('app')
    .setDescription('Ações rápidas para uma aplicação.')
    .addSubcommand((sub) =>
      sub
        .setName('status')
        .setDescription('Consulta o status.')
        .addStringOption((option) =>
          option.setName('id').setDescription('ID interno da aplicação.').setRequired(true),
        ),
    )
    .addSubcommand((sub) =>
      sub
        .setName('logs')
        .setDescription('Consulta logs recentes.')
        .addStringOption((option) =>
          option.setName('id').setDescription('ID interno da aplicação.').setRequired(true),
        ),
    )
    .addSubcommand((sub) =>
      sub
        .setName('renovar')
        .setDescription('Abre o fluxo de renovação.')
        .addStringOption((option) =>
          option.setName('id').setDescription('ID interno da aplicação.').setRequired(true),
        ),
    )
    .addSubcommand((sub) => sub.setName('suporte').setDescription('Mostra o canal de suporte.')),
  new SlashCommandBuilder()
    .setName('licenca')
    .setDescription('Consulta sua licença.')
    .addSubcommand((sub) =>
      sub
        .setName('status')
        .setDescription('Consulta o status de uma licença.')
        .addStringOption((option) =>
          option.setName('aplicacao').setDescription('ID interno da aplicação.').setRequired(true),
        ),
    ),
  new SlashCommandBuilder()
    .setName('pagamento')
    .setDescription('Consulta pagamentos.')
    .addSubcommand((sub) =>
      sub
        .setName('status')
        .setDescription('Consulta um pagamento.')
        .addStringOption((option) =>
          option.setName('id').setDescription('ID interno do pagamento.').setRequired(true),
        ),
    ),
  new SlashCommandBuilder()
    .setName('wallet')
    .setDescription('Consulte seu saldo e as últimas movimentações da ASTRO WALLET.'),
  new SlashCommandBuilder()
    .setName('admin')
    .setDescription('Administração do Manager.')
    .addSubcommand((sub) => sub.setName('painel').setDescription('Mostra o painel administrativo.'))
    .addSubcommandGroup((group) =>
      group
        .setName('aplicacao')
        .setDescription('Gerencia aplicações.')
        .addSubcommand((sub) =>
          sub
            .setName('criar')
            .setDescription('Entrega um bot diretamente a um cliente.')
            .addStringOption((option) =>
              option
                .setName('plano')
                .setDescription('Plano por nome, slug ou ID.')
                .setRequired(true)
                .setAutocomplete(true),
            )
            .addIntegerOption((option) =>
              option
                .setName('dias')
                .setDescription('Quantidade de dias da licença.')
                .setRequired(true)
                .setMinValue(1),
            )
            .addStringOption((option) =>
              option.setName('nome').setDescription('Nome do bot; opcional.'),
            )
            .addUserOption((option) =>
              option.setName('cliente').setDescription('Cliente por menção ou seleção.'),
            )
            .addStringOption((option) =>
              option.setName('usuario_id').setDescription('ID do Discord do cliente.'),
            ),
        )
        .addSubcommand((sub) =>
          sub
            .setName('entregar')
            .setDescription('Entrega um bot por @cliente ou ID do Discord.')
            .addStringOption((option) =>
              option
                .setName('plano')
                .setDescription('Plano por nome, slug ou ID.')
                .setRequired(true)
                .setAutocomplete(true),
            )
            .addIntegerOption((option) =>
              option
                .setName('dias')
                .setDescription('Quantidade de dias da licença.')
                .setRequired(true)
                .setMinValue(1),
            )
            .addStringOption((option) =>
              option.setName('nome').setDescription('Nome do bot; opcional.'),
            )
            .addUserOption((option) =>
              option.setName('cliente').setDescription('Cliente por menção ou seleção.'),
            )
            .addStringOption((option) =>
              option.setName('usuario_id').setDescription('ID do Discord do cliente.'),
            ),
        )
        .addSubcommand((sub) =>
          sub
            .setName('consultar')
            .setDescription('Consulta uma aplicação.')
            .addStringOption((option) =>
              option.setName('id').setDescription('ID interno.').setRequired(true),
            ),
        )
        .addSubcommand((sub) =>
          sub
            .setName('editar')
            .setDescription('Edita o nome.')
            .addStringOption((option) =>
              option.setName('id').setDescription('ID interno.').setRequired(true),
            )
            .addStringOption((option) =>
              option.setName('nome').setDescription('Novo nome.').setRequired(true),
            ),
        )
        .addSubcommand((sub) =>
          sub
            .setName('suspender')
            .setDescription('Suspende uma aplicação.')
            .addStringOption((option) =>
              option.setName('id').setDescription('ID interno.').setRequired(true),
            ),
        )
        .addSubcommand((sub) =>
          sub
            .setName('ativar')
            .setDescription('Ativa uma aplicação.')
            .addStringOption((option) =>
              option.setName('id').setDescription('ID interno.').setRequired(true),
            ),
        )
        .addSubcommand((sub) =>
          sub
            .setName('excluir')
            .setDescription('Exclui logicamente uma aplicação.')
            .addStringOption((option) =>
              option.setName('id').setDescription('ID interno.').setRequired(true),
            ),
        )
        .addSubcommand((sub) =>
          sub
            .setName('reiniciar')
            .setDescription('Reinicia uma aplicação.')
            .addStringOption((option) =>
              option.setName('id').setDescription('ID interno.').setRequired(true),
            ),
        ),
    )
    .addSubcommandGroup((group) =>
      group
        .setName('licenca')
        .setDescription('Gerencia licenças.')
        .addSubcommand((sub) =>
          sub
            .setName('criar')
            .setDescription('Cria ou substitui a licença.')
            .addStringOption((option) =>
              option
                .setName('aplicacao')
                .setDescription('ID interno da aplicação.')
                .setRequired(true),
            )
            .addIntegerOption((option) =>
              option
                .setName('dias')
                .setDescription('Dias de licença.')
                .setRequired(true)
                .setMinValue(1),
            ),
        )
        .addSubcommand((sub) =>
          sub
            .setName('renovar')
            .setDescription('Renova manualmente.')
            .addStringOption((option) =>
              option.setName('aplicacao').setDescription('ID interno.').setRequired(true),
            )
            .addIntegerOption((option) =>
              option
                .setName('dias')
                .setDescription('Dias adicionais.')
                .setRequired(true)
                .setMinValue(1),
            ),
        )
        .addSubcommand((sub) =>
          sub
            .setName('suspender')
            .setDescription('Suspende a licença.')
            .addStringOption((option) =>
              option.setName('aplicacao').setDescription('ID interno.').setRequired(true),
            ),
        )
        .addSubcommand((sub) =>
          sub
            .setName('ativar')
            .setDescription('Ativa a licença.')
            .addStringOption((option) =>
              option.setName('aplicacao').setDescription('ID interno.').setRequired(true),
            ),
        )
        .addSubcommand((sub) =>
          sub
            .setName('revogar')
            .setDescription('Revoga a licença.')
            .addStringOption((option) =>
              option.setName('aplicacao').setDescription('ID interno.').setRequired(true),
            ),
        ),
    )
    .addSubcommandGroup((group) =>
      group
        .setName('pagamento')
        .setDescription('Gerencia pagamentos.')
        .addSubcommand((sub) =>
          sub
            .setName('consultar')
            .setDescription('Consulta um pagamento.')
            .addStringOption((option) =>
              option.setName('id').setDescription('ID interno.').setRequired(true),
            ),
        )
        .addSubcommand((sub) =>
          sub
            .setName('aprovar')
            .setDescription('Aprova manualmente por pagamento, @cliente ou ID do usuário.')
            .addStringOption((option) =>
              option.setName('id').setDescription('ID interno do pagamento.'),
            )
            .addUserOption((option) =>
              option.setName('usuario').setDescription('Cliente por menção ou seleção.'),
            )
            .addStringOption((option) =>
              option.setName('usuario_id').setDescription('ID do Discord do cliente.'),
            ),
        )
        .addSubcommand((sub) =>
          sub
            .setName('sincronizar')
            .setDescription('Consulta o provedor e atualiza o pagamento.')
            .addStringOption((option) =>
              option.setName('id').setDescription('ID interno do pagamento.').setRequired(true),
            ),
        )
        .addSubcommand((sub) =>
          sub
            .setName('cancelar')
            .setDescription('Cancela um pagamento pendente.')
            .addStringOption((option) =>
              option.setName('id').setDescription('ID interno.').setRequired(true),
            ),
        ),
    )
    .addSubcommandGroup((group) =>
      group
        .setName('cliente')
        .setDescription('Gerencia clientes.')
        .addSubcommand((sub) =>
          sub
            .setName('consultar')
            .setDescription('Consulta um cliente.')
            .addUserOption((option) =>
              option.setName('usuario').setDescription('Cliente.').setRequired(true),
            ),
        )
        .addSubcommand((sub) =>
          sub
            .setName('transferir-app')
            .setDescription('Transfere uma aplicação.')
            .addStringOption((option) =>
              option.setName('aplicacao').setDescription('ID interno.').setRequired(true),
            )
            .addUserOption((option) =>
              option
                .setName('novo-proprietario')
                .setDescription('Novo proprietário.')
                .setRequired(true),
            ),
        ),
    )
    .addSubcommandGroup((group) =>
      group
        .setName('wallet')
        .setDescription('Gerencia saldos da ASTRO WALLET.')
        .addSubcommand((sub) =>
          sub
            .setName('saldo')
            .setDescription('Consulta o saldo de um cliente.')
            .addUserOption((option) =>
              option.setName('usuario').setDescription('Cliente por menção ou seleção.'),
            )
            .addStringOption((option) =>
              option.setName('usuario_id').setDescription('ID do Discord do cliente.'),
            ),
        )
        .addSubcommand((sub) =>
          sub
            .setName('adicionar')
            .setDescription('Adiciona saldo à ASTRO WALLET de um cliente.')
            .addNumberOption((option) =>
              option
                .setName('valor')
                .setDescription('Valor em reais.')
                .setRequired(true)
                .setMinValue(0.01),
            )
            .addUserOption((option) =>
              option.setName('usuario').setDescription('Cliente por menção ou seleção.'),
            )
            .addStringOption((option) =>
              option.setName('usuario_id').setDescription('ID do Discord do cliente.'),
            )
            .addStringOption((option) =>
              option.setName('motivo').setDescription('Motivo do crédito.'),
            ),
        )
        .addSubcommand((sub) =>
          sub
            .setName('remover')
            .setDescription('Remove saldo da ASTRO WALLET de um cliente.')
            .addNumberOption((option) =>
              option
                .setName('valor')
                .setDescription('Valor em reais.')
                .setRequired(true)
                .setMinValue(0.01),
            )
            .addUserOption((option) =>
              option.setName('usuario').setDescription('Cliente por menção ou seleção.'),
            )
            .addStringOption((option) =>
              option.setName('usuario_id').setDescription('ID do Discord do cliente.'),
            )
            .addStringOption((option) =>
              option.setName('motivo').setDescription('Motivo do débito.'),
            ),
        ),
    )
    .addSubcommandGroup((group) =>
      group
        .setName('plano')
        .setDescription('Gerencia planos.')
        .addSubcommand((sub) =>
          sub
            .setName('criar')
            .setDescription('Cria um plano.')
            .addStringOption((option) =>
              option.setName('nome').setDescription('Nome.').setRequired(true),
            )
            .addStringOption((option) =>
              option.setName('descricao').setDescription('Descrição.').setRequired(true),
            )
            .addIntegerOption((option) =>
              option
                .setName('servidores')
                .setDescription('Limite de servidores.')
                .setRequired(true)
                .setMinValue(1),
            ),
        )
        .addSubcommand((sub) =>
          sub
            .setName('editar')
            .setDescription('Edita um plano.')
            .addStringOption((option) =>
              option.setName('id').setDescription('ID do plano.').setRequired(true),
            )
            .addStringOption((option) =>
              option.setName('descricao').setDescription('Nova descrição.').setRequired(true),
            ),
        )
        .addSubcommand((sub) =>
          sub
            .setName('ativar')
            .setDescription('Ativa um plano.')
            .addStringOption((option) =>
              option.setName('id').setDescription('ID do plano.').setRequired(true),
            ),
        )
        .addSubcommand((sub) =>
          sub
            .setName('desativar')
            .setDescription('Desativa um plano.')
            .addStringOption((option) =>
              option.setName('id').setDescription('ID do plano.').setRequired(true),
            ),
        )
        .addSubcommand((sub) =>
          sub.setName('listar').setDescription('Lista IDs, slugs e preços dos planos.'),
        ),
    )
    .addSubcommand((sub) =>
      sub.setName('sincronizar').setDescription('Sincroniza pagamentos pendentes.'),
    )
    .addSubcommand((sub) =>
      sub.setName('diagnostico').setDescription('Executa diagnósticos do sistema.'),
    )
    .addSubcommand((sub) =>
      sub
        .setName('integracao')
        .setDescription('Mostra como vincular o Bot de Vendas ao Manager.'),
    ),
] as const;

export const commandPayloads = commandBuilders.map((command) => command.toJSON());
