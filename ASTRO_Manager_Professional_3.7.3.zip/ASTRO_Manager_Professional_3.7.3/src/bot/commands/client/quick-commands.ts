import { AttachmentBuilder, MessageFlags, type ChatInputCommandInteraction } from 'discord.js';
import type { AppContext } from '../../../context.js';
import { applicationPanel, licensePanel } from '../../panels/apps-panel.js';
import { openCartFlow } from '../../flows/cart-flow.js';
import { errorPanel } from '../../panels/common-panels.js';
import { redactText } from '../../../utils/redact.js';
import { formatMoney } from '../../../utils/money.js';

export async function handleAppCommand(
  interaction: ChatInputCommandInteraction,
  context: AppContext,
): Promise<void> {
  const subcommand = interaction.options.getSubcommand();
  if (subcommand === 'suporte') {
    const support =
      context.env.SUPPORT_CHANNEL_ID && interaction.guildId
        ? `https://discord.com/channels/${interaction.guildId}/${context.env.SUPPORT_CHANNEL_ID}`
        : 'O canal de suporte não foi configurado.';
    await interaction.reply({ content: support, flags: 64 });
    return;
  }
  const applicationId = interaction.options.getString('id', true);
  const application = await context.applications.getOwned(applicationId, interaction.user.id);
  if (subcommand === 'logs') {
    const logs = redactText((await context.logs.getRecent(applicationId, 100)).join('\n'));
    await interaction.reply({
      content: 'Logs recentes em anexo.',
      files: [
        new AttachmentBuilder(Buffer.from(logs || 'Sem logs.'), {
          name: `logs-${applicationId}.txt`,
        }),
      ],
      flags: MessageFlags.Ephemeral,
    });
    return;
  }
  const session = await context.sessions.create(
    interaction.user.id,
    'APPLICATION',
    'Application',
    application.id,
  );
  if (subcommand === 'renovar') {
    const periodDays = application.plan.prices.some(
      (price) => price.periodDays === context.env.DEFAULT_PLAN_PERIOD_DAYS,
    )
      ? context.env.DEFAULT_PLAN_PERIOD_DAYS
      : (application.plan.prices[0]?.periodDays ?? 30);
    await openCartFlow(interaction, context, {
      kind: 'RENEWAL',
      planId: application.planId,
      applicationId: application.id,
      periodDays,
      responseMode: 'reply',
    });
    return;
  }
  await interaction.reply({
    ...applicationPanel(
      context.brand,
      application,
      session,
      context.sessions,
      interaction.user.username,
    ),
    flags: MessageFlags.Ephemeral,
  });
}

export async function handleLicenseCommand(
  interaction: ChatInputCommandInteraction,
  context: AppContext,
): Promise<void> {
  const applicationId = interaction.options.getString('aplicacao', true);
  const application = await context.applications.getOwned(applicationId, interaction.user.id);
  const session = await context.sessions.create(
    interaction.user.id,
    'LICENSE',
    'Application',
    application.id,
  );
  await interaction.reply({
    ...licensePanel(context.brand, application, session, context.sessions),
    flags: MessageFlags.Ephemeral,
  });
}

export async function handlePaymentCommand(
  interaction: ChatInputCommandInteraction,
  context: AppContext,
): Promise<void> {
  const paymentId = interaction.options.getString('id', true);
  const payment = await context.prisma.payment.findFirst({
    where: { id: paymentId, user: { discordId: interaction.user.id } },
  });
  if (!payment) {
    await interaction.reply({
      ...errorPanel(context.brand, 'Pagamento não encontrado ou sem permissão.'),
      flags: MessageFlags.Ephemeral,
    });
    return;
  }
  await interaction.reply({
    content: `Pagamento \`${payment.id}\`\nStatus: **${payment.status}**\nValor: **${payment.amountInCents / 100} ${payment.currency}**`,
    flags: MessageFlags.Ephemeral,
  });
}


export async function handleWalletCommand(
  interaction: ChatInputCommandInteraction,
  context: AppContext,
): Promise<void> {
  const wallet = await context.wallets.getSummary(interaction.user.id, interaction.user.username);
  const movements = wallet.transactions.length
    ? wallet.transactions
        .map((transaction) => {
          const sign = transaction.amountInCents >= 0 ? '+' : '-';
          const amount = formatMoney(Math.abs(transaction.amountInCents));
          const description = transaction.description ?? transaction.type;
          return `• ${sign}${amount} — ${description}`;
        })
        .join('\n')
    : 'Nenhuma movimentação registrada.';

  await interaction.reply({
    content: [
      `${context.brand.emojis.wallet ?? '💳'} **ASTRO WALLET**`,
      `Saldo disponível: **${formatMoney(wallet.balanceInCents)}**`,
      '',
      '**Últimas movimentações**',
      movements,
      '',
      'A renovação automática usa este saldo quando estiver ativada em `/apps`.',
    ].join('\n'),
    flags: MessageFlags.Ephemeral,
  });
}
