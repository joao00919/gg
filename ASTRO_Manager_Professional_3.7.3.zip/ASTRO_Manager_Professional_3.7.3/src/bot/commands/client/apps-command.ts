import {
  MessageFlags,
  type AutocompleteInteraction,
  type ChatInputCommandInteraction,
} from 'discord.js';
import type { AppContext } from '../../../context.js';
import { DomainError } from '../../../utils/errors.js';
import { openCartFlow } from '../../flows/cart-flow.js';
import { isAdministrator } from '../../guards/admin-guard.js';
import { applicationPanel } from '../../panels/apps-panel.js';
import { loadingPanel, successPanel } from '../../panels/common-panels.js';
import { commandsPublicPanel, storePublicPanel } from '../../panels/public-panels.js';

export async function handleAppsCommand(
  interaction: ChatInputCommandInteraction,
  context: AppContext,
): Promise<void> {
  const applicationId = interaction.options.getString('app', true);
  await interaction.reply({
    ...loadingPanel(context.brand, 'Iniciando verificações necessárias...'),
    flags: MessageFlags.Ephemeral,
  });
  const application = await context.applications.getOwned(applicationId, interaction.user.id);
  const session = await context.sessions.create(
    interaction.user.id,
    'APPLICATION',
    'Application',
    application.id,
  );
  await interaction.editReply(
    applicationPanel(
      context.brand,
      application,
      session,
      context.sessions,
      interaction.user.username,
    ),
  );
}

export async function handleRenewCommand(
  interaction: ChatInputCommandInteraction,
  context: AppContext,
): Promise<void> {
  const applicationId = interaction.options.getString('app', true);
  const application = await context.applications.getOwned(applicationId, interaction.user.id);
  const periodDays = application.plan.prices.some(
    (price) => price.periodDays === context.env.DEFAULT_PLAN_PERIOD_DAYS,
  )
    ? context.env.DEFAULT_PLAN_PERIOD_DAYS
    : (application.plan.prices[0]?.periodDays ?? 30);
  await openCartFlow(interaction, context, {
    kind: 'RENEWAL',
    planId: application.planId,
    applicationId: application.id,
    periodDays,
    responseMode: 'reply',
  });
}

export async function handleRestoreCommand(
  interaction: ChatInputCommandInteraction,
  context: AppContext,
): Promise<void> {
  const applicationId = interaction.options.getString('app', true);
  await interaction.reply({
    ...loadingPanel(context.brand, 'Restaurando sua aplicação...'),
    flags: MessageFlags.Ephemeral,
  });
  await context.applications.restore(applicationId, interaction.user.id);
  await interaction.editReply(successPanel(context.brand, 'Aplicação restaurada com sucesso.'));
}

export async function handleImageUrlCommand(
  interaction: ChatInputCommandInteraction,
): Promise<void> {
  const attachment = interaction.options.getAttachment('imagem', true);
  if (!attachment.contentType?.startsWith('image/')) {
    throw new DomainError('O arquivo enviado precisa ser uma imagem.', 'IMAGE_REQUIRED');
  }
  await interaction.reply({
    content: `URL da imagem:\n${attachment.url}`,
    flags: MessageFlags.Ephemeral,
  });
}

export async function handlePanelCommand(
  interaction: ChatInputCommandInteraction,
  context: AppContext,
): Promise<void> {
  if (!isAdministrator(interaction, context.env)) {
    throw new DomainError(
      'Você não possui permissão para publicar painéis.',
      'ADMIN_REQUIRED',
      403,
    );
  }
  const type = interaction.options.getString('tipo', true);
  if (type === 'comandos') {
    await interaction.reply(commandsPublicPanel(context.brand));
    return;
  }
  const plans = await context.plans.listActive();
  await interaction.reply(storePublicPanel(context.brand, plans));
}

export async function handleApplicationAutocomplete(
  interaction: AutocompleteInteraction,
  context: AppContext,
): Promise<void> {
  const focused = interaction.options.getFocused(true);
  if (focused.name !== 'app') return interaction.respond([]);
  const options = await context.applications.autocomplete(interaction.user.id, focused.value);
  await interaction.respond(options);
}
