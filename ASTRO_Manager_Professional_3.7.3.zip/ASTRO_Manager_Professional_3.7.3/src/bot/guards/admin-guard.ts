import {
  GuildMember,
  type AutocompleteInteraction,
  type ChatInputCommandInteraction,
} from 'discord.js';
import type { Env } from '../../config/env.js';

export type AdministrativeInteraction =
  | ChatInputCommandInteraction
  | AutocompleteInteraction;

export function isAdministrator(
  interaction: AdministrativeInteraction,
  env: Env,
): boolean {
  if (env.OWNER_IDS.includes(interaction.user.id)) return true;
  if (interaction.guildId !== env.MANAGER_GUILD_ID) return false;

  const member = interaction.member;
  if (!(member instanceof GuildMember)) return false;

  return env.ADMIN_ROLE_IDS.some((roleId) => member.roles.cache.has(roleId));
}
