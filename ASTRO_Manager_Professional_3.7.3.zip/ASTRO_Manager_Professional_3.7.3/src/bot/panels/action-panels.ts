import {
  ActionRowBuilder,
  ButtonBuilder,
  ButtonStyle,
  EmbedBuilder,
  StringSelectMenuBuilder,
  StringSelectMenuOptionBuilder,
  UserSelectMenuBuilder,
  type BaseMessageOptions,
  type MessageActionRowComponentBuilder,
} from 'discord.js';
import type { Plan, PlanPrice } from '@prisma/client';
import type { BrandConfig } from '../../config/brand.js';
import type { SessionService } from '../../services/sessions/session-service.js';
import { button, linkButton, row } from '../components/helpers.js';

function embed(brand: BrandConfig, title: string, description: string): EmbedBuilder {
  const result = new EmbedBuilder()
    .setColor(brand.primaryColor)
    .setTitle(title)
    .setDescription(description);
  if (brand.logoUrl) result.setThumbnail(brand.logoUrl);
  return result;
}

export function planSelectPanel(
  brand: BrandConfig,
  plans: (Plan & { prices: PlanPrice[] })[],
  session: { id: string; version: number },
  sessions: SessionService,
): BaseMessageOptions {
  const select = new StringSelectMenuBuilder()
    .setCustomId(sessions.buildCustomId(session, 'change_plan_select'))
    .setPlaceholder('Escolha o novo plano')
    .addOptions(
      plans
        .slice(0, 25)
        .map((plan) =>
          new StringSelectMenuOptionBuilder()
            .setLabel(plan.name)
            .setDescription(plan.description.slice(0, 100))
            .setValue(plan.id),
        ),
    );
  return {
    content: null as unknown as string,
    embeds: [
      embed(
        brand,
        'Alterar plano',
        'Selecione o plano desejado. A alteração será concluída somente após a confirmação automática do pagamento.',
      ),
    ],
    components: [
      new ActionRowBuilder<MessageActionRowComponentBuilder>().addComponents(select),
      row(button(sessions.buildCustomId(session, 'back_app'), 'Voltar', ButtonStyle.Secondary)),
    ],
  };
}

export function transferSelectPanel(
  brand: BrandConfig,
  session: { id: string; version: number },
  sessions: SessionService,
): BaseMessageOptions {
  const select = new UserSelectMenuBuilder()
    .setCustomId(sessions.buildCustomId(session, 'transfer_select'))
    .setPlaceholder('Selecione o novo proprietário')
    .setMinValues(1)
    .setMaxValues(1);
  return {
    content: null as unknown as string,
    embeds: [
      embed(
        brand,
        'Transferir propriedade',
        'Selecione o novo proprietário. Pagamentos pendentes, bloqueios e o intervalo mínimo serão verificados antes da confirmação.',
      ),
    ],
    components: [
      new ActionRowBuilder<MessageActionRowComponentBuilder>().addComponents(select),
      row(button(sessions.buildCustomId(session, 'back_app'), 'Voltar', ButtonStyle.Secondary)),
    ],
  };
}

export function confirmationPanel(
  brand: BrandConfig,
  title: string,
  description: string,
  confirmCustomId: string,
  cancelCustomId: string,
): BaseMessageOptions {
  return {
    content: null as unknown as string,
    embeds: [embed(brand, title, description)],
    components: [
      row(
        button(confirmCustomId, 'Confirmar', ButtonStyle.Danger),
        button(cancelCustomId, 'Cancelar', ButtonStyle.Secondary),
      ),
    ],
  };
}

export function informationPanel(
  brand: BrandConfig,
  title: string,
  description: string,
  backCustomId: string,
  link?: { label: string; url: string; emoji?: string },
): BaseMessageOptions {
  const buttons = [button(backCustomId, 'Voltar', ButtonStyle.Secondary)];
  if (link) buttons.unshift(linkButton(link.label, link.url, link.emoji));
  return {
    content: null as unknown as string,
    embeds: [embed(brand, title, description)],
    components: [row(...buttons)],
  };
}

export function cartCancellationPanel(
  brand: BrandConfig,
  confirmCustomId: string,
  backCustomId: string,
): BaseMessageOptions {
  return {
    content: null as unknown as string,
    embeds: [
      embed(
        brand,
        'Cancelar compra',
        'Tem certeza de que deseja cancelar esta compra? O carrinho será encerrado e o tópico será apagado.',
      ),
    ],
    components: [
      row(
        button(backCustomId, 'Voltar', ButtonStyle.Secondary),
        button(confirmCustomId, 'Cancelar Compra', ButtonStyle.Danger),
      ),
    ],
  };
}

export function cartOpenedPanel(brand: BrandConfig, channelUrl: string): BaseMessageOptions {
  const link = new ButtonBuilder()
    .setLabel('Ir para carrinho')
    .setStyle(ButtonStyle.Link)
    .setURL(channelUrl);
  return {
    content: `${brand.emojis.cartOpened ?? brand.emojis.success ?? '✓'} Carrinho aberto com sucesso!`,
    embeds: [],
    components: [row(link)],
  };
}
