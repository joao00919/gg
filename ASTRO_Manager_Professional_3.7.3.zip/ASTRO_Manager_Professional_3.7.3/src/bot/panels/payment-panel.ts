import {
  ActionRowBuilder,
  ButtonStyle,
  EmbedBuilder,
  StringSelectMenuBuilder,
  StringSelectMenuOptionBuilder,
  type BaseMessageOptions,
  type MessageActionRowComponentBuilder,
} from 'discord.js';
import type { Addon, Plan, PlanPrice } from '@prisma/client';
import type { BrandConfig } from '../../config/brand.js';
import type { SessionService } from '../../services/sessions/session-service.js';
import { formatMoney } from '../../utils/money.js';
import { button, parseCustomEmoji, row } from '../components/helpers.js';

export interface PurchaseCartView {
  id: string;
  kind: 'NEW_APPLICATION' | 'RENEWAL' | 'ADDON';
  periodDays: number;
  amountInCents: number;
  expiresAt?: Date;
  application: { name: string } | null;
  plan: Plan & { prices: PlanPrice[] };
  addons: {
    addonId: string;
    amountInCents: number;
    addon: Addon;
  }[];
  availableAddons: Addon[];
}

function planName(days: number): string {
  if (days === 1) return 'Diário';
  if (days === 7) return 'Semanal';
  if (days === 15) return 'Quinzenal';
  if (days === 30) return 'Mensal';
  if (days === 90) return 'Trimestral';
  if (days === 180) return 'Semestral';
  if (days === 365) return 'Anual';

  return `${days} dias`;
}

function purchaseLabel(days: number): string {
  return `Adquirir ${days} ${days === 1 ? 'dia' : 'dias'}`;
}

function safeInline(value: string): string {
  return `\`${value.replaceAll('`', '')}\``;
}

export function cartPanel(
  brand: BrandConfig,
  cart: PurchaseCartView,
  session: { id: string; version: number },
  sessions: SessionService,
): BaseMessageOptions {
  const selectedAddonIds = new Set(cart.addons.map((item) => item.addonId));

  const productName = cart.application?.name ?? cart.plan.name;

  // Emoji personalizado pode ser usado no título porque aqui ele é texto,
  // não um objeto de componente do Discord.
  const cartEmoji = brand.emojis.cart ?? '🛒';

  const embed = new EmbedBuilder()
    .setColor(brand.primaryColor)
    .setTitle(`${cartEmoji} Realizar Compra`)
    .setDescription('• Selecione o plano desejado e, se quiser, adicionais para seu bot.')
    .addFields(
      {
        name: 'Produto',
        value: safeInline(productName),
        inline: true,
      },
      {
        name: 'Plano',
        value: safeInline(planName(cart.periodDays)),
        inline: true,
      },
      {
        name: 'Valor Total:',
        value: safeInline(formatMoney(cart.amountInCents)),
        inline: true,
      },
      {
        name: 'Tempo restante',
        value: `<t:${Math.floor((cart.expiresAt ?? new Date(Date.now() + 10 * 60_000)).getTime() / 1000)}:R>`,
        inline: false,
      },
    )
    .setFooter({ text: 'O carrinho é apagado automaticamente ao expirar.' });

  if (cart.addons.length > 0) {
    embed.addFields({
      name: 'Adicionais selecionados',
      value: cart.addons
        .map((item) => `• **${item.addon.name}** — ${formatMoney(item.amountInCents)}`)
        .join('\n'),
      inline: false,
    });
  }

  const components: ActionRowBuilder<MessageActionRowComponentBuilder>[] = [];

  if (cart.kind !== 'ADDON') {
    const periodOptions = cart.plan.prices
      .filter((price) => price.active)
      .sort((a, b) => a.periodDays - b.periodDays)
      .slice(0, 25)
      .map((price) => {
        const finalPrice = Math.max(50, price.amountInCents - price.discountInCents);

        const option = new StringSelectMenuOptionBuilder()
          .setLabel(purchaseLabel(price.periodDays))
          .setDescription(`Valor: ${formatMoney(finalPrice)}`)
          .setValue(String(price.periodDays))
          .setDefault(price.periodDays === cart.periodDays);
        const emoji = parseCustomEmoji(brand.emojis.dollar ?? '$');
        if (emoji) option.setEmoji(emoji);
        return option;
      });

    const periodSelect = new StringSelectMenuBuilder()
      .setCustomId(sessions.buildCustomId(session, 'cart_period'))
      .setPlaceholder(purchaseLabel(cart.periodDays))
      .addOptions(periodOptions);

    components.push(
      new ActionRowBuilder<MessageActionRowComponentBuilder>().addComponents(periodSelect),
    );
  }

  if (cart.availableAddons.length > 0) {
    const addonOptions = cart.availableAddons.slice(0, 25).map((addon) => {
      const option = new StringSelectMenuOptionBuilder()
        .setLabel(`[ADICIONAL] ${addon.name}`.slice(0, 100))
        .setDescription(`Valor: ${formatMoney(addon.amountInCents)}`)
        .setValue(addon.id)
        .setDefault(selectedAddonIds.has(addon.id));
      const emoji = parseCustomEmoji(brand.emojis.settings ?? '🔧');
      if (emoji) option.setEmoji(emoji);
      return option;
    });

    const addonSelect = new StringSelectMenuBuilder()
      .setCustomId(sessions.buildCustomId(session, 'cart_addons'))
      .setPlaceholder('Selecione um adicional desejado')
      .setMinValues(0)
      .setMaxValues(Math.min(25, cart.availableAddons.length))
      .addOptions(addonOptions);

    components.push(
      new ActionRowBuilder<MessageActionRowComponentBuilder>().addComponents(addonSelect),
    );
  }

  components.push(
    row(
      button(
        sessions.buildCustomId(session, 'generate_pix'),
        'Finalizar Compra',
        ButtonStyle.Success,
        brand.emojis.checkout,
      ),
      button(sessions.buildCustomId(session, 'cancel_cart'), 'Cancelar Compra', ButtonStyle.Danger),
    ),
  );

  return {
    content: null as unknown as string,
    embeds: [embed],
    components,
  };
}

export function paymentProcessingPanel(brand?: BrandConfig): BaseMessageOptions {
  return {
    content: `${
      brand?.emojis.loading ?? '◔'
    } Aguarde um momento, estamos processando seu pagamento...`,
    embeds: [],
    components: [],
  };
}

export function pixPanel(
  brand: BrandConfig,
  session: { id: string; version: number },
  sessions: SessionService,
): BaseMessageOptions {
  void brand;

  return {
    content: [
      '## Leia as informações abaixo para concluir o pagamento:',
      '',
      '• Leia o QR Code abaixo ou use o Código QR para efetuar o pagamento;',
      '• Após o pagamento, aguarde até no máximo **10 segundo(s)** para a identificação automática;',
      '• Não feche este carrinho antes da conclusão do pedido.',
    ].join('\n'),
    embeds: [],
    components: [
      row(
        button(
          sessions.buildCustomId(session, 'copy_pix'),
          'Copiar Código QR',
          ButtonStyle.Secondary,
          brand.emojis.pix,
        ),
        button(sessions.buildCustomId(session, 'cancel_payment'), 'Cancelar', ButtonStyle.Danger),
      ),
    ],
  };
}

export function paymentFinalPanel(
  brand: BrandConfig,
  status: 'APPROVED' | 'CANCELLED' | 'EXPIRED' | 'ERROR',
): BaseMessageOptions {
  const contentByStatus: Record<typeof status, string> = {
    APPROVED: `${brand.emojis.success ?? '✓'} Pagamento aprovado com sucesso!`,

    CANCELLED: `${brand.emojis.paymentCancelled ?? '✕'} Pagamento cancelado com sucesso!`,

    EXPIRED: '⌛ Este pagamento expirou.',

    ERROR: `${brand.emojis.error ?? '✕'} Não foi possível gerar o pagamento neste momento.`,
  };

  return {
    content: contentByStatus[status],
    embeds: [],
    components: [],
  };
}
