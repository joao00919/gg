import { EmbedBuilder, type BaseMessageOptions } from 'discord.js';
import type { BrandConfig } from '../../config/brand.js';

function removeLegacyLoadingPrefix(message: string): string {
  return message.replace(/^◔\s*/, '').trim();
}

export function loadingText(brand: BrandConfig, message = 'Carregando...'): string {
  return `${brand.emojis.loading ?? '◔'} ${removeLegacyLoadingPrefix(message)}`;
}

/** Mensagens tradicionais: nenhuma tela deste fluxo usa Components V2. */
export function loadingPanel(brand: BrandConfig, message = 'Carregando...'): BaseMessageOptions {
  return { content: loadingText(brand, message), embeds: [], components: [] };
}

export function successPanel(brand: BrandConfig, message: string): BaseMessageOptions {
  return {
    content: null as unknown as string,
    embeds: [
      new EmbedBuilder()
        .setColor(brand.primaryColor)
        .setDescription(`${brand.emojis.success ?? '✓'} ${message}`),
    ],
    components: [],
  };
}

export function errorPanel(brand: BrandConfig, message: string): BaseMessageOptions {
  return {
    content: null as unknown as string,
    embeds: [
      new EmbedBuilder()
        .setColor(0xed4245)
        .setDescription(
          `${brand.emojis.error ?? '✕'} Não foi possível concluir a ação.\n\n${message}`,
        ),
    ],
    components: [],
  };
}

export function plainLoadingMessage(
  brand: BrandConfig,
  message = 'Carregando...',
): BaseMessageOptions {
  return { content: loadingText(brand, message), embeds: [], components: [] };
}

export function plainSuccessMessage(message: string): BaseMessageOptions {
  return { content: `✓ ${message}`, embeds: [], components: [] };
}

export function plainErrorMessage(message: string): BaseMessageOptions {
  return {
    content: `Não foi possível concluir a ação.\n\n${message}`,
    embeds: [],
    components: [],
  };
}
