import {
  ActionRowBuilder,
  ButtonStyle,
  EmbedBuilder,
  StringSelectMenuBuilder,
  StringSelectMenuOptionBuilder,
  type BaseMessageOptions,
  type MessageActionRowComponentBuilder,
} from 'discord.js';
import type {
  Addon,
  Application,
  ApplicationAddon,
  License,
  Payment,
  Plan,
  PlanAddon,
  PlanPrice,
} from '@prisma/client';
import type { BrandConfig } from '../../config/brand.js';
import type { SessionService } from '../../services/sessions/session-service.js';
import { formatMoney } from '../../utils/money.js';
import { formatDateTime, formatRemaining } from '../../utils/time.js';
import { button, linkButton, parseCustomEmoji, row } from '../components/helpers.js';

export type AppSummary = Application & {
  plan: Plan;
  license: License | null;
  payments: Payment[];
};

type ManagedApplication = Application & {
  owner: { discordId: string; wallet?: { balanceInCents: number } | null };
  plan: Plan & {
    prices: PlanPrice[];
    addons: (PlanAddon & { addon: Addon })[];
  };
  license: License | null;
  instances: { guildId: string; active: boolean }[];
  addons: (ApplicationAddon & { addon: Addon })[];
  payments: Payment[];
};

function greeting(): string {
  const hour = new Date().getHours();
  if (hour < 12) return 'Bom dia';
  if (hour < 18) return 'Boa tarde';
  return 'Boa noite';
}

function dateLong(date: Date): string {
  return new Intl.DateTimeFormat('pt-BR', {
    day: '2-digit',
    month: 'long',
    year: 'numeric',
  }).format(date);
}

function onlineText(application: ManagedApplication): string {
  if (application.status === 'ONLINE') {
    const since = application.lastRestartAt ?? application.updatedAt;
    const milliseconds = Math.max(0, Date.now() - since.getTime());
    const days = Math.floor(milliseconds / 86_400_000);
    const hours = Math.floor((milliseconds % 86_400_000) / 3_600_000);
    return `Rodando há ${days}d ${hours}h`;
  }
  if (application.status === 'INSTALLING' || application.status === 'PENDING_SETUP') {
    return 'Em configuração';
  }
  if (application.status === 'SUSPENDED' || application.status === 'EXPIRED') {
    return 'Aplicação suspensa';
  }
  if (application.status === 'ERROR') return 'Erro na aplicação';
  return 'Aplicação desligada';
}

function brandedEmbed(brand: BrandConfig): EmbedBuilder {
  const embed = new EmbedBuilder().setColor(brand.primaryColor);
  if (brand.logoUrl) embed.setThumbnail(brand.logoUrl);
  return embed;
}

function option(
  label: string,
  description: string,
  value: string,
  emoji?: string,
): StringSelectMenuOptionBuilder {
  const item = new StringSelectMenuOptionBuilder()
    .setLabel(label.slice(0, 100))
    .setDescription(description.slice(0, 100))
    .setValue(value);
  const parsed = parseCustomEmoji(emoji);
  if (parsed) item.setEmoji(parsed);
  return item;
}

export function appsPanel(
  brand: BrandConfig,
  username: string,
  applications: AppSummary[],
  session: { id: string; version: number },
  sessions: SessionService,
  _userId: string,
  salesChannelUrl?: string,
): BaseMessageOptions {
  const active = applications.filter((app) => app.status === 'ONLINE').length;
  const expired = applications.filter((app) => app.status === 'EXPIRED').length;
  const suspended = applications.filter((app) => app.status === 'SUSPENDED').length;
  const embed = brandedEmbed(brand)
    .setTitle(`${brand.emojis.app ?? '🤖'} Minhas aplicações`)
    .setDescription(
      applications.length
        ? `Olá, **${username}**. Selecione abaixo a aplicação que deseja gerenciar.`
        : `Olá, **${username}**. Você ainda não possui aplicações. Realize uma compra para liberar seu acesso automaticamente.`,
    )
    .addFields(
      { name: 'Total', value: `\`${applications.length}\``, inline: true },
      { name: 'Ativas', value: `\`${active}\``, inline: true },
      { name: 'Vencidas', value: `\`${expired}\``, inline: true },
      { name: 'Suspensas', value: `\`${suspended}\``, inline: true },
    )
    .setFooter({ text: `${brand.name} • Gerenciamento de aplicações` });

  const components: ActionRowBuilder<MessageActionRowComponentBuilder>[] = [];
  if (!applications.length) {
    if (salesChannelUrl) components.push(row(linkButton('Ir para vendas', salesChannelUrl)));
    return { content: null as unknown as string, embeds: [embed], components };
  }

  const select = new StringSelectMenuBuilder()
    .setCustomId(sessions.buildCustomId(session, 'apps_select'))
    .setPlaceholder('Selecione uma aplicação')
    .addOptions(
      applications.slice(0, 25).map((application) => {
        const expires = application.license
          ? application.license.expiresAt.toLocaleDateString('pt-BR')
          : 'sem licença';
        return option(
          application.name,
          `${application.plan.name} • ${application.status} • vence ${expires}`,
          application.id,
          '🤖',
        );
      }),
    );
  components.push(new ActionRowBuilder<MessageActionRowComponentBuilder>().addComponents(select));
  return { content: null as unknown as string, embeds: [embed], components };
}

export function applicationPanel(
  brand: BrandConfig,
  application: ManagedApplication,
  session: { id: string; version: number },
  sessions: SessionService,
  username: string,
): BaseMessageOptions {
  const license = application.license;
  const activeAddons = application.addons.filter((item) => item.status === 'ACTIVE');
  const appLink = application.discordApplicationId
    ? `https://discord.com/oauth2/authorize?client_id=${application.discordApplicationId}&permissions=0&scope=bot%20applications.commands`
    : undefined;
  const onlineEmoji =
    application.status === 'ONLINE' ? (brand.emojis.online ?? '📶') : (brand.emojis.off ?? '📴');
  const planBenefits = brand.dashboardUrl ? ` [Vantagens](${brand.dashboardUrl})` : '';

  const embed = brandedEmbed(brand)
    .setTitle(`${brand.emojis.app ?? '🤖'} Gerenciamento - ${application.plan.name}`)
    .setDescription(
      [
        `**${greeting()}, ${username}!**`,
        `Gerencie sua aplicação **${application.name}** de forma simples e eficiente.`,
        application.bio ? `\n${application.bio}` : '',
      ].join('\n'),
    )
    .addFields(
      {
        name: `${brand.emojis.folder ?? brand.emojis.member ?? '👤'} Nome`,
        value: application.name,
        inline: true,
      },
      {
        name: `${brand.emojis.card ?? '📅'} Expira em`,
        value: license ? dateLong(license.expiresAt) : 'Sem licença',
        inline: true,
      },
      { name: `${onlineEmoji} Online`, value: onlineText(application), inline: true },
      {
        name: `${brand.emojis.cardbox ?? '▣'} ID da aplicação:`,
        value: `\`${application.id}\``,
        inline: true,
      },
      {
        name: `${brand.emojis.card ?? '💳'} Plano`,
        value: `\`${application.plan.name}\`${planBenefits}`,
        inline: true,
      },
      {
        name: `${brand.emojis.save ?? '🔐'} Licença`,
        value: `\`${license?.status ?? 'Não criada'}\``,
        inline: true,
      },
    )
    .setFooter({ text: `${brand.name} • ${application.id.slice(0, 12)}` });

  if (activeAddons.length) {
    embed.addFields({
      name: 'Adicionais ativos',
      value: activeAddons.map((item) => `• ${item.addon.name}`).join('\n'),
      inline: false,
    });
  }

  const components: ActionRowBuilder<MessageActionRowComponentBuilder>[] = [
    row(
      button(
        sessions.buildCustomId(session, 'app_start'),
        'Iniciar',
        ButtonStyle.Success,
        brand.emojis.play,
      ),
      button(
        sessions.buildCustomId(session, 'app_restart'),
        'Reiniciar',
        ButtonStyle.Primary,
        brand.emojis.reload,
      ),
      button(
        sessions.buildCustomId(session, 'app_stop'),
        'Parar',
        ButtonStyle.Danger,
        brand.emojis.pause,
      ),
    ),
  ];

  const manageSelect = new StringSelectMenuBuilder()
    .setCustomId(sessions.buildCustomId(session, 'app_manage_select'))
    .setPlaceholder('Realize ações em sua aplicação.')
    .addOptions(
      option(
        'Gerenciar renovação',
        'Renove ou altere o período da aplicação.',
        'renewal',
        brand.emojis.wallet,
      ),
      option(
        'Alterar nome do BOT',
        'Modifique o nome exibido da aplicação.',
        'rename',
        brand.emojis.trusted ?? brand.emojis.member,
      ),
      option('Alterar BIO do BOT', 'Edite a descrição pública do bot.', 'bio', brand.emojis.save),
      option(
        'Alterar token do BOT',
        'Atualize o token de forma criptografada.',
        'token',
        brand.emojis.config,
      ),
      option(
        'Alterar pessoa de confiança',
        'Defina uma pessoa autorizada para suporte.',
        'trusted_person',
        brand.emojis.trusted,
      ),
      option(
        'Gerenciar equipe',
        'Gerencie pessoas com acesso à aplicação.',
        'team',
        brand.emojis.team,
      ),
      option(
        'Gerenciar servidores',
        'Visualize servidores autorizados e convide o bot.',
        'servers',
        brand.emojis.servers,
      ),
      option(
        'Transferir posse',
        'Transfira a aplicação para outro usuário.',
        'transfer',
        brand.emojis.transfer,
      ),
      option(
        'Gerenciar licença',
        'Consulte e regenere a licença da aplicação.',
        'license',
        brand.emojis.cardbox,
      ),
      option(
        'Deletar aplicação permanente',
        'Remove a aplicação após confirmação.',
        'delete',
        brand.emojis.delete,
      ),
    );
  components.push(
    new ActionRowBuilder<MessageActionRowComponentBuilder>().addComponents(manageSelect),
  );

  const availableAddons = application.plan.addons
    .filter(
      (relation) => !activeAddons.some((activeAddon) => activeAddon.addonId === relation.addonId),
    )
    .slice(0, 25);
  if (availableAddons.length) {
    const addonSelect = new StringSelectMenuBuilder()
      .setCustomId(sessions.buildCustomId(session, 'app_addon_select'))
      .setPlaceholder('Adquira um adicional para sua aplicação')
      .addOptions(
        availableAddons.map(({ addon }) =>
          option(
            `[ADICIONAL] ${addon.name}`,
            `Valor: ${formatMoney(addon.amountInCents)}`,
            addon.id,
            brand.emojis.config,
          ),
        ),
      );
    components.push(
      new ActionRowBuilder<MessageActionRowComponentBuilder>().addComponents(addonSelect),
    );
  }

  if (appLink)
    components.push(
      row(linkButton('Adicionar aplicação', appLink, brand.emojis.plus ?? brand.emojis.rocket)),
    );
  return { content: null as unknown as string, embeds: [embed], components };
}

export function licensePanel(
  brand: BrandConfig,
  application: ManagedApplication,
  session: { id: string; version: number },
  sessions: SessionService,
): BaseMessageOptions {
  const license = application.license;
  const embed = brandedEmbed(brand).setTitle(`🔐 Licença - ${application.name}`);
  if (!license) {
    embed.setDescription('Nenhuma licença foi encontrada para esta aplicação.');
  } else {
    embed.addFields(
      { name: 'Chave', value: `\`${license.keyPrefix}••••-••••-••••\``, inline: false },
      { name: 'Status', value: `\`${license.status}\``, inline: true },
      { name: 'Plano', value: `\`${application.plan.name}\``, inline: true },
      {
        name: 'Ativação',
        value: license.activatedAt ? formatDateTime(license.activatedAt) : 'Pendente',
        inline: true,
      },
      { name: 'Vencimento', value: formatDateTime(license.expiresAt), inline: true },
      { name: 'Tempo restante', value: formatRemaining(license.expiresAt), inline: true },
      {
        name: 'Servidores utilizados',
        value: `${application.instances.filter((item) => item.active).length}/${license.serverLimit}`,
        inline: true,
      },
      {
        name: 'Última validação',
        value: license.lastValidatedAt ? formatDateTime(license.lastValidatedAt) : 'Nunca',
        inline: true,
      },
      { name: 'Validações', value: String(license.validationCount), inline: true },
      {
        name: 'Renovação automática',
        value: license.autoRenew ? 'Ativada' : 'Desativada',
        inline: true,
      },
    );
  }
  return {
    content: null as unknown as string,
    embeds: [embed],
    components: [
      row(
        button(sessions.buildCustomId(session, 'renew'), 'Renovar licença', ButtonStyle.Success),
        button(
          sessions.buildCustomId(session, 'regenerate'),
          'Regenerar chave',
          ButtonStyle.Danger,
        ),
        button(sessions.buildCustomId(session, 'back_app'), 'Voltar', ButtonStyle.Secondary),
      ),
    ],
  };
}
