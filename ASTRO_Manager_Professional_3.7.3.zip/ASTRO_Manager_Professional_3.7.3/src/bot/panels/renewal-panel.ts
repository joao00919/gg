import {
  ActionRowBuilder,
  ButtonStyle,
  EmbedBuilder,
  StringSelectMenuBuilder,
  StringSelectMenuOptionBuilder,
  type BaseMessageOptions,
  type MessageActionRowComponentBuilder,
} from 'discord.js';
import type { Application, License, Plan, PlanPrice } from '@prisma/client';
import type { BrandConfig } from '../../config/brand.js';
import type { SessionService } from '../../services/sessions/session-service.js';
import { formatMoney } from '../../utils/money.js';
import { formatDateTime, calculateRenewalExpiry } from '../../utils/time.js';
import { button, row } from '../components/helpers.js';

export function renewalPeriodPanel(
  brand: BrandConfig,
  application: Application & { plan: Plan & { prices: PlanPrice[] }; license: License | null },
  session: { id: string; version: number },
  sessions: SessionService,
): BaseMessageOptions {
  const select = new StringSelectMenuBuilder()
    .setCustomId(sessions.buildCustomId(session, 'renew_period'))
    .setPlaceholder('Escolha o período')
    .addOptions(
      application.plan.prices
        .filter((price) => price.active)
        .slice(0, 25)
        .map((price) =>
          new StringSelectMenuOptionBuilder()
            .setLabel(price.label || `${price.periodDays} dias`)
            .setDescription(formatMoney(Math.max(50, price.amountInCents - price.discountInCents)))
            .setValue(String(price.periodDays)),
        ),
    );
  return {
    content: null as unknown as string,
    embeds: [
      new EmbedBuilder()
        .setColor(brand.primaryColor)
        .setTitle(`Renovar ${application.name}`)
        .setDescription('Selecione o período que deseja adicionar à licença.'),
    ],
    components: [
      new ActionRowBuilder<MessageActionRowComponentBuilder>().addComponents(select),
      row(button(sessions.buildCustomId(session, 'back_app'), 'Voltar', ButtonStyle.Secondary)),
    ],
  };
}

export function renewalSummaryPanel(
  brand: BrandConfig,
  application: Application & { plan: Plan; license: License | null },
  price: PlanPrice,
  session: { id: string; version: number },
  sessions: SessionService,
): BaseMessageOptions {
  const approvedAt = new Date();
  const current = application.license?.expiresAt ?? approvedAt;
  const next = calculateRenewalExpiry(current, approvedAt, price.periodDays);
  const finalValue = Math.max(50, price.amountInCents - price.discountInCents);
  return {
    content: null as unknown as string,
    embeds: [
      new EmbedBuilder()
        .setColor(brand.primaryColor)
        .setTitle('Resumo da renovação')
        .addFields(
          { name: 'Aplicação', value: application.name, inline: true },
          { name: 'Plano', value: application.plan.name, inline: true },
          { name: 'Período', value: `${price.periodDays} dias`, inline: true },
          { name: 'Vencimento atual', value: formatDateTime(current), inline: true },
          { name: 'Novo vencimento', value: formatDateTime(next), inline: true },
          { name: 'Valor original', value: formatMoney(price.amountInCents), inline: true },
          { name: 'Desconto', value: formatMoney(price.discountInCents), inline: true },
          { name: 'Valor final', value: formatMoney(finalValue), inline: true },
        ),
    ],
    components: [
      row(
        button(
          sessions.buildCustomId(session, `confirm_${price.periodDays}`),
          'Confirmar e abrir carrinho',
          ButtonStyle.Success,
        ),
        button(sessions.buildCustomId(session, 'renew'), 'Voltar', ButtonStyle.Secondary),
      ),
    ],
  };
}

export function renewalManagementPanel(
  brand: BrandConfig,
  application: Application & { plan: Plan & { prices: PlanPrice[] }; license: License | null },
  walletBalanceInCents: number,
  session: { id: string; version: number },
  sessions: SessionService,
): BaseMessageOptions {
  const prices = application.plan.prices
    .filter((price) => price.active)
    .sort((a, b) => a.periodDays - b.periodDays);
  const preferred =
    prices.find((price) => price.periodDays === 30) ??
    prices.find((price) => price.periodDays === application.autoRenewPeriodDays) ??
    prices[0];
  const amount = preferred ? Math.max(50, preferred.amountInCents - preferred.discountInCents) : 0;
  const expiry = application.license?.expiresAt;
  const autoRenew = Boolean(application.autoRenew && application.license?.autoRenew);

  const embed = new EmbedBuilder()
    .setColor(brand.primaryColor)
    .setTitle(`${brand.emojis.wallet ?? '💳'} Renovação - ${application.plan.name}`)
    .setDescription(
      [
        `Gerencie a renovação da aplicação **${application.name}** de forma simples e eficiente.`,
        '',
        `A renovação automática usa o saldo disponível na **ASTRO WALLET**.`,
      ].join('\n'),
    )
    .addFields(
      {
        name: `${brand.emojis.card ?? '📅'} Expira em`,
        value: expiry ? formatDateTime(expiry) : 'Sem licença',
        inline: true,
      },
      {
        name: `${brand.emojis.wallet ?? '💰'} Valor disponível`,
        value: `\`${formatMoney(walletBalanceInCents)}\``,
        inline: true,
      },
      {
        name: `${brand.emojis.power ?? '⚡'} Renovação automática`,
        value: `\`${autoRenew ? 'Ligado' : 'Desligado'}\``,
        inline: true,
      },
    );

  const renewButton = button(
    sessions.buildCustomId(session, 'quick_renew_30'),
    preferred ? `Renovar ${preferred.periodDays}d - ${formatMoney(amount)}` : 'Renovar',
    ButtonStyle.Secondary,
    brand.emojis.wallet,
  ).setDisabled(!preferred);

  return {
    content: null as unknown as string,
    embeds: [embed],
    components: [
      row(
        renewButton,
        button(
          sessions.buildCustomId(session, 'toggle_autorenew'),
          autoRenew ? 'Desativar Automático' : 'Renovar Automático',
          autoRenew ? ButtonStyle.Success : ButtonStyle.Secondary,
          brand.emojis.power,
        ),
        button(sessions.buildCustomId(session, 'back_app'), 'Voltar', ButtonStyle.Secondary),
      ),
    ],
  };
}
