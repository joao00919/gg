import {
  ActionRowBuilder,
  EmbedBuilder,
  StringSelectMenuBuilder,
  StringSelectMenuOptionBuilder,
  type BaseMessageOptions,
  type MessageActionRowComponentBuilder,
} from 'discord.js';
import type { BrandConfig } from '../../config/brand.js';
import type { PlanWithStore } from '../../services/plans/plan-service.js';
import { linkButton, parseCustomEmoji, row } from '../components/helpers.js';

function applyBrand(embed: EmbedBuilder, brand: BrandConfig): EmbedBuilder {
  embed.setColor(brand.primaryColor);
  if (brand.logoUrl) embed.setThumbnail(brand.logoUrl);
  return embed.setFooter({ text: `${brand.name} • Simplicidade e eficiência` });
}

export function commandsPublicPanel(brand: BrandConfig): BaseMessageOptions {
  const robot = brand.emojis.app ?? '🤖';
  const embed = applyBrand(
    new EmbedBuilder()
      .setTitle(`Central de Comandos - ${brand.name}`)
      .setDescription(
        [
          `Aqui estão os comandos disponíveis para gerenciar seus serviços na **${brand.name}**. Embora seja possível utilizá-los diretamente por aqui, recomendamos fortemente o uso da nossa Dashboard para uma experiência mais completa, visual e intuitiva.`,
          '',
          '**Comandos Disponíveis**',
          `${robot} \`/apps\` - Exibe a lista de aplicativos disponíveis.`,
          `${brand.emojis.dollar ?? '💵'} \`/renovar\` - Renova serviços ou bots ativos.`,
          `${brand.emojis.restart ?? '♻️'} \`/restore\` - Recupera bots perdidos ou inativos.`,
          `${brand.emojis.web ?? '🌐'} \`/imagem_url\` - Não perca suas imagens.`,
          `${brand.emojis.wallet ?? '💳'} \`/wallet\` - Consulta o saldo e o histórico da ASTRO WALLET.`,
        ].join('\n'),
      ),
    brand,
  );
  const banner = brand.commandsBannerUrl ?? brand.bannerUrl;
  if (banner) embed.setImage(banner);

  const components: ActionRowBuilder<MessageActionRowComponentBuilder>[] = [];
  if (brand.dashboardUrl) {
    components.push(
      row(linkButton('Dashboard OAuth2', brand.dashboardUrl, brand.emojis.web ?? '🌐')),
    );
  }
  return { content: null as unknown as string, embeds: [embed], components };
}

export function storePublicPanel(brand: BrandConfig, plans: PlanWithStore[]): BaseMessageOptions {
  const storefront = plans.filter((plan) => ['vendas', 'ticket'].includes(plan.slug));
  const productLines = storefront
    .map((plan) => {
      const emoji = plan.slug === 'ticket' ? brand.emojis.ticket : brand.emojis.app;
      return `${emoji ?? '🤖'} **${plan.storeDescription ?? `Bot de ${plan.name}`}:** ${plan.description}`;
    })
    .join('\n');

  const embed = applyBrand(
    new EmbedBuilder()
      .setTitle(`Painel de Aquisição - ${brand.name}`)
      .setDescription(
        [
          'Bem-vindo(a) à nossa Central de Compras. Abaixo, você pode escolher o bot que deseja adquirir. Selecione um produto no menu para prosseguir com a compra.',
          '',
          '**O que oferecemos**',
          'Conheça nossos produtos e escolha a solução ideal para o seu negócio ou comunidade no Discord:',
          '',
          '**Produtos Disponíveis**',
          productLines || 'Nenhum produto está disponível no momento.',
        ].join('\n'),
      ),
    brand,
  );
  const banner = brand.storeBannerUrl ?? brand.bannerUrl;
  if (banner) embed.setImage(banner);

  const components: ActionRowBuilder<MessageActionRowComponentBuilder>[] = [];
  if (storefront.length) {
    const select = new StringSelectMenuBuilder()
      .setCustomId('vision:store:product')
      .setPlaceholder('Escolha o bot que deseja adquirir')
      .addOptions(
        storefront.slice(0, 25).map((plan) => {
          const option = new StringSelectMenuOptionBuilder()
            .setLabel((plan.storeDescription ?? `Bot de ${plan.name}`).slice(0, 100))
            .setDescription(plan.description.slice(0, 100))
            .setValue(plan.id);
          const emoji = parseCustomEmoji(
            plan.slug === 'ticket' ? brand.emojis.ticket : brand.emojis.app,
          );
          if (emoji) option.setEmoji(emoji);
          return option;
        }),
      );
    components.push(new ActionRowBuilder<MessageActionRowComponentBuilder>().addComponents(select));
  }
  if (brand.previewBotsUrl) {
    components.push(
      row(linkButton('Preview Bots', brand.previewBotsUrl, brand.emojis.web ?? '🌐')),
    );
  }
  return { content: null as unknown as string, embeds: [embed], components };
}
