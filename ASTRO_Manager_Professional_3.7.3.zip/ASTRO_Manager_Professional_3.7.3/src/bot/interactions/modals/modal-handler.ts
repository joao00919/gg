import type { ModalSubmitInteraction } from 'discord.js';
import type { AppContext } from '../../../context.js';
import { encryptText } from '../../../utils/crypto.js';
import { DomainError } from '../../../utils/errors.js';
import { applicationPanel } from '../../panels/apps-panel.js';

export async function handleModal(
  interaction: ModalSubmitInteraction,
  context: AppContext,
): Promise<void> {
  await interaction.deferUpdate();
  const validated = await context.sessions.validate(interaction.customId, interaction.user.id);
  if (!validated.entityId) throw new DomainError('Formulário inválido ou expirado.', 'MODAL_INVALID');
  const application = await context.applications.getOwned(validated.entityId, interaction.user.id);

  if (validated.action === 'rename_modal') {
    const name = interaction.fields.getTextInputValue('name').trim();
    if (name.length < 2) throw new DomainError('O nome precisa ter ao menos 2 caracteres.', 'NAME_REQUIRED');
    await context.prisma.application.update({ where: { id: application.id }, data: { name } });
    await context.audit.record({ actorId: interaction.user.id, actorType: 'USER', action: 'APPLICATION_RENAME', entityType: 'Application', entityId: application.id, metadataSafe: { newName: name } });
  } else if (validated.action === 'bio_modal') {
    const bio = interaction.fields.getTextInputValue('bio').trim();
    await context.prisma.application.update({ where: { id: application.id }, data: { bio: bio || null } });
    await context.audit.record({ actorId: interaction.user.id, actorType: 'USER', action: 'APPLICATION_BIO_UPDATE', entityType: 'Application', entityId: application.id, metadataSafe: { hasBio: Boolean(bio) } });
  } else if (validated.action === 'token_modal') {
    const token = interaction.fields.getTextInputValue('token').trim();
    if (token.length < 30) throw new DomainError('O token informado é inválido.', 'BOT_TOKEN_INVALID');
    await validateDiscordBotToken(token);
    await context.prisma.application.update({ where: { id: application.id }, data: { botTokenEncrypted: encryptText(token, context.env.ENCRYPTION_KEY) } });
    await context.audit.record({ actorId: interaction.user.id, actorType: 'USER', action: 'APPLICATION_TOKEN_UPDATE', entityType: 'Application', entityId: application.id, metadataSafe: { validated: true } });
  } else if (validated.action === 'trusted_modal') {
    const trustedUserId = interaction.fields.getTextInputValue('trusted_user_id').trim();
    if (trustedUserId && !/^\d{17,20}$/.test(trustedUserId)) throw new DomainError('ID da pessoa de confiança inválido.', 'DISCORD_ID_INVALID');
    if (trustedUserId === interaction.user.id) throw new DomainError('Você já é o proprietário. Informe outra pessoa ou deixe vazio.', 'TRUSTED_USER_IS_OWNER');
    await context.prisma.application.update({ where: { id: application.id }, data: { trustedUserId: trustedUserId || null } });
    await context.audit.record({ actorId: interaction.user.id, actorType: 'USER', action: 'APPLICATION_TRUSTED_USER_UPDATE', entityType: 'Application', entityId: application.id, metadataSafe: { configured: Boolean(trustedUserId) } });
  } else if (validated.action === 'settings_modal') {
    const discordApplicationId = interaction.fields.getTextInputValue('discord_application_id').trim();
    const guildId = interaction.fields.getTextInputValue('guild_id').trim();
    if (discordApplicationId && !/^\d{17,20}$/.test(discordApplicationId)) throw new DomainError('Discord Application ID inválido.', 'DISCORD_ID_INVALID');
    if (guildId && !/^\d{17,20}$/.test(guildId)) throw new DomainError('ID do servidor inválido.', 'GUILD_ID_INVALID');
    await context.prisma.$transaction(async (tx) => {
      await tx.application.update({ where: { id: application.id }, data: { discordApplicationId: discordApplicationId || null, linkedGuildId: guildId || null } });
      if (guildId) await tx.applicationInstance.upsert({ where: { applicationId_guildId: { applicationId: application.id, guildId } }, update: { active: true }, create: { applicationId: application.id, guildId } });
    });
    await context.audit.record({ actorId: interaction.user.id, actorType: 'USER', action: 'APPLICATION_SETTINGS_UPDATE', entityType: 'Application', entityId: application.id });
  } else {
    throw new DomainError('Formulário desconhecido.', 'MODAL_UNKNOWN');
  }

  const updated = await context.applications.getOwned(application.id, interaction.user.id);
  const session = await context.sessions.create(interaction.user.id, 'APPLICATION', 'Application', application.id);
  await interaction.editReply(applicationPanel(context.brand, updated, session, context.sessions, interaction.user.username));
}

async function validateDiscordBotToken(token: string): Promise<void> {
  const controller = new AbortController();
  const timeout = setTimeout(() => controller.abort(), 8_000);
  try {
    const response = await fetch('https://discord.com/api/v10/users/@me', {
      headers: { Authorization: `Bot ${token}` },
      signal: controller.signal,
    });
    if (!response.ok) throw new DomainError('O Discord recusou o token informado.', 'BOT_TOKEN_REJECTED');
    const body = (await response.json()) as { bot?: boolean };
    if (!body.bot) throw new DomainError('O token precisa pertencer a um bot.', 'BOT_TOKEN_NOT_BOT');
  } catch (error) {
    if (error instanceof DomainError) throw error;
    throw new DomainError('Não foi possível validar o token no Discord neste momento.', 'BOT_TOKEN_VALIDATION_FAILED');
  } finally {
    clearTimeout(timeout);
  }
}
