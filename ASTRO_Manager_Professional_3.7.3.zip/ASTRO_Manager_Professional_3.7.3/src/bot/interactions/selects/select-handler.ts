import {
  ActionRowBuilder,
  MessageFlags,
  ModalBuilder,
  TextInputBuilder,
  TextInputStyle,
  type StringSelectMenuInteraction,
  type UserSelectMenuInteraction,
} from 'discord.js';
import type { AppContext } from '../../../context.js';
import { DomainError } from '../../../utils/errors.js';
import { buildCartView, openCartFlow } from '../../flows/cart-flow.js';
import { applicationPanel, licensePanel } from '../../panels/apps-panel.js';
import {
  confirmationPanel,
  informationPanel,
  transferSelectPanel,
} from '../../panels/action-panels.js';
import { plainLoadingMessage } from '../../panels/common-panels.js';
import { cartPanel } from '../../panels/payment-panel.js';
import { renewalManagementPanel } from '../../panels/renewal-panel.js';

export async function handleStringSelect(
  interaction: StringSelectMenuInteraction,
  context: AppContext,
): Promise<void> {
  const selected = interaction.values[0];
  if (!selected) throw new DomainError('Nenhuma opção foi selecionada.', 'SELECT_EMPTY');

  if (interaction.customId === 'vision:store:product') {
    await interaction.reply({
      ...plainLoadingMessage(context.brand),
      flags: MessageFlags.Ephemeral,
    });
    const plan = await context.plans.getStorePlan(selected);
    const periodDays = plan.prices.some(
      (price) => price.periodDays === context.env.DEFAULT_PLAN_PERIOD_DAYS,
    )
      ? context.env.DEFAULT_PLAN_PERIOD_DAYS
      : (plan.prices[0]?.periodDays ?? 30);
    await openCartFlow(interaction, context, {
      kind: 'NEW_APPLICATION',
      planId: plan.id,
      periodDays,
      responseMode: 'reply',
    });
    return;
  }

  const actionHint = interaction.customId.split('.')[1] ?? '';
  const modalSelections = new Set(['rename', 'bio', 'token', 'trusted_person', 'settings']);
  const wantsSeparateEphemeral =
    ['app_addon_select', 'change_plan_select'].includes(actionHint) ||
    (actionHint === 'app_manage_select' && selected === 'renewal');
  const shouldDefer =
    ['apps_select', 'cart_period', 'cart_addons'].includes(actionHint) ||
    (actionHint === 'app_manage_select' &&
      !modalSelections.has(selected) &&
      selected !== 'renewal');

  if (wantsSeparateEphemeral) {
    await interaction.reply({
      ...plainLoadingMessage(context.brand),
      flags: MessageFlags.Ephemeral,
    });
  } else if (shouldDefer) {
    await interaction.deferUpdate();
  }

  const validated = await context.sessions.validate(interaction.customId, interaction.user.id);

  if (validated.action === 'apps_select') {
    const application = await context.applications.getOwned(selected, interaction.user.id);
    const session = await context.sessions.create(
      interaction.user.id,
      'APPLICATION',
      'Application',
      application.id,
    );
    await interaction.editReply(
      applicationPanel(
        context.brand,
        application,
        session,
        context.sessions,
        interaction.user.username,
      ),
    );
    return;
  }

  if (!validated.entityId)
    throw new DomainError('Entidade não associada à sessão.', 'SESSION_ENTITY_MISSING');

  if (validated.action === 'app_manage_select') {
    await handleApplicationManagementSelect(
      interaction,
      context,
      validated.entityId,
      selected,
      shouldDefer,
    );
    return;
  }

  if (validated.action === 'app_addon_select') {
    const application = await context.applications.getOwned(
      validated.entityId,
      interaction.user.id,
    );
    await openCartFlow(interaction, context, {
      kind: 'ADDON',
      planId: application.planId,
      applicationId: application.id,
      periodDays: context.env.DEFAULT_PLAN_PERIOD_DAYS,
      preselectedAddonIds: [selected],
      responseMode: 'update',
    });
    return;
  }

  if (validated.action === 'cart_period') {
    const periodDays = Number(selected);
    if (!Number.isInteger(periodDays) || periodDays <= 0)
      throw new DomainError('Período inválido.', 'INVALID_PERIOD');
    await context.carts.updatePeriod(validated.entityId, interaction.user.id, periodDays);
    const cart = await buildCartView(context, validated.entityId, interaction.user.id);
    const session = await context.sessions.create(
      interaction.user.id,
      'CART',
      'Cart',
      cart.id,
      context.env.PAYMENT_EXPIRATION_MINUTES,
    );
    await interaction.editReply(cartPanel(context.brand, cart, session, context.sessions));
    return;
  }

  if (validated.action === 'cart_addons') {
    await context.carts.updateAddons(validated.entityId, interaction.user.id, interaction.values);
    const cart = await buildCartView(context, validated.entityId, interaction.user.id);
    const session = await context.sessions.create(
      interaction.user.id,
      'CART',
      'Cart',
      cart.id,
      context.env.PAYMENT_EXPIRATION_MINUTES,
    );
    await interaction.editReply(cartPanel(context.brand, cart, session, context.sessions));
    return;
  }

  if (validated.action === 'change_plan_select') {
    const plan = await context.plans.getStorePlan(selected);
    const periodDays = plan.prices.some(
      (price) => price.periodDays === context.env.DEFAULT_PLAN_PERIOD_DAYS,
    )
      ? context.env.DEFAULT_PLAN_PERIOD_DAYS
      : (plan.prices[0]?.periodDays ?? 30);
    await openCartFlow(interaction, context, {
      kind: 'RENEWAL',
      planId: plan.id,
      applicationId: validated.entityId,
      periodDays,
      responseMode: 'update',
    });
    return;
  }

  throw new DomainError('Seleção desconhecida.', 'SELECT_ACTION_UNKNOWN');
}

async function handleApplicationManagementSelect(
  interaction: StringSelectMenuInteraction,
  context: AppContext,
  applicationId: string,
  selected: string,
  deferred: boolean,
): Promise<void> {
  const application = await context.applications.getOwned(applicationId, interaction.user.id);

  if (selected === 'rename') {
    await showSingleFieldModal(interaction, context, {
      kind: 'RENAME_APPLICATION',
      action: 'rename_modal',
      applicationId: application.id,
      title: 'Alterar nome do BOT',
      fieldId: 'name',
      fieldLabel: 'Novo nome do BOT',
      value: application.name,
      maxLength: 100,
    });
    return;
  }
  if (selected === 'bio') {
    await showSingleFieldModal(interaction, context, {
      kind: 'BIO_APPLICATION',
      action: 'bio_modal',
      applicationId: application.id,
      title: 'Alterar BIO do BOT',
      fieldId: 'bio',
      fieldLabel: 'Nova BIO do BOT',
      value: application.bio ?? '',
      maxLength: 300,
      style: TextInputStyle.Paragraph,
      required: false,
    });
    return;
  }
  if (selected === 'token') {
    await showSingleFieldModal(interaction, context, {
      kind: 'TOKEN_APPLICATION',
      action: 'token_modal',
      applicationId: application.id,
      title: 'Alterar token do BOT',
      fieldId: 'token',
      fieldLabel: 'Novo token do BOT',
      value: '',
      maxLength: 200,
      required: true,
      placeholder: 'O token será armazenado criptografado.',
    });
    return;
  }
  if (selected === 'trusted_person') {
    await showSingleFieldModal(interaction, context, {
      kind: 'TRUSTED_APPLICATION',
      action: 'trusted_modal',
      applicationId: application.id,
      title: 'Alterar pessoa de confiança',
      fieldId: 'trusted_user_id',
      fieldLabel: 'ID do usuário de confiança',
      value: application.trustedUserId ?? '',
      maxLength: 20,
      required: false,
      placeholder: 'Deixe vazio para remover.',
    });
    return;
  }
  if (selected === 'renewal') {
    const wallet = await context.wallets.getSummary(interaction.user.id, interaction.user.username);
    const session = await context.sessions.create(
      interaction.user.id,
      'RENEWAL',
      'Application',
      application.id,
    );
    await interaction.editReply(
      renewalManagementPanel(
        context.brand,
        application,
        wallet.balanceInCents,
        session,
        context.sessions,
      ),
    );
    return;
  }
  if (selected === 'license') {
    const session = await context.sessions.create(
      interaction.user.id,
      'LICENSE',
      'Application',
      application.id,
    );
    await interaction.editReply(
      licensePanel(context.brand, application, session, context.sessions),
    );
    return;
  }
  if (selected === 'transfer') {
    const session = await context.sessions.create(
      interaction.user.id,
      'TRANSFER',
      'Application',
      application.id,
    );
    await interaction.editReply(transferSelectPanel(context.brand, session, context.sessions));
    return;
  }
  if (selected === 'delete') {
    const session = await context.sessions.create(
      interaction.user.id,
      'DELETE_APPLICATION',
      'Application',
      application.id,
    );
    await interaction.editReply(
      confirmationPanel(
        context.brand,
        'Deletar aplicação permanente',
        `A aplicação **${application.name}** será removida e deixará de aparecer em \`/apps\`. Esta ação exige confirmação.`,
        context.sessions.buildCustomId(session, 'confirm_delete'),
        context.sessions.buildCustomId(session, 'back_app'),
      ),
    );
    return;
  }

  const message =
    selected === 'team'
      ? application.trustedUserId
        ? `Pessoa de confiança: <@${application.trustedUserId}>
O proprietário continua sendo <@${application.owner.discordId}>.`
        : 'Nenhuma pessoa de confiança está configurada.'
      : application.instances.length
        ? application.instances
            .map(
              (instance) =>
                `• Servidor \`${instance.guildId}\` — ${instance.active ? 'Ativo' : 'Inativo'}`,
            )
            .join('\n')
        : 'Nenhum servidor está vinculado à aplicação. Use o botão abaixo para convidar o bot ao servidor desejado.';
  const session = await context.sessions.create(
    interaction.user.id,
    'APPLICATION',
    'Application',
    application.id,
  );
  const inviteUrl =
    selected === 'servers' && application.discordApplicationId
      ? `https://discord.com/oauth2/authorize?client_id=${application.discordApplicationId}&permissions=0&scope=bot%20applications.commands`
      : undefined;
  const panel = informationPanel(
    context.brand,
    selected === 'team' ? 'Gerenciar equipe' : 'Gerenciar servidores',
    selected === 'servers' && !application.discordApplicationId
      ? `${message}\n\nO ID da aplicação do Discord ainda não foi configurado. Atualize a aplicação antes de gerar o convite.`
      : message,
    context.sessions.buildCustomId(session, 'back_app'),
    inviteUrl
      ? {
          label: 'Adicionar aplicação',
          url: inviteUrl,
          emoji: context.brand.emojis.plus ?? context.brand.emojis.rocket,
        }
      : undefined,
  );
  if (deferred) await interaction.editReply(panel);
  else await interaction.update(panel);
}

interface SingleFieldModalInput {
  kind: string;
  action: string;
  applicationId: string;
  title: string;
  fieldId: string;
  fieldLabel: string;
  value: string;
  maxLength: number;
  style?: TextInputStyle;
  required?: boolean;
  placeholder?: string;
}

async function showSingleFieldModal(
  interaction: StringSelectMenuInteraction,
  context: AppContext,
  input: SingleFieldModalInput,
): Promise<void> {
  const session = await context.sessions.create(
    interaction.user.id,
    input.kind,
    'Application',
    input.applicationId,
  );
  const field = new TextInputBuilder()
    .setCustomId(input.fieldId)
    .setLabel(input.fieldLabel)
    .setStyle(input.style ?? TextInputStyle.Short)
    .setRequired(input.required ?? true)
    .setMaxLength(input.maxLength);
  if (input.value) field.setValue(input.value);
  if (input.placeholder) field.setPlaceholder(input.placeholder);
  await interaction.showModal(
    new ModalBuilder()
      .setCustomId(context.sessions.buildCustomId(session, input.action))
      .setTitle(input.title)
      .addComponents(new ActionRowBuilder<TextInputBuilder>().addComponents(field)),
  );
}

export async function handleUserSelect(
  interaction: UserSelectMenuInteraction,
  context: AppContext,
): Promise<void> {
  await interaction.deferUpdate();
  const validated = await context.sessions.validate(interaction.customId, interaction.user.id);
  if (validated.action !== 'transfer_select' || !validated.entityId) {
    throw new DomainError('Seleção de usuário inválida.', 'TRANSFER_SESSION_INVALID');
  }
  const targetUserId = interaction.values[0];
  if (!targetUserId) {
    throw new DomainError('Novo proprietário não selecionado.', 'TRANSFER_TARGET_MISSING');
  }

  const targetUser = interaction.users.get(targetUserId);
  if (!targetUser) {
    throw new DomainError(
      'Não foi possível localizar o usuário selecionado.',
      'TRANSFER_TARGET_NOT_FOUND',
    );
  }
  if (targetUser.bot || targetUser.system) {
    throw new DomainError(
      'Selecione uma conta de usuário. Bots e contas de sistema não podem receber aplicações.',
      'TRANSFER_TARGET_BOT',
    );
  }

  const eligibility = await context.transfers.assertCanTransfer(
    validated.entityId,
    interaction.user.id,
    targetUserId,
  );
  const safeApplicationName = eligibility.applicationName.replaceAll('`', '');
  const session = await context.sessions.create(
    interaction.user.id,
    `TRANSFER:${targetUserId}`,
    'Application',
    validated.entityId,
    5,
  );
  await interaction.editReply(
    confirmationPanel(
      context.brand,
      'Confirmar transferência de posse',
      [
        `A aplicação \`${safeApplicationName}\` será transferida definitivamente para <@${targetUserId}>.`,
        '',
        'Ao confirmar, você perderá o acesso administrativo, as sessões antigas serão encerradas e uma nova transferência ficará bloqueada por sete dias.',
      ].join('\n'),
      context.sessions.buildCustomId(session, 'confirm_transfer'),
      context.sessions.buildCustomId(session, 'back_app'),
    ),
  );
}
