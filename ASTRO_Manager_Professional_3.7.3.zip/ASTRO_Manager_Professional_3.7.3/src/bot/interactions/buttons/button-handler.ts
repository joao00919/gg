import {
  AttachmentBuilder,
  ButtonStyle,
  EmbedBuilder,
  MessageFlags,
  type ButtonInteraction,
} from 'discord.js';
import type { AppContext } from '../../../context.js';
import { DomainError } from '../../../utils/errors.js';
import { formatDateTime } from '../../../utils/time.js';
import { button, row } from '../../components/helpers.js';
import { deleteCartChannel } from '../../flows/cart-channel-cleanup.js';
import { buildCartView, openCartFlow } from '../../flows/cart-flow.js';
import {
  cartCancellationPanel,
  confirmationPanel,
  planSelectPanel,
} from '../../panels/action-panels.js';
import { applicationPanel, licensePanel } from '../../panels/apps-panel.js';
import {
  loadingPanel,
  plainLoadingMessage,
  plainSuccessMessage,
  successPanel,
} from '../../panels/common-panels.js';
import {
  cartPanel,
  paymentFinalPanel,
  paymentProcessingPanel,
  pixPanel,
} from '../../panels/payment-panel.js';
import { renewalManagementPanel } from '../../panels/renewal-panel.js';

export async function handleButton(
  interaction: ButtonInteraction,
  context: AppContext,
): Promise<void> {
  const actionHint = interaction.customId.split('.')[1] ?? '';
  if (actionHint === 'copy_pix') {
    await interaction.deferReply({ flags: MessageFlags.Ephemeral });
  } else if (actionHint === 'quick_renew_30' || actionHint === 'renew') {
    await interaction.reply({
      ...plainLoadingMessage(context.brand),
      flags: MessageFlags.Ephemeral,
    });
  } else {
    await interaction.deferUpdate();
  }

  const validated = await context.sessions.validate(interaction.customId, interaction.user.id);
  const entityId = validated.entityId;

  switch (validated.action) {
    case 'back_app':
      if (!entityId) throw missingEntity();
      await showApplication(interaction, context, entityId);
      return;
    case 'license':
      if (!entityId) throw missingEntity();
      await showLicense(interaction, context, entityId);
      return;
    case 'app_start':
      if (!entityId) throw missingEntity();
      await runApplicationAction(interaction, context, entityId, 'start');
      return;
    case 'app_restart':
    case 'restart':
      if (!entityId) throw missingEntity();
      await runApplicationAction(interaction, context, entityId, 'restart');
      return;
    case 'app_stop':
      if (!entityId) throw missingEntity();
      await runApplicationAction(interaction, context, entityId, 'stop');
      return;
    case 'quick_renew_30':
      if (!entityId) throw missingEntity();
      await openRenewalCart(interaction, context, entityId, 30);
      return;
    case 'renew':
      if (!entityId) throw missingEntity();
      await openRenewalCart(interaction, context, entityId, context.env.DEFAULT_PLAN_PERIOD_DAYS);
      return;
    case 'change_plan':
      if (!entityId) throw missingEntity();
      await showPlanSelection(interaction, context, entityId);
      return;
    case 'toggle_autorenew':
      if (!entityId) throw missingEntity();
      await toggleAutoRenew(interaction, context, entityId);
      return;
    case 'regenerate':
      if (!entityId) throw missingEntity();
      await confirmRegenerate(interaction, context, entityId);
      return;
    case 'confirm_regenerate':
      if (!entityId) throw missingEntity();
      await regenerateLicense(interaction, context, entityId, validated.sessionId);
      return;
    case 'confirm_transfer':
      if (!entityId) throw missingEntity();
      await confirmTransfer(interaction, context, entityId, validated.kind, validated.sessionId);
      return;
    case 'confirm_delete':
      if (!entityId) throw missingEntity();
      await deleteApplication(interaction, context, entityId, validated.sessionId);
      return;
    case 'generate_pix':
      if (!entityId) throw missingEntity();
      await generatePix(interaction, context, entityId);
      return;
    case 'copy_pix':
      if (!entityId) throw missingEntity();
      await copyPix(interaction, context, entityId);
      return;
    case 'cancel_payment':
      if (!entityId) throw missingEntity();
      await cancelPayment(interaction, context, entityId);
      return;
    case 'cancel_cart':
      if (!entityId) throw missingEntity();
      await showCancelCartConfirmation(interaction, context, entityId);
      return;
    case 'back_cart':
      if (!entityId) throw missingEntity();
      await showCart(interaction, context, entityId);
      return;
    case 'confirm_cancel_cart':
      if (!entityId) throw missingEntity();
      await cancelCart(interaction, context, entityId);
      return;
    case 'status':
      if (!entityId) throw missingEntity();
      await showStatus(interaction, context, entityId);
      return;
    default:
      if (validated.action.startsWith('confirm_') && entityId) {
        const periodDays = Number(validated.action.slice('confirm_'.length));
        if (Number.isInteger(periodDays) && periodDays > 0) {
          await openRenewalCart(interaction, context, entityId, periodDays);
          return;
        }
      }
      throw new DomainError('Ação desconhecida ou indisponível.', 'BUTTON_ACTION_UNKNOWN');
  }
}

async function replaceInteractionMessage(
  interaction: ButtonInteraction,
  payload: NonNullable<Parameters<ButtonInteraction['update']>[0]>,
): Promise<void> {
  if (interaction.deferred || interaction.replied) {
    await interaction.editReply(payload);
    return;
  }
  await interaction.update(payload);
}

function missingEntity(): DomainError {
  return new DomainError('A sessão não possui uma entidade associada.', 'SESSION_ENTITY_MISSING');
}

async function showApplication(
  interaction: ButtonInteraction,
  context: AppContext,
  applicationId: string,
): Promise<void> {
  const application = await context.applications.getOwned(applicationId, interaction.user.id);
  const session = await context.sessions.create(
    interaction.user.id,
    'APPLICATION',
    'Application',
    application.id,
  );
  await replaceInteractionMessage(
    interaction,
    applicationPanel(
      context.brand,
      application,
      session,
      context.sessions,
      interaction.user.username,
    ),
  );
}

async function showLicense(
  interaction: ButtonInteraction,
  context: AppContext,
  applicationId: string,
): Promise<void> {
  const application = await context.applications.getOwned(applicationId, interaction.user.id);
  const session = await context.sessions.create(
    interaction.user.id,
    'LICENSE',
    'Application',
    application.id,
  );
  await replaceInteractionMessage(
    interaction,
    licensePanel(context.brand, application, session, context.sessions),
  );
}

async function runApplicationAction(
  interaction: ButtonInteraction,
  context: AppContext,
  applicationId: string,
  action: 'start' | 'restart' | 'stop',
): Promise<void> {
  const messages = {
    start: '◔ Iniciando a aplicação...',
    restart: '◔ Reiniciando a aplicação...',
    stop: '◔ Parando a aplicação...',
  } as const;
  await replaceInteractionMessage(interaction, loadingPanel(context.brand, messages[action]));
  if (action === 'start') await context.applications.start(applicationId, interaction.user.id);
  if (action === 'restart') await context.applications.restart(applicationId, interaction.user.id);
  if (action === 'stop') await context.applications.stop(applicationId, interaction.user.id);
  const application = await context.applications.getOwned(applicationId, interaction.user.id);
  const session = await context.sessions.create(
    interaction.user.id,
    'APPLICATION',
    'Application',
    application.id,
  );
  await interaction.editReply(
    applicationPanel(
      context.brand,
      application,
      session,
      context.sessions,
      interaction.user.username,
    ),
  );
}

async function openRenewalCart(
  interaction: ButtonInteraction,
  context: AppContext,
  applicationId: string,
  requestedPeriod: number,
): Promise<void> {
  const application = await context.applications.getOwned(applicationId, interaction.user.id);
  const periodDays = application.plan.prices.some((price) => price.periodDays === requestedPeriod)
    ? requestedPeriod
    : (application.plan.prices[0]?.periodDays ?? 30);
  await openCartFlow(interaction, context, {
    kind: 'RENEWAL',
    planId: application.planId,
    applicationId,
    periodDays,
    responseMode: 'update',
  });
}

async function showPlanSelection(
  interaction: ButtonInteraction,
  context: AppContext,
  applicationId: string,
): Promise<void> {
  await context.applications.getOwned(applicationId, interaction.user.id);
  const plans = await context.plans.listActive();
  const session = await context.sessions.create(
    interaction.user.id,
    'PLAN_CHANGE',
    'Application',
    applicationId,
  );
  await replaceInteractionMessage(
    interaction,
    planSelectPanel(context.brand, plans, session, context.sessions),
  );
}

async function toggleAutoRenew(
  interaction: ButtonInteraction,
  context: AppContext,
  applicationId: string,
): Promise<void> {
  const application = await context.applications.getOwned(applicationId, interaction.user.id);
  if (!application.license) throw new DomainError('Licença não encontrada.', 'LICENSE_NOT_FOUND');
  const next = !application.license.autoRenew;
  const preferredPeriod = application.plan.prices.some((price) => price.periodDays === 30)
    ? 30
    : (application.plan.prices[0]?.periodDays ?? context.env.DEFAULT_PLAN_PERIOD_DAYS);
  await context.prisma.$transaction([
    context.prisma.license.update({
      where: { id: application.license.id },
      data: { autoRenew: next },
    }),
    context.prisma.application.update({
      where: { id: applicationId },
      data: { autoRenew: next, autoRenewPeriodDays: preferredPeriod },
    }),
  ]);
  const updated = await context.applications.getOwned(applicationId, interaction.user.id);
  const wallet = await context.wallets.getSummary(interaction.user.id, interaction.user.username);
  const session = await context.sessions.create(
    interaction.user.id,
    'RENEWAL',
    'Application',
    applicationId,
  );
  await replaceInteractionMessage(
    interaction,
    renewalManagementPanel(
      context.brand,
      updated,
      wallet.balanceInCents,
      session,
      context.sessions,
    ),
  );
}

async function confirmRegenerate(
  interaction: ButtonInteraction,
  context: AppContext,
  applicationId: string,
): Promise<void> {
  await context.applications.getOwned(applicationId, interaction.user.id);
  const session = await context.sessions.create(
    interaction.user.id,
    'REGENERATE_LICENSE',
    'Application',
    applicationId,
  );
  await replaceInteractionMessage(
    interaction,
    confirmationPanel(
      context.brand,
      'Regenerar chave',
      'A chave atual deixará de funcionar imediatamente. A nova chave será exibida apenas uma vez.',
      context.sessions.buildCustomId(session, 'confirm_regenerate'),
      context.sessions.buildCustomId(session, 'back_app'),
    ),
  );
}

async function regenerateLicense(
  interaction: ButtonInteraction,
  context: AppContext,
  applicationId: string,
  sessionId: string,
): Promise<void> {
  if (!(await context.sessions.consume(sessionId))) {
    throw new DomainError('Esta confirmação já foi utilizada.', 'SESSION_CONSUMED');
  }
  const key = await context.licenses.regenerate(applicationId, interaction.user.id);
  await replaceInteractionMessage(interaction, {
    content: null as unknown as string,
    embeds: [
      new EmbedBuilder()
        .setColor(context.brand.primaryColor)
        .setTitle('Chave regenerada com sucesso')
        .setDescription(
          `Copie e guarde agora. Esta chave será exibida somente uma vez:\n\n\`${key}\``,
        ),
    ],
    components: [],
  });
}

async function confirmTransfer(
  interaction: ButtonInteraction,
  context: AppContext,
  applicationId: string,
  kind: string,
  _sessionId: string,
): Promise<void> {
  if (!kind.startsWith('TRANSFER:')) {
    throw new DomainError('Destino da transferência ausente.', 'TRANSFER_TARGET_MISSING');
  }
  const target = kind.slice('TRANSFER:'.length);
  if (!/^\d{17,20}$/.test(target)) {
    throw new DomainError('Destino da transferência inválido.', 'TRANSFER_TARGET_INVALID');
  }

  await context.transfers.transfer(applicationId, interaction.user.id, target);
  await interaction.editReply(
    successPanel(context.brand, `Aplicação transferida com sucesso para <@${target}>.`),
  );
}

async function deleteApplication(
  interaction: ButtonInteraction,
  context: AppContext,
  applicationId: string,
  sessionId: string,
): Promise<void> {
  if (!(await context.sessions.consume(sessionId))) {
    throw new DomainError('Esta confirmação já foi utilizada.', 'SESSION_CONSUMED');
  }
  await replaceInteractionMessage(
    interaction,
    plainLoadingMessage(context.brand, 'Deletando sua aplicação...'),
  );
  await context.applications.deletePermanent(applicationId, interaction.user.id);
  await interaction.editReply(plainSuccessMessage('Aplicação deletada com sucesso!'));
}

async function generatePix(
  interaction: ButtonInteraction,
  context: AppContext,
  cartId: string,
): Promise<void> {
  await replaceInteractionMessage(interaction, paymentProcessingPanel(context.brand));
  try {
    const created = await context.payments.createForCart(cartId, interaction.user.id);
    const session = await context.sessions.create(
      interaction.user.id,
      'PAYMENT',
      'Payment',
      created.payment.id,
      context.env.PAYMENT_EXPIRATION_MINUTES,
    );
    const attachment = new AttachmentBuilder(created.pix.qrCodeImage, { name: 'pix.png' });
    await interaction.editReply({
      ...pixPanel(context.brand, session, context.sessions),
      files: [attachment],
    });
    await context.carts.attachPaymentMessage(cartId, interaction.message.id);
  } catch (error) {
    await interaction.editReply({
      ...paymentFinalPanel(context.brand, 'ERROR'),
      attachments: [],
    });
    throw error;
  }
}

async function copyPix(
  interaction: ButtonInteraction,
  context: AppContext,
  paymentId: string,
): Promise<void> {
  const code = await context.payments.getPixCode(paymentId, interaction.user.id);
  const payload = {
    content: `Código PIX:\n\`\`\`\n${code}\n\`\`\`\nCopie o código acima e cole no aplicativo do seu banco.`,
  };
  if (interaction.deferred || interaction.replied) await interaction.editReply(payload);
  else await interaction.reply({ ...payload, flags: MessageFlags.Ephemeral });
}

async function cancelPayment(
  interaction: ButtonInteraction,
  context: AppContext,
  paymentId: string,
): Promise<void> {
  await replaceInteractionMessage(interaction, {
    ...plainLoadingMessage(
      context.brand,
      'Aguarde um momento, estamos cancelando seu pagamento...',
    ),
    attachments: [],
  });
  await context.payments.cancel(paymentId, interaction.user.id);
  await interaction.editReply({
    ...paymentFinalPanel(context.brand, 'CANCELLED'),
    attachments: [],
  });
  await deleteCartChannel(
    interaction.client,
    interaction.channelId,
    context.logger,
    `Pagamento cancelado por ${interaction.user.tag}`,
    context.env.CART_DELETE_DELAY_SECONDS,
  );
}

async function showCancelCartConfirmation(
  interaction: ButtonInteraction,
  context: AppContext,
  cartId: string,
): Promise<void> {
  await context.carts.getOwned(cartId, interaction.user.id);
  const session = await context.sessions.create(
    interaction.user.id,
    'CANCEL_CART',
    'Cart',
    cartId,
    context.env.PAYMENT_EXPIRATION_MINUTES,
  );
  await replaceInteractionMessage(
    interaction,
    cartCancellationPanel(
      context.brand,
      context.sessions.buildCustomId(session, 'confirm_cancel_cart'),
      context.sessions.buildCustomId(session, 'back_cart'),
    ),
  );
}

async function showCart(
  interaction: ButtonInteraction,
  context: AppContext,
  cartId: string,
): Promise<void> {
  const cart = await buildCartView(context, cartId, interaction.user.id);
  const session = await context.sessions.create(
    interaction.user.id,
    'CART',
    'Cart',
    cartId,
    context.env.PAYMENT_EXPIRATION_MINUTES,
  );
  await replaceInteractionMessage(
    interaction,
    cartPanel(context.brand, cart, session, context.sessions),
  );
}

async function cancelCart(
  interaction: ButtonInteraction,
  context: AppContext,
  cartId: string,
): Promise<void> {
  await replaceInteractionMessage(
    interaction,
    plainLoadingMessage(context.brand, 'Aguarde um momento, estamos cancelando sua compra...'),
  );
  await context.carts.cancel(cartId, interaction.user.id);
  await interaction.editReply(paymentFinalPanel(context.brand, 'CANCELLED'));
  await deleteCartChannel(
    interaction.client,
    interaction.channelId,
    context.logger,
    `Compra cancelada por ${interaction.user.tag}`,
    context.env.CART_DELETE_DELAY_SECONDS,
  );
}

async function showStatus(
  interaction: ButtonInteraction,
  context: AppContext,
  applicationId: string,
): Promise<void> {
  const application = await context.applications.getOwned(applicationId, interaction.user.id);
  const status = await context.hostingProvider.getStatus(applicationId);
  const session = await context.sessions.create(
    interaction.user.id,
    'APPLICATION',
    'Application',
    applicationId,
  );
  await replaceInteractionMessage(interaction, {
    content: null as unknown as string,
    embeds: [
      new EmbedBuilder()
        .setColor(context.brand.primaryColor)
        .setTitle(`Status de ${application.name}`)
        .addFields(
          { name: 'Manager', value: application.status, inline: true },
          { name: 'Hospedagem', value: status.state, inline: true },
          {
            name: 'Versão',
            value: status.version ?? application.version ?? 'Não informada',
            inline: true,
          },
          { name: 'Atualizado', value: formatDateTime(status.updatedAt), inline: false },
        ),
    ],
    components: [
      row(
        button(
          context.sessions.buildCustomId(session, 'back_app'),
          'Voltar',
          ButtonStyle.Secondary,
        ),
      ),
    ],
  });
}
