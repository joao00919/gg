import { Events, MessageFlags, type Client, type Interaction } from 'discord.js';
import type { AppContext } from '../../context.js';
import { errorMessage } from '../../utils/errors.js';
import { handleAdminAutocomplete, handleAdminCommand } from '../commands/admin/admin-command.js';
import {
  handleApplicationAutocomplete,
  handleAppsCommand,
  handleImageUrlCommand,
  handlePanelCommand,
  handleRenewCommand,
  handleRestoreCommand,
} from '../commands/client/apps-command.js';
import {
  handleAppCommand,
  handleLicenseCommand,
  handlePaymentCommand,
  handleWalletCommand,
} from '../commands/client/quick-commands.js';
import { handleButton } from './buttons/button-handler.js';
import { handleModal } from './modals/modal-handler.js';
import { handleStringSelect, handleUserSelect } from './selects/select-handler.js';

export function bindInteractionRouter(client: Client, context: AppContext): void {
  client.on(Events.InteractionCreate, async (interaction) => {
    try {
      await routeInteraction(interaction, context);
    } catch (error) {
      context.logger.warn(
        { err: error, interactionId: interaction.id },
        'Falha ao processar interação',
      );
      await respondWithError(interaction, errorMessage(error));
    }
  });
}

async function routeInteraction(interaction: Interaction, context: AppContext): Promise<void> {
  if (interaction.isAutocomplete()) {
    if (['apps', 'renovar', 'restore'].includes(interaction.commandName)) {
      return handleApplicationAutocomplete(interaction, context);
    }
    if (interaction.commandName === 'admin') {
      return handleAdminAutocomplete(interaction, context);
    }
    return;
  }
  if (interaction.isChatInputCommand()) {
    if (interaction.commandName === 'apps') return handleAppsCommand(interaction, context);
    if (interaction.commandName === 'renovar') return handleRenewCommand(interaction, context);
    if (interaction.commandName === 'restore') return handleRestoreCommand(interaction, context);
    if (interaction.commandName === 'imagem_url') return handleImageUrlCommand(interaction);
    if (interaction.commandName === 'painel') return handlePanelCommand(interaction, context);
    if (interaction.commandName === 'app') return handleAppCommand(interaction, context);
    if (interaction.commandName === 'licenca') return handleLicenseCommand(interaction, context);
    if (interaction.commandName === 'pagamento') return handlePaymentCommand(interaction, context);
    if (interaction.commandName === 'wallet') return handleWalletCommand(interaction, context);
    if (interaction.commandName === 'admin') return handleAdminCommand(interaction, context);
    return;
  }
  if (interaction.isButton()) return handleButton(interaction, context);
  if (interaction.isStringSelectMenu()) return handleStringSelect(interaction, context);
  if (interaction.isUserSelectMenu()) return handleUserSelect(interaction, context);
  if (interaction.isModalSubmit()) return handleModal(interaction, context);
}

async function respondWithError(interaction: Interaction, message: string): Promise<void> {
  if (!interaction.isRepliable()) return;
  const payload = {
    content: `Não foi possível concluir a ação. ${message}`,
    flags: MessageFlags.Ephemeral,
  } as const;
  if (interaction.isChatInputCommand() && (interaction.deferred || interaction.replied)) {
    await interaction
      .editReply({
        content: payload.content,
        embeds: [],
        components: [],
        attachments: [],
      })
      .catch(() => undefined);
    return;
  }
  if (interaction.deferred || interaction.replied) {
    await interaction.followUp(payload).catch(() => undefined);
    return;
  }
  await interaction.reply(payload).catch(() => undefined);
}
