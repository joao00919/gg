import type { Client } from 'discord.js';
import type { PrismaClient } from '@prisma/client';
import type { BrandConfig } from '../../config/brand.js';
import type { Logger } from '../../config/logger.js';
import { deleteCartChannel } from '../flows/cart-channel-cleanup.js';
import { paymentFinalPanel } from '../panels/payment-panel.js';

export class PaymentMessageService {
  public constructor(
    private readonly prisma: PrismaClient,
    private readonly client: Client,
    private readonly brand: BrandConfig,
    private readonly logger: Logger,
    private readonly cancelledDeleteDelaySeconds = 3,
  ) {}

  public async refresh(paymentId: string): Promise<void> {
    const payment = await this.prisma.payment.findUnique({
      where: { id: paymentId },
      include: { cart: true },
    });
    if (!payment?.cart.channelId || !payment.cart.paymentMessageId) return;
    if (!['APPROVED', 'CANCELLED', 'EXPIRED', 'ERROR'].includes(payment.status)) return;
    try {
      const channel = await this.client.channels.fetch(payment.cart.channelId);
      if (!channel?.isTextBased() || !('messages' in channel)) return;
      const message = await channel.messages.fetch(payment.cart.paymentMessageId);
      const status = payment.status as 'APPROVED' | 'CANCELLED' | 'EXPIRED' | 'ERROR';
      await message.edit({
        ...paymentFinalPanel(this.brand, status),
        attachments: [],
      });

      if (status === 'CANCELLED') {
        await deleteCartChannel(
          this.client,
          payment.cart.channelId,
          this.logger,
          'Pagamento cancelado; encerrando carrinho',
          this.cancelledDeleteDelaySeconds,
        );
      }
    } catch (error) {
      this.logger.warn(
        { err: error, paymentId },
        'Não foi possível atualizar a mensagem do pagamento',
      );
    }
  }
}
