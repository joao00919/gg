import {
  ActionRowBuilder,
  ButtonBuilder,
  ButtonStyle,
  type APIMessageComponentEmoji,
} from 'discord.js';

export function button(
  customId: string,
  label: string,
  style: ButtonStyle,
  emoji?: string,
): ButtonBuilder {
  const builder = new ButtonBuilder().setCustomId(customId).setLabel(label).setStyle(style);
  const parsed = parseCustomEmoji(emoji);
  if (parsed) builder.setEmoji(parsed);
  return builder;
}

export function linkButton(label: string, url: string, emoji?: string): ButtonBuilder {
  const builder = new ButtonBuilder().setLabel(label).setURL(url).setStyle(ButtonStyle.Link);
  const parsed = parseCustomEmoji(emoji);
  if (parsed) builder.setEmoji(parsed);
  return builder;
}

export function row(...buttons: ButtonBuilder[]): ActionRowBuilder<ButtonBuilder> {
  return new ActionRowBuilder<ButtonBuilder>().addComponents(buttons);
}

/**
 * Converte emoji para o formato aceito em componentes do Discord.
 *
 * Para emojis personalizados, apenas o ID é enviado. O nome digitado no .env
 * pode estar desatualizado ou até ser numérico; enviar esse nome causava
 * COMPONENT_INVALID_EMOJI. O ID é a parte autoritativa para componentes.
 */
export function parseCustomEmoji(value?: string): APIMessageComponentEmoji | undefined {
  if (!value) return undefined;
  const trimmed = value.trim();
  const custom = /^<(a?):[^:>]+:(\d{17,20})>$/.exec(trimmed);
  if (custom) {
    const id = custom[2];
    if (!id) return undefined;
    return { animated: custom[1] === 'a', id };
  }
  if (/^\d{17,20}$/.test(trimmed)) {
    return { id: trimmed };
  }
  const unicodeEmoji = /^(?:\p{Regional_Indicator}{2}|[#*0-9]\uFE0F?\u20E3|(?:\p{Emoji_Presentation}|\p{Emoji}\uFE0F)(?:\p{Emoji_Modifier})?(?:\u200D(?:\p{Emoji_Presentation}|\p{Emoji}\uFE0F)(?:\p{Emoji_Modifier})?)*)$/u;
  if (unicodeEmoji.test(trimmed)) {
    return { name: trimmed };
  }
  return undefined;
}

/**
 * Normaliza a menção textual de um emoji personalizado. O nome visual não é
 * usado como identidade; o ID é preservado e um nome sintaticamente válido é
 * aplicado quando o usuário colou algo como <:123:456>.
 */
export function normalizeDisplayEmoji(
  value: string | undefined,
  fallback: string,
  safeName: string,
): string {
  const selected = value?.trim();
  const source = selected && selected.length > 0 ? selected : fallback;
  const custom = /^<(a?):([^:>]+):(\d{17,20})>$/.exec(source);
  if (!custom) return source;
  const animated = custom[1] === 'a';
  const originalName = custom[2];
  const id = custom[3];
  if (!originalName || !id) return fallback;
  const validName = /^[A-Za-z_][A-Za-z0-9_]{1,31}$/.test(originalName)
    ? originalName
    : safeName;
  return `<${animated ? 'a' : ''}:${validName}:${id}>`;
}
