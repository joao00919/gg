import { Client, Events, GatewayIntentBits, Partials } from 'discord.js';
import type { AppContext } from '../../context.js';
import type { BrandConfig } from '../../config/brand.js';
import { bindInteractionRouter } from '../interactions/router.js';

const componentEmojiKeys = [
  'app',
  'start',
  'restart',
  'stop',
  'settings',
  'member',
  'search',
  'role',
  'delete',
  'dollar',
  'pix',
  'web',
  'paymentCancelled',
  'wallet',
  'power',
  'reload',
  'save',
  'rocket',
  'pause',
  'play',
  'folder',
  'donation',
  'cardbox',
  'card',
  'plus',
  'config',
  'commands',
  'trusted',
  'team',
  'servers',
  'transfer',
  'moderation',
  'checkout',
] as const satisfies readonly (keyof BrandConfig['emojis'])[];

function customEmojiId(value?: string): string | undefined {
  return /^<a?:[^:>]+:(\d{17,20})>$/.exec(value ?? '')?.[1];
}

/**
 * Remove apenas emojis usados em componentes quando o bot não consegue acessá-los.
 * Emojis usados em texto permanecem configurados, pois não invalidam a mensagem.
 */
export function removeUnavailableComponentEmojis(
  brand: BrandConfig,
  availableEmojiIds: ReadonlySet<string>,
): string[] {
  const removed: string[] = [];
  for (const key of componentEmojiKeys) {
    const value = brand.emojis[key];
    const id = customEmojiId(value);
    if (id && !availableEmojiIds.has(id)) {
      brand.emojis[key] = undefined;
      removed.push(key);
    }
  }
  return removed;
}

export function createManagerClient(): Client {
  return new Client({
    intents: [
      GatewayIntentBits.Guilds,
      GatewayIntentBits.GuildMessages,
      GatewayIntentBits.DirectMessages,
    ],
    partials: [Partials.Channel],
  });
}

export function bindManagerClient(client: Client, context: AppContext): void {
  bindInteractionRouter(client, context);
  client.once(Events.ClientReady, async (readyClient) => {
    const availableEmojiIds = new Set<string>();
    try {
      const managerGuild = await readyClient.guilds.fetch(context.env.MANAGER_GUILD_ID);
      const guildEmojis = await managerGuild.emojis.fetch();
      for (const id of guildEmojis.keys()) availableEmojiIds.add(id);

      const applicationEmojis = await readyClient.application.emojis.fetch().catch(() => null);
      if (applicationEmojis) {
        for (const id of applicationEmojis.keys()) availableEmojiIds.add(id);
      }
    } catch (error) {
      context.logger.warn({ err: error }, 'Não foi possível validar os emojis personalizados');
    }

    const removed = removeUnavailableComponentEmojis(context.brand, availableEmojiIds);
    if (removed.length) {
      context.logger.warn(
        { emojiKeys: removed },
        'Emojis sem acesso foram removidos dos componentes para evitar falha ao enviar painéis',
      );
    }

    context.logger.info(
      { bot: readyClient.user.tag, guilds: readyClient.guilds.cache.size },
      'Bot Manager conectado',
    );
  });
  client.on(Events.Error, (error) =>
    context.logger.error({ err: error }, 'Erro no cliente Discord'),
  );
}
