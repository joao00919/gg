import { randomUUID } from 'node:crypto';

export function createIdempotencyKey(scope: string): string {
  return `${scope}:${randomUUID()}`;
}
