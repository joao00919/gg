export function addDays(base: Date, days: number): Date {
  const result = new Date(base);
  result.setUTCDate(result.getUTCDate() + days);
  return result;
}

export function calculateRenewalExpiry(
  currentExpiry: Date,
  approvedAt: Date,
  periodDays: number,
): Date {
  const base = currentExpiry.getTime() > approvedAt.getTime() ? currentExpiry : approvedAt;
  return addDays(base, periodDays);
}

export function formatDateTime(date: Date): string {
  return new Intl.DateTimeFormat('pt-BR', {
    timeZone: 'America/Sao_Paulo',
    dateStyle: 'short',
    timeStyle: 'short',
  }).format(date);
}

export function formatRemaining(expiresAt: Date, now = new Date()): string {
  const milliseconds = expiresAt.getTime() - now.getTime();
  if (milliseconds <= 0) return 'Vencida';
  const days = Math.floor(milliseconds / 86_400_000);
  const hours = Math.floor((milliseconds % 86_400_000) / 3_600_000);
  return `${days}d ${hours}h`;
}
