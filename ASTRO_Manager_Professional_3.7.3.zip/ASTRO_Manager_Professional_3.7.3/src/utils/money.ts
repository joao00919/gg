export function formatMoney(amountInCents: number, currency = 'BRL'): string {
  return new Intl.NumberFormat('pt-BR', { style: 'currency', currency }).format(
    amountInCents / 100,
  );
}
