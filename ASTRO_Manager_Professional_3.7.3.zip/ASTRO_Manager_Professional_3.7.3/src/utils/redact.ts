const sensitivePatterns: RegExp[] = [
  /authorization\s*[:=]\s*[^\s]+/gi,
  /(?:token|secret|password|senha|access[_-]?token)\s*[:=]\s*[^\s]+/gi,
  /[A-Za-z0-9_-]{24}\.[A-Za-z0-9_-]{6}\.[A-Za-z0-9_-]{20,}/g,
  /(?:000201)[0-9A-Za-z.-]{40,}/g,
];

export function redactText(input: string): string {
  return sensitivePatterns.reduce((text, pattern) => text.replace(pattern, '[REDACTED]'), input);
}

export function splitDiscordText(input: string, maxLength = 1800): string[] {
  if (input.length <= maxLength) return [input];
  const chunks: string[] = [];
  let remaining = input;
  while (remaining.length > maxLength) {
    const boundary = remaining.lastIndexOf('\n', maxLength);
    const cut = boundary > 0 ? boundary : maxLength;
    chunks.push(remaining.slice(0, cut));
    remaining = remaining.slice(cut).replace(/^\n/, '');
  }
  if (remaining) chunks.push(remaining);
  return chunks;
}
