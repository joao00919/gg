import { randomToken, signHmac, verifyHmacPrefix } from './crypto.js';

export interface CompactCustomId {
  action: string;
  sessionId: string;
  version: number;
  nonce: string;
}

export interface CreateCustomIdInput extends Omit<CompactCustomId, 'nonce'> {
  nonce?: string;
}

export function createCustomId(input: CreateCustomIdInput, secret: string): string {
  const sessionId = input.sessionId.replaceAll('-', '');
  const nonce = input.nonce ?? randomToken(3);
  const unsigned = `vm.${input.action}.${sessionId}.${input.version}.${nonce}`;
  const signature = signHmac(unsigned, secret).slice(0, 12);
  const customId = `${unsigned}.${signature}`;
  if (customId.length > 100) throw new Error('Custom ID ultrapassou o limite do Discord.');
  return customId;
}

export function parseCustomId(customId: string, secret: string): CompactCustomId {
  const [prefix, action, compactSessionId, versionText, nonce, signature] = customId.split('.');
  const unsigned = [prefix, action, compactSessionId, versionText, nonce].join('.');
  if (
    prefix !== 'vm' ||
    !action ||
    compactSessionId?.length !== 32 ||
    !versionText ||
    !nonce ||
    !signature ||
    !verifyHmacPrefix(unsigned, signature, secret, 12)
  ) {
    throw new Error('Componente inválido ou adulterado.');
  }
  const version = Number(versionText);
  if (!Number.isInteger(version) || version < 1) throw new Error('Versão do componente inválida.');
  const sessionId = `${compactSessionId.slice(0, 8)}-${compactSessionId.slice(8, 12)}-${compactSessionId.slice(12, 16)}-${compactSessionId.slice(16, 20)}-${compactSessionId.slice(20)}`;
  return { action, sessionId, version, nonce };
}
