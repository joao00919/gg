import type { ApplicationStatus, Prisma, PrismaClient } from '@prisma/client';
import type { HostingProvider } from '../../types/hosting.js';
import { DomainError } from '../../utils/errors.js';
import { KeyedLock } from '../../utils/locks.js';
import type { AuditService } from '../audit/audit-service.js';

export class ApplicationService {
  private readonly actionLock = new KeyedLock();

  public constructor(
    private readonly prisma: PrismaClient,
    private readonly hosting: HostingProvider,
    private readonly audit: AuditService,
  ) {}

  public async listForDiscordUser(discordId: string) {
    return this.prisma.application.findMany({
      where: { owner: { discordId }, deletedAt: null },
      include: {
        plan: true,
        license: true,
        payments: { orderBy: { createdAt: 'desc' }, take: 1 },
      },
      orderBy: { createdAt: 'desc' },
    });
  }

  public async autocomplete(discordId: string, query: string) {
    const filters: Prisma.ApplicationWhereInput[] = [
      { name: { contains: query, mode: 'insensitive' } },
    ];
    if (/^[0-9a-f-]{36}$/i.test(query)) filters.push({ id: query });
    const applications = await this.prisma.application.findMany({
      where: {
        owner: { discordId },
        deletedAt: null,
        OR: filters,
      },
      include: { plan: true },
      orderBy: { updatedAt: 'desc' },
      take: 25,
    });
    return applications.map((application) => ({
      name: `${application.name} - ${application.id.slice(0, 28)} - ${application.plan.name}`.slice(0, 100),
      value: application.id,
    }));
  }

  public async getOwned(applicationId: string, discordId: string) {
    const application = await this.prisma.application.findFirst({
      where: { id: applicationId, owner: { discordId }, deletedAt: null },
      include: {
        owner: { include: { wallet: true } },
        plan: {
          include: {
            prices: { where: { active: true }, orderBy: { periodDays: 'asc' } },
            addons: {
              where: { addon: { active: true, deletedAt: null } },
              include: { addon: true },
              orderBy: { addon: { displayOrder: 'asc' } },
            },
          },
        },
        license: true,
        instances: true,
        addons: { include: { addon: true }, orderBy: { addon: { displayOrder: 'asc' } } },
        payments: { orderBy: { createdAt: 'desc' }, take: 1 },
      },
    });
    if (!application)
      throw new DomainError(
        'Aplicação não encontrada ou sem permissão.',
        'APPLICATION_FORBIDDEN',
        403,
      );
    return application;
  }

  public async start(applicationId: string, actorDiscordId: string): Promise<void> {
    await this.actionLock.runExclusive(applicationId, async () => {
      const application = await this.requireActiveLicense(applicationId, actorDiscordId);
      await this.hosting.activateApplication(application.hostingExternalId ?? application.id);
      await this.prisma.application.update({ where: { id: application.id }, data: { status: 'ONLINE' } });
      await this.recordAction(actorDiscordId, 'APPLICATION_START', application.id);
    });
  }

  public async stop(applicationId: string, actorDiscordId: string): Promise<void> {
    await this.actionLock.runExclusive(applicationId, async () => {
      const application = await this.getOwned(applicationId, actorDiscordId);
      await this.hosting.suspendApplication(application.hostingExternalId ?? application.id);
      await this.prisma.application.update({ where: { id: application.id }, data: { status: 'OFFLINE' } });
      await this.recordAction(actorDiscordId, 'APPLICATION_STOP', application.id);
    });
  }

  public async restore(applicationId: string, actorDiscordId: string): Promise<void> {
    await this.actionLock.runExclusive(applicationId, async () => {
      const application = await this.requireActiveLicense(applicationId, actorDiscordId);
      await this.hosting.activateApplication(application.hostingExternalId ?? application.id);
      await this.prisma.application.update({
        where: { id: application.id },
        data: { status: 'OFFLINE', deletedAt: null },
      });
      await this.recordAction(actorDiscordId, 'APPLICATION_RESTORE', application.id);
    });
  }

  public async restart(applicationId: string, actorDiscordId: string): Promise<void> {
    await this.actionLock.runExclusive(applicationId, async () => {
      const application = await this.requireActiveLicense(applicationId, actorDiscordId);
      if (application.lastRestartAt && Date.now() - application.lastRestartAt.getTime() < 60_000) {
        throw new DomainError('Aguarde um minuto antes de reiniciar novamente.', 'RESTART_COOLDOWN');
      }
      const result = await this.hosting.restartApplication(application.hostingExternalId ?? application.id);
      const status: ApplicationStatus = result.accepted ? 'ONLINE' : 'ERROR';
      await this.prisma.application.update({
        where: { id: applicationId },
        data: { status, lastRestartAt: new Date() },
      });
      await this.audit.record({
        actorId: actorDiscordId,
        actorType: 'USER',
        action: 'APPLICATION_RESTART',
        entityType: 'Application',
        entityId: applicationId,
        metadataSafe: { provider: this.hosting.name, accepted: result.accepted },
      });
    });
  }

  public async deletePermanent(applicationId: string, actorDiscordId: string): Promise<void> {
    await this.actionLock.runExclusive(applicationId, async () => {
      const application = await this.getOwned(applicationId, actorDiscordId);
      await this.hosting.suspendApplication(application.hostingExternalId ?? application.id).catch(() => undefined);
      await this.prisma.$transaction(async (tx) => {
        await tx.application.update({
          where: { id: application.id },
          data: { status: 'DELETED', deletedAt: new Date() },
        });
        if (application.license) {
          await tx.license.update({ where: { id: application.license.id }, data: { status: 'REVOKED' } });
        }
        await tx.subscription.updateMany({ where: { applicationId: application.id, active: true }, data: { active: false } });
        await tx.interactionSession.updateMany({
          where: { entityType: 'Application', entityId: application.id, status: 'ACTIVE' },
          data: { status: 'REVOKED' },
        });
      });
      await this.recordAction(actorDiscordId, 'APPLICATION_DELETE', application.id);
    });
  }

  private async requireActiveLicense(applicationId: string, actorDiscordId: string) {
    const application = await this.getOwned(applicationId, actorDiscordId);
    if (!application.license || !['ACTIVE', 'EXPIRING'].includes(application.license.status)) {
      throw new DomainError('A licença precisa estar ativa para executar esta ação.', 'LICENSE_INACTIVE');
    }
    return application;
  }

  private async recordAction(actorDiscordId: string, action: string, applicationId: string) {
    await this.audit.record({
      actorId: actorDiscordId,
      actorType: 'USER',
      action,
      entityType: 'Application',
      entityId: applicationId,
      metadataSafe: { provider: this.hosting.name },
    });
  }
}
