import type { Client } from 'discord.js';
import type { PrismaClient } from '@prisma/client';
import type { Logger } from '../../config/logger.js';

export class NotificationService {
  public constructor(
    private readonly prisma: PrismaClient,
    private readonly logger: Logger,
    private readonly client?: Client,
  ) {}

  public async sendDiscord(discordId: string, type: string, content: string): Promise<void> {
    const user = await this.prisma.user.upsert({
      where: { discordId },
      update: {},
      create: { discordId },
    });
    const notification = await this.prisma.notification.create({
      data: { userId: user.id, type, content },
    });
    if (!this.client) return;
    try {
      const discordUser = await this.client.users.fetch(discordId);
      await discordUser.send({ content });
      await this.prisma.notification.update({
        where: { id: notification.id },
        data: { status: 'SENT', sentAt: new Date() },
      });
    } catch (error) {
      this.logger.warn(
        { err: error, notificationId: notification.id },
        'Não foi possível enviar DM',
      );
      await this.prisma.notification.update({
        where: { id: notification.id },
        data: { status: 'FAILED', error: 'Falha ao enviar mensagem privada.' },
      });
    }
  }
}
