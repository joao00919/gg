import type { Addon, Plan, PlanPrice, PrismaClient } from '@prisma/client';
import { DomainError } from '../../utils/errors.js';

export type PlanWithPrices = Plan & { prices: PlanPrice[] };
export type PlanWithStore = Plan & {
  prices: PlanPrice[];
  addons: { addon: Addon }[];
};

const referencePrices = [
  { label: '1 dia', days: 1, cents: 100 },
  { label: '7 dias', days: 7, cents: 399 },
  { label: '15 dias', days: 15, cents: 599 },
  { label: '30 dias', days: 30, cents: 899 },
  { label: '365 dias', days: 365, cents: 7999 },
] as const;

const defaultPlans = [
  {
    slug: 'vendas',
    name: 'Vendas',
    description: 'Automatize todo o processo de vendas, do catálogo à entrega.',
    storeDescription: 'Bot de Vendas',
    serverLimit: 1,
    displayOrder: 1,
  },
  {
    slug: 'ticket',
    name: 'Ticket',
    description: 'Gerencie o suporte ao cliente com IA e automação avançada.',
    storeDescription: 'Bot de Ticket',
    serverLimit: 1,
    displayOrder: 2,
  },
  {
    slug: 'roblox',
    name: 'Roblox',
    description: 'Venda itens e moedas do Roblox de forma segura e automatizada.',
    storeDescription: 'Bot de Roblox',
    serverLimit: 1,
    displayOrder: 3,
  },
  {
    slug: 'divulgacao',
    name: 'Divulgação',
    description: 'Promova produtos e serviços em larga escala com controle de campanhas.',
    storeDescription: 'Bot de Divulgação',
    serverLimit: 1,
    displayOrder: 4,
  },
  {
    slug: 'verificacao',
    name: 'Verificação',
    description: 'Proteja seu servidor com autenticação e validação via OAuth2.',
    storeDescription: 'Bot de Verificação',
    serverLimit: 1,
    displayOrder: 5,
  },
] as const;

const defaultAddons = [
  {
    slug: 'suporte-prioritario',
    name: 'Suporte Prioritário',
    description: 'Prioridade na fila de atendimento e suporte técnico.',
    cents: 400,
    displayOrder: 1,
  },
  {
    slug: 'remover-anuncio',
    name: 'Remover Anúncio',
    description: 'Remove a identificação promocional padrão da aplicação.',
    cents: 400,
    displayOrder: 2,
  },
  {
    slug: 'qrcode-personalizavel',
    name: 'QRCode Personalizável',
    description: 'Libera personalização visual do QR Code exibido ao cliente.',
    cents: 400,
    displayOrder: 3,
  },
] as const;

export class PlanService {
  public constructor(private readonly prisma: PrismaClient) {}

  public async seedDefaults(): Promise<void> {
    const storedPlans: Plan[] = [];
    for (const plan of defaultPlans) {
      const stored = await this.prisma.plan.upsert({
        where: { slug: plan.slug },
        update: {
          name: plan.name,
          description: plan.description,
          storeDescription: plan.storeDescription,
          serverLimit: plan.serverLimit,
          displayOrder: plan.displayOrder,
          active: true,
          deletedAt: null,
        },
        create: {
          slug: plan.slug,
          name: plan.name,
          description: plan.description,
          storeDescription: plan.storeDescription,
          features: [plan.description],
          serverLimit: plan.serverLimit,
          displayOrder: plan.displayOrder,
        },
      });
      storedPlans.push(stored);
      for (const price of referencePrices) {
        await this.prisma.planPrice.upsert({
          where: { planId_periodDays: { planId: stored.id, periodDays: price.days } },
          update: { label: price.label, amountInCents: price.cents, active: true },
          create: {
            planId: stored.id,
            label: price.label,
            periodDays: price.days,
            amountInCents: price.cents,
          },
        });
      }
      await this.prisma.planPrice.updateMany({
        where: {
          planId: stored.id,
          periodDays: { notIn: referencePrices.map((price) => price.days) },
        },
        data: { active: false },
      });
    }

    await this.prisma.addon.updateMany({
      where: { slug: { notIn: defaultAddons.map((addon) => addon.slug) } },
      data: { active: false, deletedAt: new Date() },
    });

    const storedAddons: Addon[] = [];
    for (const addon of defaultAddons) {
      storedAddons.push(
        await this.prisma.addon.upsert({
          where: { slug: addon.slug },
          update: {
            name: addon.name,
            description: addon.description,
            amountInCents: addon.cents,
            displayOrder: addon.displayOrder,
            active: true,
            deletedAt: null,
          },
          create: {
            slug: addon.slug,
            name: addon.name,
            description: addon.description,
            amountInCents: addon.cents,
            displayOrder: addon.displayOrder,
          },
        }),
      );
    }

    for (const plan of storedPlans) {
      for (const addon of storedAddons) {
        await this.prisma.planAddon.upsert({
          where: { planId_addonId: { planId: plan.id, addonId: addon.id } },
          update: {},
          create: { planId: plan.id, addonId: addon.id },
        });
      }
    }
  }

  public async listActive(): Promise<PlanWithStore[]> {
    return this.prisma.plan.findMany({
      where: { active: true, deletedAt: null },
      include: {
        prices: { where: { active: true }, orderBy: { periodDays: 'asc' } },
        addons: {
          where: { addon: { active: true, deletedAt: null } },
          include: { addon: true },
          orderBy: { addon: { displayOrder: 'asc' } },
        },
      },
      orderBy: { displayOrder: 'asc' },
    });
  }

  public async getStorePlan(planId: string): Promise<PlanWithStore> {
    const plan = await this.prisma.plan.findFirst({
      where: { id: planId, active: true, deletedAt: null },
      include: {
        prices: { where: { active: true }, orderBy: { periodDays: 'asc' } },
        addons: {
          where: { addon: { active: true, deletedAt: null } },
          include: { addon: true },
          orderBy: { addon: { displayOrder: 'asc' } },
        },
      },
    });
    if (!plan) throw new DomainError('Produto indisponível.', 'PLAN_UNAVAILABLE');
    return plan;
  }

  public async getPrice(planId: string, periodDays: number): Promise<PlanPrice & { plan: Plan }> {
    const price = await this.prisma.planPrice.findUnique({
      where: { planId_periodDays: { planId, periodDays } },
      include: { plan: true },
    });
    if (!price || !price.active || !price.plan.active) {
      throw new DomainError('Plano ou período indisponível.', 'PLAN_UNAVAILABLE');
    }
    return price;
  }

  public async getAddonForPlan(planId: string, addonId: string): Promise<Addon> {
    const relation = await this.prisma.planAddon.findUnique({
      where: { planId_addonId: { planId, addonId } },
      include: { addon: true },
    });
    if (!relation?.addon.active || relation.addon.deletedAt) {
      throw new DomainError('Adicional indisponível.', 'ADDON_UNAVAILABLE');
    }
    return relation.addon;
  }
}
