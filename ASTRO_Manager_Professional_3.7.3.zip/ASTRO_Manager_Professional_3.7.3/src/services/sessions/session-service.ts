import { randomUUID } from 'node:crypto';
import type { PrismaClient } from '@prisma/client';
import { createCustomId, parseCustomId } from '../../utils/custom-id.js';
import { randomToken, sha256 } from '../../utils/crypto.js';
import { DomainError } from '../../utils/errors.js';

export interface ValidatedSessionAction {
  action: string;
  kind: string;
  sessionId: string;
  userId: string;
  entityType?: string;
  entityId?: string;
  version: number;
}

export class SessionService {
  public constructor(
    private readonly prisma: PrismaClient,
    private readonly customIdSecret: string,
  ) {}

  public async create(
    discordUserId: string,
    kind: string,
    entityType?: string,
    entityId?: string,
    ttlMinutes = 15,
  ) {
    const user = await this.prisma.user.upsert({
      where: { discordId: discordUserId },
      update: {},
      create: { discordId: discordUserId },
    });
    const id = randomUUID();
    const nonce = randomToken(6);
    return this.prisma.interactionSession
      .create({
        data: {
          id,
          userId: user.id,
          kind,
          entityType,
          entityId,
          nonceHash: sha256(nonce),
          expiresAt: new Date(Date.now() + ttlMinutes * 60_000),
        },
      })
      .then((session) => ({ ...session, componentNonce: nonce }));
  }

  public buildCustomId(
    session: { id: string; version: number; componentNonce?: string },
    action: string,
  ): string {
    if (!session.componentNonce) {
      throw new DomainError('A sessão não possui nonce para componentes.', 'SESSION_NONCE_MISSING');
    }
    return createCustomId(
      { action, sessionId: session.id, version: session.version, nonce: session.componentNonce },
      this.customIdSecret,
    );
  }

  public async validate(customId: string, clickingUserId: string): Promise<ValidatedSessionAction> {
    const compact = parseCustomId(customId, this.customIdSecret);
    const session = await this.prisma.interactionSession.findUnique({
      where: { id: compact.sessionId },
      include: { user: true },
    });
    if (!session || session.user.discordId !== clickingUserId) {
      throw new DomainError(
        'Este componente pertence a outro usuário.',
        'INTERACTION_FORBIDDEN',
        403,
      );
    }
    if (session.nonceHash !== sha256(compact.nonce)) {
      throw new DomainError('Componente inválido ou revogado.', 'INTERACTION_NONCE_INVALID', 403);
    }
    if (
      session.status !== 'ACTIVE' ||
      session.version !== compact.version ||
      session.expiresAt.getTime() <= Date.now()
    ) {
      throw new DomainError(
        'Esta sessão expirou. Execute o comando novamente.',
        'INTERACTION_EXPIRED',
      );
    }
    return {
      action: compact.action,
      kind: session.kind,
      sessionId: session.id,
      userId: clickingUserId,
      entityType: session.entityType ?? undefined,
      entityId: session.entityId ?? undefined,
      version: session.version,
    };
  }

  public async consume(sessionId: string): Promise<boolean> {
    const result = await this.prisma.interactionSession.updateMany({
      where: { id: sessionId, status: 'ACTIVE', expiresAt: { gt: new Date() } },
      data: { status: 'CONSUMED', consumedAt: new Date() },
    });
    return result.count === 1;
  }
}
