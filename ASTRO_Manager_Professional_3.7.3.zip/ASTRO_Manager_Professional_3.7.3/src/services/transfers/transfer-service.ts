import type { PrismaClient } from '@prisma/client';
import { DomainError } from '../../utils/errors.js';
import type { AuditService } from '../audit/audit-service.js';

export interface TransferEligibility {
  applicationName: string;
}

export class TransferService {
  public constructor(
    private readonly prisma: PrismaClient,
    private readonly audit: AuditService,
  ) {}

  public async assertCanTransfer(
    applicationId: string,
    fromDiscordId: string,
    toDiscordId: string,
  ): Promise<TransferEligibility> {
    const source = await this.loadEligibleSource(applicationId, fromDiscordId, toDiscordId);
    return { applicationName: source.name };
  }

  public async transfer(applicationId: string, fromDiscordId: string, toDiscordId: string) {
    const source = await this.loadEligibleSource(applicationId, fromDiscordId, toDiscordId);

    const destination = await this.prisma.user.upsert({
      where: { discordId: toDiscordId },
      update: {},
      create: { discordId: toDiscordId },
    });

    const result = await this.prisma.$transaction(async (tx) => {
      const changed = await tx.application.updateMany({
        where: {
          id: applicationId,
          ownerId: source.ownerId,
          deletedAt: null,
        },
        data: { ownerId: destination.id },
      });

      if (changed.count !== 1) {
        throw new DomainError(
          'A propriedade da aplicação foi alterada durante a confirmação. Abra o painel novamente.',
          'TRANSFER_CONFLICT',
          409,
        );
      }

      const transfer = await tx.transfer.create({
        data: {
          applicationId,
          fromUserId: source.ownerId,
          toUserId: destination.id,
          status: 'COMPLETED',
          completedAt: new Date(),
        },
      });

      await tx.interactionSession.updateMany({
        where: { entityId: applicationId, status: 'ACTIVE' },
        data: { status: 'REVOKED' },
      });
      return transfer;
    });

    await this.audit.record({
      actorId: fromDiscordId,
      actorType: 'USER',
      action: 'APPLICATION_TRANSFER',
      entityType: 'Application',
      entityId: applicationId,
      metadataSafe: { toDiscordId },
    });
    return result;
  }

  private async loadEligibleSource(
    applicationId: string,
    fromDiscordId: string,
    toDiscordId: string,
  ) {
    if (fromDiscordId === toDiscordId) {
      throw new DomainError(
        'O novo proprietário precisa ser diferente do proprietário atual.',
        'TRANSFER_SAME_USER',
      );
    }

    const source = await this.prisma.application.findFirst({
      where: { id: applicationId, owner: { discordId: fromDiscordId }, deletedAt: null },
      include: { payments: { where: { status: 'PENDING' } } },
    });
    if (!source) {
      throw new DomainError(
        'Aplicação não encontrada ou você não possui mais permissão para transferi-la.',
        'APPLICATION_FORBIDDEN',
        403,
      );
    }
    if (source.payments.length > 0) {
      throw new DomainError(
        'A aplicação possui um pagamento pendente. Conclua ou cancele o pagamento antes da transferência.',
        'TRANSFER_PAYMENT_PENDING',
      );
    }

    const recent = await this.prisma.transfer.findFirst({
      where: {
        applicationId,
        status: 'COMPLETED',
        completedAt: { gt: new Date(Date.now() - 7 * 86_400_000) },
      },
    });
    if (recent) {
      throw new DomainError(
        'Esta aplicação foi transferida recentemente. Aguarde sete dias para realizar outra transferência.',
        'TRANSFER_COOLDOWN',
      );
    }

    return source;
  }
}
