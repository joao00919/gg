import type { Addon, CartKind, PrismaClient } from '@prisma/client';
import { DomainError } from '../../utils/errors.js';
import type { PlanService } from '../plans/plan-service.js';

export interface CreateCartInput {
  discordUserId: string;
  username: string;
  guildId: string;
  planId: string;
  periodDays: number;
  applicationId?: string;
  kind: CartKind;
  expiresAt: Date;
}

export class CartService {
  public constructor(
    private readonly prisma: PrismaClient,
    private readonly plans: PlanService,
  ) {}

  public async create(input: CreateCartInput) {
    const price = await this.plans.getPrice(input.planId, input.periodDays);
    const user = await this.prisma.user.upsert({
      where: { discordId: input.discordUserId },
      update: { username: input.username },
      create: { discordId: input.discordUserId, username: input.username },
    });

    if (input.applicationId) {
      const application = await this.prisma.application.findFirst({
        where: { id: input.applicationId, ownerId: user.id, deletedAt: null },
      });
      if (!application)
        throw new DomainError(
          'Aplicação não encontrada ou sem permissão.',
          'APPLICATION_FORBIDDEN',
          403,
        );
    }

    const existing = await this.prisma.cart.findFirst({
      where: {
        userId: user.id,
        status: { in: ['OPEN', 'PAYMENT_PENDING'] },
        expiresAt: { gt: new Date() },
      },
    });
    if (existing)
      throw new DomainError(
        'Você já possui um carrinho ou pagamento pendente.',
        'CART_ALREADY_OPEN',
      );

    const baseAmountInCents = Math.max(50, price.amountInCents - price.discountInCents);
    return this.prisma.cart.create({
      data: {
        kind: input.kind,
        userId: user.id,
        applicationId: input.applicationId,
        planId: input.planId,
        periodDays: input.periodDays,
        baseAmountInCents,
        amountInCents: baseAmountInCents,
        guildId: input.guildId,
        expiresAt: input.expiresAt,
      },
      include: {
        user: true,
        application: true,
        plan: true,
        addons: { include: { addon: true } },
      },
    });
  }

  public async getOwned(cartId: string, discordUserId: string) {
    const cart = await this.prisma.cart.findFirst({
      where: { id: cartId, user: { discordId: discordUserId } },
      include: {
        user: true,
        application: true,
        plan: { include: { prices: { where: { active: true }, orderBy: { periodDays: 'asc' } } } },
        addons: { include: { addon: true }, orderBy: { addon: { displayOrder: 'asc' } } },
        payment: true,
      },
    });
    if (!cart) throw new DomainError('Carrinho não encontrado ou sem permissão.', 'CART_FORBIDDEN');
    return cart;
  }

  public async updatePeriod(cartId: string, discordUserId: string, periodDays: number) {
    const cart = await this.getOwned(cartId, discordUserId);
    if (cart.status !== 'OPEN') throw new DomainError('Este carrinho não pode mais ser alterado.', 'CART_FINAL');
    const price = await this.plans.getPrice(cart.planId, periodDays);
    const baseAmountInCents = Math.max(50, price.amountInCents - price.discountInCents);
    const addonAmount = cart.addons.reduce((sum, item) => sum + item.amountInCents, 0);
    await this.prisma.cart.update({
      where: { id: cart.id },
      data: { periodDays, baseAmountInCents, amountInCents: baseAmountInCents + addonAmount },
    });
    return this.getOwned(cart.id, discordUserId);
  }

  public async updateAddons(cartId: string, discordUserId: string, addonIds: string[]) {
    const cart = await this.getOwned(cartId, discordUserId);
    if (cart.status !== 'OPEN') throw new DomainError('Este carrinho não pode mais ser alterado.', 'CART_FINAL');
    const uniqueIds = [...new Set(addonIds)].slice(0, 20);
    const addons: Addon[] = [];
    for (const addonId of uniqueIds) addons.push(await this.plans.getAddonForPlan(cart.planId, addonId));
    const addonAmount = addons.reduce((sum, addon) => sum + addon.amountInCents, 0);
    await this.prisma.$transaction(async (tx) => {
      await tx.cartAddon.deleteMany({ where: { cartId: cart.id } });
      if (addons.length) {
        await tx.cartAddon.createMany({
          data: addons.map((addon) => ({
            cartId: cart.id,
            addonId: addon.id,
            amountInCents: addon.amountInCents,
          })),
        });
      }
      await tx.cart.update({
        where: { id: cart.id },
        data: { amountInCents: cart.baseAmountInCents + addonAmount },
      });
    });
    return this.getOwned(cart.id, discordUserId);
  }

  public async cancel(cartId: string, discordUserId: string): Promise<void> {
    const cart = await this.getOwned(cartId, discordUserId);
    if (cart.status === 'CANCELLED') throw new DomainError('Este carrinho já foi cancelado.', 'CART_CANCELLED');
    if (cart.status !== 'OPEN') throw new DomainError('Este carrinho não pode mais ser cancelado.', 'CART_FINAL');
    await this.prisma.cart.update({ where: { id: cart.id }, data: { status: 'CANCELLED' } });
  }

  public async attachChannel(
    cartId: string,
    channelId: string,
    mainMessageId: string,
  ): Promise<void> {
    await this.prisma.cart.update({ where: { id: cartId }, data: { channelId, mainMessageId } });
  }

  public async attachPaymentMessage(cartId: string, paymentMessageId: string): Promise<void> {
    await this.prisma.cart.update({ where: { id: cartId }, data: { paymentMessageId } });
  }
}
