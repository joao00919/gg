import type { Prisma, PrismaClient } from '@prisma/client';

export interface AuditInput {
  actorId?: string;
  actorType: 'USER' | 'ADMIN' | 'SYSTEM' | 'WEBHOOK' | 'SALES_BOT';
  action: string;
  entityType: string;
  entityId?: string;
  metadataSafe?: Prisma.InputJsonValue;
}

export class AuditService {
  public constructor(private readonly prisma: PrismaClient) {}

  public async record(input: AuditInput): Promise<void> {
    await this.prisma.auditLog.create({
      data: {
        actorId: input.actorId,
        actorType: input.actorType,
        action: input.action,
        entityType: input.entityType,
        entityId: input.entityId,
        metadataSafe: input.metadataSafe,
      },
    });
  }
}
