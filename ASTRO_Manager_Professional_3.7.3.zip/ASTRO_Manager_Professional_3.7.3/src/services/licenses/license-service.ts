import type { PrismaClient } from '@prisma/client';
import { randomToken, sha256 } from '../../utils/crypto.js';
import { DomainError } from '../../utils/errors.js';
import type { AuditService } from '../audit/audit-service.js';

export interface GeneratedLicense {
  key: string;
  prefix: string;
  hash: string;
}

export function generateLicenseKey(): GeneratedLicense {
  const raw = randomToken(32).toUpperCase();
  const key = `VIS-${raw.slice(0, 8)}-${raw.slice(8, 16)}-${raw.slice(16, 24)}-${raw.slice(24, 32)}`;
  return { key, prefix: key.slice(0, 12), hash: sha256(key) };
}

export function maskLicense(prefix: string): string {
  return `${prefix}••••-••••-••••`;
}

export class LicenseService {
  public constructor(
    private readonly prisma: PrismaClient,
    private readonly audit: AuditService,
  ) {}

  public async regenerate(applicationId: string, actorDiscordId: string): Promise<string> {
    const application = await this.prisma.application.findFirst({
      where: { id: applicationId, owner: { discordId: actorDiscordId }, deletedAt: null },
      include: { license: true },
    });
    if (!application?.license)
      throw new DomainError('Licença não encontrada.', 'LICENSE_NOT_FOUND');
    const generated = generateLicenseKey();
    await this.prisma.license.update({
      where: { id: application.license.id },
      data: { keyHash: generated.hash, keyPrefix: generated.prefix },
    });
    await this.audit.record({
      actorId: actorDiscordId,
      actorType: 'USER',
      action: 'LICENSE_REGENERATE',
      entityType: 'License',
      entityId: application.license.id,
    });
    return generated.key;
  }

  public async validate(key: string, guildId?: string): Promise<boolean> {
    const hash = sha256(key);
    const license = await this.prisma.license.findUnique({
      where: { keyHash: hash },
      include: { application: { include: { instances: true } } },
    });
    const valid = Boolean(
      license &&
        ['ACTIVE', 'EXPIRING'].includes(license.status) &&
        license.expiresAt.getTime() > Date.now() &&
        (!guildId ||
          license.application.instances.some(
            (instance) => instance.guildId === guildId && instance.active,
          )),
    );
    if (license) {
      await this.prisma.$transaction([
        this.prisma.licenseValidation.create({
          data: {
            licenseId: license.id,
            guildId,
            success: valid,
            reason: valid ? undefined : 'Licença ou servidor inválido.',
          },
        }),
        this.prisma.license.update({
          where: { id: license.id },
          data: { validationCount: { increment: 1 }, lastValidatedAt: new Date() },
        }),
      ]);
    }
    return valid;
  }
}
