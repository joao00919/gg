import type { PrismaClient, WalletTransactionType } from '@prisma/client';
import { DomainError } from '../../utils/errors.js';

export class WalletService {
  public constructor(private readonly prisma: PrismaClient) {}

  public async getSummary(discordUserId: string, username?: string) {
    const user = await this.prisma.user.upsert({
      where: { discordId: discordUserId },
      update: username ? { username } : {},
      create: { discordId: discordUserId, username },
    });
    return this.prisma.wallet.upsert({
      where: { userId: user.id },
      update: {},
      create: { userId: user.id },
      include: { transactions: { orderBy: { createdAt: 'desc' }, take: 10 } },
    });
  }

  public async adjust(
    discordUserId: string,
    amountInCents: number,
    actorDiscordId: string,
    description: string,
    type: WalletTransactionType = 'ADJUSTMENT',
  ) {
    if (!Number.isInteger(amountInCents) || amountInCents === 0) {
      throw new DomainError('Informe um valor inteiro em centavos diferente de zero.', 'WALLET_INVALID_AMOUNT');
    }

    return this.prisma.$transaction(async (tx) => {
      const user = await tx.user.upsert({
        where: { discordId: discordUserId },
        update: {},
        create: { discordId: discordUserId },
      });
      const wallet = await tx.wallet.upsert({
        where: { userId: user.id },
        update: {},
        create: { userId: user.id },
      });
      const nextBalance = wallet.balanceInCents + amountInCents;
      if (nextBalance < 0) {
        throw new DomainError('O saldo da ASTRO WALLET não pode ficar negativo.', 'WALLET_INSUFFICIENT_BALANCE');
      }
      const updated = await tx.wallet.update({
        where: { id: wallet.id },
        data: { balanceInCents: nextBalance },
      });
      await tx.walletTransaction.create({
        data: {
          walletId: wallet.id,
          type,
          amountInCents,
          balanceAfterInCents: nextBalance,
          description,
          actorDiscordId,
        },
      });
      return updated;
    }, { isolationLevel: 'Serializable' });
  }
}
