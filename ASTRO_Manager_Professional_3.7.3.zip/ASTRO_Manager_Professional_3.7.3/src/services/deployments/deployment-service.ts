import type { PrismaClient } from '@prisma/client';
import type { HostingProvider } from '../../types/hosting.js';
import type { AuditService } from '../audit/audit-service.js';

export class DeploymentService {
  public constructor(
    private readonly prisma: PrismaClient,
    private readonly hosting: HostingProvider,
    private readonly audit: AuditService,
  ) {}

  public async provision(applicationId: string): Promise<void> {
    const deployment = await this.prisma.deployment.create({
      data: {
        applicationId,
        provider: this.hosting.name,
        status: 'RUNNING',
        startedAt: new Date(),
      },
    });
    try {
      await this.hosting.activateApplication(applicationId);
      await this.prisma.$transaction([
        this.prisma.deployment.update({
          where: { id: deployment.id },
          data: { status: 'SUCCEEDED', finishedAt: new Date() },
        }),
        this.prisma.application.update({
          where: { id: applicationId },
          data: { status: 'ONLINE' },
        }),
      ]);
      await this.audit.record({
        actorType: 'SYSTEM',
        action: 'DEPLOYMENT_SUCCEEDED',
        entityType: 'Application',
        entityId: applicationId,
      });
    } catch (error) {
      const message = error instanceof Error ? error.message.slice(0, 500) : 'Falha desconhecida.';
      await this.prisma.$transaction([
        this.prisma.deployment.update({
          where: { id: deployment.id },
          data: { status: 'FAILED', finishedAt: new Date(), errorSafe: message },
        }),
        this.prisma.application.update({ where: { id: applicationId }, data: { status: 'ERROR' } }),
      ]);
      throw error;
    }
  }
}
