import { Prisma, type Payment, type PrismaClient } from '@prisma/client';
import type { Env } from '../../config/env.js';
import type { Logger } from '../../config/logger.js';
import type { PaymentProvider, PaymentStatusResult, PixPayment } from '../../types/payment.js';
import { calculateRenewalExpiry } from '../../utils/time.js';
import { createIdempotencyKey } from '../../utils/idempotency.js';
import { decryptText, encryptText } from '../../utils/crypto.js';
import { DomainError } from '../../utils/errors.js';
import { KeyedLock } from '../../utils/locks.js';
import { generateLicenseKey } from '../licenses/license-service.js';
import type { AuditService } from '../audit/audit-service.js';

const terminalStatuses = new Set(['APPROVED', 'CANCELLED', 'EXPIRED', 'REJECTED', 'REFUNDED']);

export interface CreatedPayment {
  payment: Payment;
  pix: PixPayment;
}

export class PaymentService {
  private readonly lock = new KeyedLock();

  public constructor(
    private readonly prisma: PrismaClient,
    private readonly provider: PaymentProvider,
    private readonly env: Env,
    private readonly audit: AuditService,
    private readonly logger: Logger,
  ) {}

  public async createForCart(cartId: string, discordUserId: string): Promise<CreatedPayment> {
    return this.lock.runExclusive(`create:${cartId}`, async () => {
      const cart = await this.prisma.cart.findFirst({
        where: {
          id: cartId,
          user: { discordId: discordUserId },
          status: 'OPEN',
          expiresAt: { gt: new Date() },
        },
        include: {
          user: true,
          application: true,
          plan: true,
          addons: { include: { addon: true } },
        },
      });
      if (!cart)
        throw new DomainError('Carrinho inexistente, expirado ou sem permissão.', 'CART_INVALID');

      const existing = await this.prisma.payment.findUnique({ where: { cartId } });
      if (existing)
        throw new DomainError('Este carrinho já possui um pagamento.', 'PAYMENT_ALREADY_EXISTS');

      const idempotencyKey = createIdempotencyKey(`cart:${cartId}`);
      const expiresAt = new Date(Date.now() + this.env.PAYMENT_EXPIRATION_MINUTES * 60_000);
      const payment = await this.prisma.payment.create({
        data: {
          userId: cart.userId,
          applicationId: cart.applicationId,
          cartId: cart.id,
          amountInCents: cart.amountInCents,
          currency: this.env.PAYMENT_CURRENCY,
          provider: this.provider.name,
          idempotencyKey,
          expiresAt,
        },
      });

      try {
        const pix = await this.provider.createPixPayment({
          amountInCents: payment.amountInCents,
          currency: payment.currency,
          idempotencyKey,
          expiresAt,
          webhookUrl: this.env.PAYMENT_WEBHOOK_URL || undefined,
          description:
            cart.kind === 'NEW_APPLICATION'
              ? `Compra de ${cart.plan.name}`
              : cart.kind === 'ADDON'
                ? `Adicional para ${cart.application?.name ?? cart.plan.name}`
                : `Renovação de ${cart.application?.name ?? cart.plan.name}`, 
        });
        if (pix.amountInCents !== payment.amountInCents || pix.currency !== payment.currency) {
          throw new DomainError(
            'O provedor retornou um valor ou moeda divergente.',
            'PAYMENT_AMOUNT_MISMATCH',
            502,
          );
        }

        const updated = await this.prisma.$transaction(async (tx) => {
          await tx.cart.update({ where: { id: cart.id }, data: { status: 'PAYMENT_PENDING' } });
          await tx.paymentEvent.create({
            data: {
              paymentId: payment.id,
              type: 'PAYMENT_CREATED',
              payloadSafe: pix.providerPayloadSafe as Prisma.InputJsonValue,
            },
          });
          return tx.payment.update({
            where: { id: payment.id },
            data: {
              externalPaymentId: pix.externalPaymentId,
              status: pix.status === 'APPROVED' ? 'PENDING' : pix.status,
              pixCodeEncrypted: encryptText(pix.qrCodeText, this.env.ENCRYPTION_KEY),
              qrCodeImageBase64: pix.qrCodeImage.toString('base64'),
              expiresAt: pix.expiresAt,
              providerPayloadSafe: pix.providerPayloadSafe as Prisma.InputJsonValue,
              lastProviderStatus: pix.status,
            },
          });
        });
        await this.audit.record({
          actorId: discordUserId,
          actorType: 'USER',
          action: 'PAYMENT_CREATE',
          entityType: 'Payment',
          entityId: updated.id,
          metadataSafe: { provider: this.provider.name, amountInCents: updated.amountInCents },
        });
        return { payment: updated, pix };
      } catch (error) {
        await this.prisma.payment.update({ where: { id: payment.id }, data: { status: 'ERROR' } });
        this.logger.error({ err: error, paymentId: payment.id }, 'Falha ao criar pagamento');
        throw error;
      }
    });
  }

  public async getPixCode(paymentId: string, discordUserId: string): Promise<string> {
    const payment = await this.prisma.payment.findFirst({
      where: { id: paymentId, user: { discordId: discordUserId }, status: 'PENDING' },
    });
    if (!payment?.pixCodeEncrypted)
      throw new DomainError('Pagamento não encontrado ou encerrado.', 'PAYMENT_INVALID');
    return decryptText(payment.pixCodeEncrypted, this.env.ENCRYPTION_KEY);
  }

  public async cancel(paymentId: string, discordUserId: string): Promise<Payment> {
    return this.lock.runExclusive(`payment:${paymentId}`, async () => {
      const payment = await this.prisma.payment.findFirst({
        where: { id: paymentId, user: { discordId: discordUserId } },
      });
      if (!payment)
        throw new DomainError(
          'Pagamento não encontrado ou sem permissão.',
          'PAYMENT_FORBIDDEN',
          403,
        );
      if (payment.status === 'CANCELLED')
        throw new DomainError('Este pagamento já foi cancelado.', 'PAYMENT_ALREADY_CANCELLED');
      if (payment.status !== 'PENDING' && payment.status !== 'CREATED') {
        throw new DomainError('Este pagamento não pode mais ser cancelado.', 'PAYMENT_FINAL');
      }
      if (payment.externalPaymentId) await this.provider.cancelPayment(payment.externalPaymentId);
      const updated = await this.prisma.$transaction(async (tx) => {
        await tx.cart.update({ where: { id: payment.cartId }, data: { status: 'CANCELLED' } });
        await tx.paymentEvent.create({ data: { paymentId, type: 'PAYMENT_CANCELLED' } });
        return tx.payment.update({
          where: { id: paymentId },
          data: { status: 'CANCELLED', cancelledAt: new Date() },
        });
      });
      await this.audit.record({
        actorId: discordUserId,
        actorType: 'USER',
        action: 'PAYMENT_CANCEL',
        entityType: 'Payment',
        entityId: paymentId,
      });
      return updated;
    });
  }

  public async syncByExternalId(
    externalPaymentId: string,
    webhookEventId?: string,
  ): Promise<Payment> {
    const payment = await this.prisma.payment.findUnique({ where: { externalPaymentId } });
    if (!payment)
      throw new DomainError('Pagamento externo não encontrado.', 'PAYMENT_NOT_FOUND', 404);
    const status = await this.provider.getPayment(externalPaymentId);
    return this.applyProviderStatus(payment.id, status, webhookEventId);
  }

  public async sync(paymentId: string): Promise<Payment> {
    const payment = await this.prisma.payment.findUnique({ where: { id: paymentId } });
    if (!payment?.externalPaymentId)
      throw new DomainError('Pagamento ainda não possui ID externo.', 'PAYMENT_NOT_READY');
    const status = await this.provider.getPayment(payment.externalPaymentId);
    return this.applyProviderStatus(payment.id, status);
  }

  public async approveManually(paymentId: string, adminDiscordId: string): Promise<Payment> {
    const payment = await this.prisma.payment.findUnique({ where: { id: paymentId } });
    if (!payment) throw new DomainError('Pagamento não encontrado.', 'PAYMENT_NOT_FOUND', 404);
    if (payment.status === 'APPROVED') return payment;
    if (!['CREATED', 'PENDING', 'ERROR'].includes(payment.status)) {
      throw new DomainError('Este pagamento não pode ser aprovado manualmente.', 'PAYMENT_FINAL');
    }

    const updated = await this.applyProviderStatus(payment.id, {
      externalPaymentId: payment.externalPaymentId ?? `manual:${payment.id}`,
      status: 'APPROVED',
      amountInCents: payment.amountInCents,
      currency: payment.currency,
      approvedAt: new Date(),
      providerPayloadSafe: {
        source: 'admin_manual_approval',
        adminDiscordId,
      },
    });

    await this.audit.record({
      actorId: adminDiscordId,
      actorType: 'ADMIN',
      action: 'PAYMENT_MANUAL_APPROVE',
      entityType: 'Payment',
      entityId: payment.id,
      metadataSafe: { customerId: payment.userId },
    });
    return updated;
  }

  public async recoverPending(): Promise<Payment[]> {
    const pending = await this.prisma.payment.findMany({
      where: { status: 'PENDING', expiresAt: { gt: new Date() } },
    });
    return Promise.all(pending.map(async (payment) => this.sync(payment.id)));
  }

  private async applyProviderStatus(
    paymentId: string,
    result: PaymentStatusResult,
    webhookEventId?: string,
  ): Promise<Payment> {
    return this.lock.runExclusive(`payment:${paymentId}`, async () => {
      const current = await this.prisma.payment.findUniqueOrThrow({ where: { id: paymentId } });
      if (terminalStatuses.has(current.status)) return current;
      if (result.amountInCents !== current.amountInCents || result.currency !== current.currency) {
        await this.prisma.payment.update({
          where: { id: paymentId },
          data: { status: 'ERROR', lastProviderStatus: result.status },
        });
        throw new DomainError(
          'Valor ou moeda divergente no retorno do provedor.',
          'PAYMENT_AMOUNT_MISMATCH',
        );
      }

      if (result.status === 'APPROVED') return this.approve(current, result, webhookEventId);
      const mapped = result.status === 'CREATED' ? 'PENDING' : result.status;
      const status = mapped === 'ERROR' ? current.status : mapped;
      return this.prisma.payment.update({
        where: { id: paymentId },
        data: { status, lastProviderStatus: result.status, pollAttempts: { increment: 1 } },
      });
    });
  }

  private async approve(
    current: Payment,
    result: PaymentStatusResult,
    webhookEventId?: string,
  ): Promise<Payment> {
    const approvedAt = result.approvedAt ?? new Date();
    const updated = await this.prisma.$transaction(
      async (tx) => {
        const locked = await tx.payment.findUniqueOrThrow({ where: { id: current.id } });
        if (locked.status === 'APPROVED') return locked;
        if (['CANCELLED', 'EXPIRED', 'REJECTED', 'REFUNDED'].includes(locked.status)) {
          throw new DomainError('Pagamento encerrado não pode ser aprovado.', 'PAYMENT_FINAL');
        }
        const cart = await tx.cart.findUniqueOrThrow({
          where: { id: locked.cartId },
          include: { addons: { include: { addon: true } }, user: true },
        });
        const plan = await tx.plan.findUniqueOrThrow({ where: { id: cart.planId } });
        let applicationId = locked.applicationId;

        if (cart.kind === 'NEW_APPLICATION') {
          if (!applicationId) {
            const created = await tx.application.create({
              data: {
                ownerId: locked.userId,
                planId: plan.id,
                name: `${plan.name.toUpperCase()} - ${cart.user.username ?? locked.id.slice(0, 8)}`.slice(0, 100),
                status: 'PENDING_SETUP',
              },
            });
            applicationId = created.id;
            await tx.payment.update({ where: { id: locked.id }, data: { applicationId } });
          }
        } else if (!applicationId) {
          throw new DomainError('Aplicação do carrinho não foi encontrada.', 'APPLICATION_NOT_FOUND');
        }

        const existingLicense = await tx.license.findUnique({ where: { applicationId } });
        let addonExpiry = existingLicense?.expiresAt ?? approvedAt;

        if (cart.kind !== 'ADDON') {
          const previousExpiry = existingLicense?.expiresAt ?? approvedAt;
          const newExpiry = calculateRenewalExpiry(previousExpiry, approvedAt, cart.periodDays);
          addonExpiry = newExpiry;
          const generated = generateLicenseKey();
          await tx.license.upsert({
            where: { applicationId },
            update: {
              planId: plan.id,
              status: 'ACTIVE',
              activatedAt: existingLicense?.activatedAt ?? approvedAt,
              expiresAt: newExpiry,
              serverLimit: plan.serverLimit,
            },
            create: {
              applicationId,
              planId: plan.id,
              keyPrefix: generated.prefix,
              keyHash: generated.hash,
              status: 'ACTIVE',
              activatedAt: approvedAt,
              expiresAt: newExpiry,
              serverLimit: plan.serverLimit,
            },
          });
          await tx.application.update({
            where: { id: applicationId },
            data: { planId: plan.id, status: 'OFFLINE' },
          });
          await tx.renewal.create({
            data: {
              paymentId: locked.id,
              applicationId,
              previousExpiry,
              newExpiry,
              periodDays: cart.periodDays,
            },
          });
        } else if (!existingLicense || !['ACTIVE', 'EXPIRING'].includes(existingLicense.status)) {
          throw new DomainError('A licença precisa estar ativa para adquirir adicionais.', 'LICENSE_INACTIVE');
        }

        for (const item of cart.addons) {
          await tx.applicationAddon.upsert({
            where: { applicationId_addonId: { applicationId, addonId: item.addonId } },
            update: { status: 'ACTIVE', activatedAt: approvedAt, expiresAt: addonExpiry },
            create: {
              applicationId,
              addonId: item.addonId,
              status: 'ACTIVE',
              activatedAt: approvedAt,
              expiresAt: addonExpiry,
            },
          });
        }

        await tx.paymentEvent.create({
          data: {
            paymentId: locked.id,
            externalEventId: webhookEventId,
            type: 'PAYMENT_APPROVED',
            payloadSafe: result.providerPayloadSafe as Prisma.InputJsonValue,
          },
        });
        await tx.cart.update({ where: { id: cart.id }, data: { status: 'COMPLETED' } });
        return tx.payment.update({
          where: { id: locked.id },
          data: {
            status: 'APPROVED',
            approvedAt,
            lastProviderStatus: result.status,
            webhookEventId,
            applicationId,
          },
        });
      },
      { isolationLevel: Prisma.TransactionIsolationLevel.Serializable },
    );
    await this.audit.record({
      actorType: 'SYSTEM',
      action: 'PAYMENT_APPROVE',
      entityType: 'Payment',
      entityId: current.id,
      metadataSafe: { provider: this.provider.name },
    });
    return updated;
  }

  public async expireDue(): Promise<string[]> {
    const due = await this.prisma.payment.findMany({
      where: { status: 'PENDING', expiresAt: { lte: new Date() } },
    });
    const expiredIds: string[] = [];
    for (const payment of due) {
      await this.lock.runExclusive(`payment:${payment.id}`, async () => {
        const current = await this.prisma.payment.findUniqueOrThrow({ where: { id: payment.id } });
        if (current.status !== 'PENDING') return;
        await this.prisma.$transaction([
          this.prisma.payment.update({ where: { id: current.id }, data: { status: 'EXPIRED' } }),
          this.prisma.cart.update({ where: { id: current.cartId }, data: { status: 'EXPIRED' } }),
          this.prisma.paymentEvent.create({
            data: { paymentId: current.id, type: 'PAYMENT_EXPIRED' },
          }),
        ]);
        expiredIds.push(current.id);
      });
    }
    return expiredIds;
  }
}
