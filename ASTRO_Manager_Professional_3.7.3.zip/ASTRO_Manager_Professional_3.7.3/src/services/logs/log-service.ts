import type { HostingProvider } from '../../types/hosting.js';
import { redactText } from '../../utils/redact.js';

/**
 * Camada única de acesso aos logs das aplicações.
 * Limita a quantidade solicitada e remove dados sensíveis antes de devolver
 * qualquer conteúdo para os comandos do Discord.
 */
export class LogService {
  public constructor(private readonly hostingProvider: HostingProvider) {}

  public async getRecent(applicationId: string, limit = 100): Promise<string[]> {
    const safeLimit = Math.max(1, Math.min(Math.trunc(limit), 500));
    const entries = await this.hostingProvider.getLogs(applicationId, safeLimit);
    return entries.slice(0, safeLimit).map((entry) => redactText(entry));
  }
}
