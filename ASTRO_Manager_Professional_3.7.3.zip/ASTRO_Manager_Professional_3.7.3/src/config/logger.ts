import pino from 'pino';
import type { Env } from './env.js';

const redactPaths = [
  'req.headers.authorization',
  'req.headers.cookie',
  'MANAGER_BOT_TOKEN',
  'PAYMENT_ACCESS_TOKEN',
  'PAYMENT_WEBHOOK_SECRET',
  'INTERNAL_API_KEY',
  'CUSTOM_ID_SECRET',
  'ENCRYPTION_KEY',
  '*.token',
  '*.secret',
  '*.authorization',
  '*.pixCode',
  '*.licenseKey',
];

export function createLogger(env: Pick<Env, 'NODE_ENV'>) {
  return pino({
    level: env.NODE_ENV === 'production' ? 'info' : 'debug',
    redact: { paths: redactPaths, censor: '[REDACTED]' },
    transport:
      env.NODE_ENV === 'development'
        ? { target: 'pino-pretty', options: { colorize: true, translateTime: 'SYS:standard' } }
        : undefined,
  });
}

export type Logger = ReturnType<typeof createLogger>;
