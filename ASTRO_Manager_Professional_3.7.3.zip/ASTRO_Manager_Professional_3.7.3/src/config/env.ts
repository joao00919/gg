import 'dotenv/config';

import { z } from 'zod';

const snowflake = z.string().regex(/^\d{17,20}$/, 'precisa ser um ID válido do Discord.');
const optionalSnowflake = z
  .union([snowflake, z.literal('')])
  .optional()
  .transform((value) => (value?.length ? value : undefined));
const csvSnowflakes = z
  .string()
  .default('')
  .transform((value) =>
    value
      .split(',')
      .map((item) => item.trim())
      .filter(Boolean),
  )
  .pipe(z.array(snowflake));

const required = (name: string) => z.string().min(1, `${name} não foi configurado.`);

export const envSchema = z
  .object({
    NODE_ENV: z.enum(['development', 'test', 'production']).default('development'),
    MANAGER_BOT_TOKEN: required('MANAGER_BOT_TOKEN'),
    MANAGER_CLIENT_ID: snowflake.refine(Boolean, 'MANAGER_CLIENT_ID não foi configurado.'),
    MANAGER_GUILD_ID: snowflake.refine(Boolean, 'MANAGER_GUILD_ID não foi configurado.'),
    DATABASE_URL: z
      .string()
      .url('DATABASE_URL precisa ser uma URL PostgreSQL válida.')
      .refine((value) => {
        try {
          const parsed = new URL(value);
          return (
            parsed.protocol.startsWith('postgres') &&
            parsed.searchParams.get('schema') === 'vision_manager'
          );
        } catch {
          return false;
        }
      }, 'DATABASE_URL deve apontar para PostgreSQL e incluir schema=vision_manager para proteger outras tabelas.'),
    DATABASE_CONNECT_TIMEOUT_MS: z.coerce.number().int().min(1000).max(120000).default(15000),
    DATABASE_POOL_MAX: z.coerce.number().int().min(1).max(50).default(10),
    DATABASE_STARTUP_RETRIES: z.coerce.number().int().min(1).max(100).default(12),
    DATABASE_RETRY_BASE_MS: z.coerce.number().int().min(250).max(60000).default(2000),
    DATABASE_RETRY_MAX_MS: z.coerce.number().int().min(500).max(120000).default(15000),
    API_HOST: z.string().default('0.0.0.0'),
    API_PORT: z.coerce.number().int().min(1).max(65535).default(3001),
    MANAGER_PUBLIC_API_URL: z.union([z.string().url(), z.literal('')]).default(''),
    INTERNAL_API_KEY: required('INTERNAL_API_KEY').min(
      32,
      'INTERNAL_API_KEY deve ter ao menos 32 caracteres.',
    ),
    ENCRYPTION_KEY: required('ENCRYPTION_KEY').min(
      32,
      'ENCRYPTION_KEY deve ter ao menos 32 caracteres.',
    ),
    CUSTOM_ID_SECRET: required('CUSTOM_ID_SECRET').min(
      32,
      'CUSTOM_ID_SECRET deve ter ao menos 32 caracteres.',
    ),
    SALES_BOT_API_URL: z.union([z.string().url(), z.literal('')]).default(''),
    SALES_BOT_API_KEY: z.string().default(''),
    PAYMENT_PROVIDER: z.enum(['promisse', 'manual', 'mock']).default('mock'),
    PAYMENT_API_URL: z.string().url().default('https://api.promisse.com.br'),
    PAYMENT_ACCESS_TOKEN: z.string().default(''),
    PAYMENT_WEBHOOK_SECRET: z.string().default(''),
    PAYMENT_WEBHOOK_URL: z.union([z.string().url(), z.literal('')]).default(''),
    PAYMENT_POLL_INTERVAL_MS: z.coerce.number().int().min(1000).default(5000),
    PAYMENT_POLL_MAX_ATTEMPTS: z.coerce.number().int().min(1).max(10000).default(120),
    PAYMENT_EXPIRATION_MINUTES: z.coerce.number().int().min(1).max(1440).default(10),
    PAYMENT_CURRENCY: z.string().length(3).default('BRL'),
    OWNER_IDS: csvSnowflakes,
    ADMIN_ROLE_IDS: csvSnowflakes,
    LOG_CHANNEL_ID: optionalSnowflake,
    SUPPORT_CHANNEL_ID: optionalSnowflake,
    SALES_CHANNEL_ID: optionalSnowflake,
    CART_PARENT_CHANNEL_ID: optionalSnowflake,
    BRAND_NAME: z.string().min(1).default('ASTRO BOT'),
    BRAND_DESCRIPTION: z
      .string()
      .min(1)
      .default('Gerencie suas aplicações, licenças e pagamentos.'),
    BRAND_LOGO_URL: z.union([z.string().url(), z.literal('')]).default(''),
    BRAND_BANNER_URL: z.union([z.string().url(), z.literal('')]).default(''),
    COMMANDS_BANNER_URL: z.union([z.string().url(), z.literal('')]).default(''),
    STORE_BANNER_URL: z.union([z.string().url(), z.literal('')]).default(''),
    DASHBOARD_URL: z.union([z.string().url(), z.literal('')]).default(''),
    PREVIEW_BOTS_URL: z.union([z.string().url(), z.literal('')]).default(''),
    BRAND_PRIMARY_COLOR: z
      .string()
      .regex(/^[0-9A-Fa-f]{6}$/)
      .default('5865F2'),
    BRAND_SECONDARY_COLOR: z
      .string()
      .regex(/^[0-9A-Fa-f]{6}$/)
      .default('2B2D31'),
    CUSTOM_EMOJI_LOADING: z.string().default(''),
    CUSTOM_EMOJI_SUCCESS: z.string().default(''),
    CUSTOM_EMOJI_ERROR: z.string().default(''),
    CUSTOM_EMOJI_CART: z.string().default(''),
    CUSTOM_EMOJI_CART_OPENED: z.string().default(''),
    CUSTOM_EMOJI_PAYMENT_CANCELLED: z.string().default(''),
    CUSTOM_EMOJI_PIX: z.string().default(''),
    CUSTOM_EMOJI_APP: z.string().default(''),
    CUSTOM_EMOJI_START: z.string().default(''),
    CUSTOM_EMOJI_RESTART: z.string().default(''),
    CUSTOM_EMOJI_STOP: z.string().default(''),
    CUSTOM_EMOJI_SETTINGS: z.string().default(''),
    CUSTOM_EMOJI_MEMBER: z.string().default(''),
    CUSTOM_EMOJI_SEARCH: z.string().default(''),
    CUSTOM_EMOJI_ROLE: z.string().default(''),
    CUSTOM_EMOJI_DELETE: z.string().default(''),
    CUSTOM_EMOJI_DOLLAR: z.string().default(''),
    CUSTOM_EMOJI_CORRECT: z.string().default(''),
    CUSTOM_EMOJI_TICKET: z.string().default(''),
    CUSTOM_EMOJI_WEB: z.string().default(''),
    CUSTOM_EMOJI_ONLINE: z.string().default(''),
    CUSTOM_EMOJI_OFF: z.string().default(''),
    CUSTOM_EMOJI_WALLET: z.string().default(''),
    CUSTOM_EMOJI_POWER: z.string().default(''),
    CUSTOM_EMOJI_RELOAD: z.string().default(''),
    CUSTOM_EMOJI_SAVE: z.string().default(''),
    CUSTOM_EMOJI_ROCKET: z.string().default(''),
    CUSTOM_EMOJI_PAUSE: z.string().default(''),
    CUSTOM_EMOJI_PLAY: z.string().default(''),
    CUSTOM_EMOJI_FOLDER: z.string().default(''),
    CUSTOM_EMOJI_DONATION: z.string().default(''),
    CUSTOM_EMOJI_CARDBOX: z.string().default(''),
    CUSTOM_EMOJI_CARD: z.string().default(''),
    CUSTOM_EMOJI_PLUS: z.string().default(''),
    CUSTOM_EMOJI_CONFIG: z.string().default(''),
    CUSTOM_EMOJI_COMMANDS: z.string().default(''),
    CUSTOM_EMOJI_TRUSTED: z.string().default(''),
    CUSTOM_EMOJI_TEAM: z.string().default(''),
    CUSTOM_EMOJI_SERVERS: z.string().default(''),
    CUSTOM_EMOJI_TRANSFER: z.string().default(''),
    CUSTOM_EMOJI_MODERATION: z.string().default(''),
    CUSTOM_EMOJI_CHECKOUT: z.string().default(''),
    HOSTING_PROVIDER: z.enum(['mock', 'sales-api', 'docker', 'square']).default('sales-api'),
    ARCHIVE_CART_DELAY_MINUTES: z.coerce.number().int().min(1).default(10),
    CART_DELETE_DELAY_SECONDS: z.coerce.number().int().min(0).max(60).default(3),
    LICENSE_JOB_INTERVAL_MS: z.coerce.number().int().min(10000).default(60000),
    WALLET_AUTO_RENEW_LEAD_HOURS: z.coerce.number().int().min(1).max(168).default(24),
    DEFAULT_PLAN_PERIOD_DAYS: z.coerce.number().int().min(1).max(3650).default(1),
  })
  .superRefine((data, context) => {
    if (data.DATABASE_RETRY_MAX_MS < data.DATABASE_RETRY_BASE_MS) {
      context.addIssue({
        code: 'custom',
        path: ['DATABASE_RETRY_MAX_MS'],
        message: 'DATABASE_RETRY_MAX_MS deve ser maior ou igual a DATABASE_RETRY_BASE_MS.',
      });
    }
    if (data.PAYMENT_PROVIDER === 'promisse' && data.PAYMENT_ACCESS_TOKEN.length === 0) {
      context.addIssue({
        code: 'custom',
        path: ['PAYMENT_ACCESS_TOKEN'],
        message: 'PAYMENT_ACCESS_TOKEN não foi configurado.',
      });
    }
    if (data.PAYMENT_WEBHOOK_URL.length > 0 && data.PAYMENT_WEBHOOK_SECRET.length < 16) {
      context.addIssue({
        code: 'custom',
        path: ['PAYMENT_WEBHOOK_SECRET'],
        message:
          'PAYMENT_WEBHOOK_SECRET deve ter ao menos 16 caracteres quando o webhook estiver ativo.',
      });
    }
  });

export type Env = z.infer<typeof envSchema>;

export function parseEnv(input: NodeJS.ProcessEnv): Env {
  const result = envSchema.safeParse(input);
  if (result.success) return result.data;

  const message = result.error.issues
    .map((issue) => `${issue.path.join('.') || 'ambiente'}: ${issue.message}`)
    .join('\n');
  throw new Error(`Configuração inválida:\n${message}`);
}

let cachedEnv: Env | undefined;

export function getEnv(): Env {
  cachedEnv ??= parseEnv(process.env);
  return cachedEnv;
}

export function resetEnvCache(): void {
  cachedEnv = undefined;
}
