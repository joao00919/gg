import type { Env } from './env.js';
import { normalizeDisplayEmoji } from '../bot/components/helpers.js';

export interface BrandConfig {
  name: string;
  description: string;
  logoUrl?: string;
  bannerUrl?: string;
  commandsBannerUrl?: string;
  storeBannerUrl?: string;
  dashboardUrl?: string;
  previewBotsUrl?: string;
  primaryColor: number;
  secondaryColor: number;
  emojis: {
    loading?: string;
    success?: string;
    error?: string;
    cart?: string;
    cartOpened?: string;
    paymentCancelled?: string;
    pix?: string;
    app?: string;
    start?: string;
    restart?: string;
    stop?: string;
    settings?: string;
    member?: string;
    search?: string;
    role?: string;
    delete?: string;
    dollar?: string;
    correct?: string;
    ticket?: string;
    web?: string;
    online?: string;
    off?: string;
    wallet?: string;
    power?: string;
    reload?: string;
    save?: string;
    rocket?: string;
    pause?: string;
    play?: string;
    folder?: string;
    donation?: string;
    cardbox?: string;
    card?: string;
    plus?: string;
    config?: string;
    commands?: string;
    trusted?: string;
    team?: string;
    servers?: string;
    transfer?: string;
    moderation?: string;
    checkout?: string;
  };
}

export function buildBrand(env: Env): BrandConfig {
  const optional = (value: string): string | undefined => value.trim() || undefined;
  const display = (value: string, fallback: string, name: string): string | undefined => {
    const selected = optional(value);
    if (!selected && !fallback) return undefined;
    return normalizeDisplayEmoji(selected, fallback, name);
  };
  return {
    name: env.BRAND_NAME,
    description: env.BRAND_DESCRIPTION,
    logoUrl: optional(env.BRAND_LOGO_URL),
    bannerUrl: optional(env.BRAND_BANNER_URL),
    commandsBannerUrl: optional(env.COMMANDS_BANNER_URL),
    storeBannerUrl: optional(env.STORE_BANNER_URL),
    dashboardUrl: optional(env.DASHBOARD_URL),
    previewBotsUrl: optional(env.PREVIEW_BOTS_URL),
    primaryColor: Number.parseInt(env.BRAND_PRIMARY_COLOR, 16),
    secondaryColor: Number.parseInt(env.BRAND_SECONDARY_COLOR, 16),
    emojis: {
      loading: display(
        env.CUSTOM_EMOJI_LOADING,
        '<a:astro_loading:1527386782776164392>',
        'astro_loading',
      ),
      success: display(env.CUSTOM_EMOJI_SUCCESS, '', 'astro_success'),
      error: display(env.CUSTOM_EMOJI_ERROR, '', 'astro_error'),
      cart: display(
        env.CUSTOM_EMOJI_CART,
        '<:astro_cart:1527389252315385876>',
        'astro_cart',
      ),
      cartOpened: display(
        env.CUSTOM_EMOJI_CART_OPENED,
        '<:astro_cart_opened:1527388353044156546>',
        'astro_cart_opened',
      ),
      paymentCancelled: display(
        env.CUSTOM_EMOJI_PAYMENT_CANCELLED,
        '<:payment_cancelled:1527388353044156546>',
        'payment_cancelled',
      ),
      pix: display(env.CUSTOM_EMOJI_PIX, '', 'astro_pix'),
      app: display(env.CUSTOM_EMOJI_APP, '', 'astro_app'),
      start: display(env.CUSTOM_EMOJI_START, '', 'astro_start'),
      restart: display(env.CUSTOM_EMOJI_RESTART, '', 'astro_restart'),
      stop: display(env.CUSTOM_EMOJI_STOP, '', 'astro_stop'),
      settings: display(env.CUSTOM_EMOJI_SETTINGS, '', 'astro_settings'),
      member: display(env.CUSTOM_EMOJI_MEMBER, '', 'astro_member'),
      search: display(env.CUSTOM_EMOJI_SEARCH, '', 'astro_search'),
      role: display(env.CUSTOM_EMOJI_ROLE, '', 'astro_role'),
      delete: display(env.CUSTOM_EMOJI_DELETE, '', 'astro_delete'),
      dollar: display(env.CUSTOM_EMOJI_DOLLAR, '', 'astro_dollar'),
      correct: display(env.CUSTOM_EMOJI_CORRECT, '', 'astro_correct'),
      ticket: display(env.CUSTOM_EMOJI_TICKET, '', 'astro_ticket'),
      web: display(env.CUSTOM_EMOJI_WEB, '', 'astro_web'),
      online: display(env.CUSTOM_EMOJI_ONLINE, '', 'astro_online'),
      off: display(env.CUSTOM_EMOJI_OFF, '', 'astro_off'),
      wallet: display(env.CUSTOM_EMOJI_WALLET, '<:wallet:1525692260879175791>', 'astro_wallet'),
      power: display(env.CUSTOM_EMOJI_POWER, '<:power:1525692188229373972>', 'astro_power'),
      reload: display(env.CUSTOM_EMOJI_RELOAD, '<:reload:1525692196676833321>', 'astro_reload'),
      save: display(env.CUSTOM_EMOJI_SAVE, '<:save:1525692205564559370>', 'astro_save'),
      rocket: display(env.CUSTOM_EMOJI_ROCKET, '<:rocket:1525692203622600774>', 'astro_rocket'),
      pause: display(env.CUSTOM_EMOJI_PAUSE, '<:pause:1525692169220915200>', 'astro_pause'),
      play: display(env.CUSTOM_EMOJI_PLAY, '<:play:1525692181539586119>', 'astro_play'),
      folder: display(env.CUSTOM_EMOJI_FOLDER, '<:folder:1525692080566046821>', 'astro_folder'),
      donation: display(env.CUSTOM_EMOJI_DONATION, '<:donation:1525692052719927336>', 'astro_donation'),
      cardbox: display(env.CUSTOM_EMOJI_CARDBOX, '<:cardbox:1525692014870663330>', 'astro_cardbox'),
      card: display(env.CUSTOM_EMOJI_CARD, '<:card:1525692012026794054>', 'astro_card'),
      plus: display(env.CUSTOM_EMOJI_PLUS, '<:plus:1525692182701281321>', 'astro_plus'),
      config: display(env.CUSTOM_EMOJI_CONFIG, '<:config:1525692035103850597>', 'astro_config'),
      commands: display(env.CUSTOM_EMOJI_COMMANDS, '<:commands:1525692033333858344>', 'astro_commands'),
      trusted: display(env.CUSTOM_EMOJI_TRUSTED, '<:trusted:1527435784964145305>', 'astro_trusted'),
      team: display(env.CUSTOM_EMOJI_TEAM, '<:team:1527435783382761602>', 'astro_team'),
      servers: display(env.CUSTOM_EMOJI_SERVERS, '<:servers:1527435781654708254>', 'astro_servers'),
      transfer: display(env.CUSTOM_EMOJI_TRANSFER, '<:transfer:1527435780296020038>', 'astro_transfer'),
      moderation: display(env.CUSTOM_EMOJI_MODERATION, '<:moderation:1527435778815295628>', 'astro_moderation'),
      checkout: display(env.CUSTOM_EMOJI_CHECKOUT, '<:checkout:1527441682545770567>', 'astro_checkout'),
    },
  };
}
