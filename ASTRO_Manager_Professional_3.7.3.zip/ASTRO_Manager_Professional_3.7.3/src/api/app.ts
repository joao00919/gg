import express from 'express';
import helmet from 'helmet';
import rateLimit from 'express-rate-limit';
import { pinoHttp } from 'pino-http';
import type { AppContext } from '../context.js';
import type { RawBodyRequest } from './types.js';
import { errorHandler } from './middlewares/error-handler.js';
import { healthRouter } from './routes/health.js';
import { internalRouter } from './routes/internal.js';
import { paymentWebhookRouter } from './webhooks/payment-webhook.js';

export function createApi(context: AppContext) {
  const app = express();
  app.disable('x-powered-by');
  app.use(helmet());
  app.use(pinoHttp({ logger: context.logger }));
  app.use(
    rateLimit({
      windowMs: 60_000,
      limit: 120,
      standardHeaders: true,
      legacyHeaders: false,
    }),
  );
  app.use(
    express.json({
      limit: '1mb',
      verify: (request, _response, buffer) => {
        (request as RawBodyRequest).rawBody = Buffer.from(buffer);
      },
    }),
  );

  app.use('/health', healthRouter(context.prisma));
  app.use(
    '/webhooks/payments',
    paymentWebhookRouter(
      context.prisma,
      context.paymentProvider,
      context.payments,
      context.paymentMessages,
    ),
  );
  app.use('/internal/v1', internalRouter(context.env, context.sales, context.licenses));
  app.use(errorHandler(context.logger));
  return app;
}
