import { Router } from 'express';
import type { PrismaClient } from '@prisma/client';
import type { PaymentProvider } from '../../types/payment.js';
import type { PaymentService } from '../../services/payments/payment-service.js';
import type { PaymentMessageService } from '../../bot/messages/payment-message-service.js';
import type { RawBodyRequest } from '../types.js';
import { sha256 } from '../../utils/crypto.js';
import { DomainError } from '../../utils/errors.js';

export function paymentWebhookRouter(
  prisma: PrismaClient,
  provider: PaymentProvider,
  payments: PaymentService,
  messages: PaymentMessageService,
): Router {
  const router = Router();
  router.post('/', async (request, response) => {
    const rawRequest = request as RawBodyRequest;
    const rawBody = rawRequest.rawBody ?? Buffer.from(JSON.stringify(request.body));
    const querySecret = typeof request.query.secret === 'string' ? request.query.secret : undefined;
    const validated = await provider.validateWebhook({
      rawBody,
      headers: {
        ...request.headers,
        ...(querySecret ? { 'x-vision-webhook-secret': querySecret } : {}),
      },
      payload: request.body,
    });
    if (!validated.valid) throw new DomainError('Webhook inválido.', 'INVALID_WEBHOOK', 401);

    const event = await prisma.webhookEvent.upsert({
      where: {
        provider_externalId: { provider: provider.name, externalId: validated.externalEventId },
      },
      update: {},
      create: {
        provider: provider.name,
        externalId: validated.externalEventId,
        payloadHash: sha256(rawBody),
      },
    });
    if (event.processedAt) {
      response.status(200).json({ accepted: true, duplicate: true });
      return;
    }

    const payment = await payments.syncByExternalId(
      validated.externalPaymentId,
      validated.externalEventId,
    );
    await prisma.webhookEvent.update({
      where: { id: event.id },
      data: { processedAt: new Date() },
    });
    await messages.refresh(payment.id);
    response.status(200).json({ accepted: true, duplicate: false });
  });
  return router;
}
