import type { ErrorRequestHandler } from 'express';
import type { Logger } from '../../config/logger.js';
import { DomainError } from '../../utils/errors.js';

export function errorHandler(logger: Logger): ErrorRequestHandler {
  return (error: unknown, _request, response, _next) => {
    if (error instanceof DomainError) {
      response.status(error.statusCode).json({ error: error.code, message: error.message });
      return;
    }
    logger.error({ err: error }, 'Erro não tratado na API');
    response.status(500).json({ error: 'INTERNAL_ERROR', message: 'Erro interno.' });
  };
}
