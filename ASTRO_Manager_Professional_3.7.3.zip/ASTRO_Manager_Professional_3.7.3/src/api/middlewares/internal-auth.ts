import type { NextFunction, Request, Response } from 'express';
import { verifyHmac } from '../../utils/crypto.js';
import type { Env } from '../../config/env.js';
import type { RawBodyRequest } from '../types.js';

export function internalAuth(env: Env) {
  return (request: Request, response: Response, next: NextFunction): void => {
    const apiKey = request.header('x-api-key') ?? '';
    const timestamp = request.header('x-timestamp') ?? '';
    const signature = request.header('x-signature') ?? '';
    if (apiKey !== env.INTERNAL_API_KEY || !/^\d{13}$/.test(timestamp)) {
      response.status(401).json({ error: 'UNAUTHORIZED' });
      return;
    }
    const age = Math.abs(Date.now() - Number(timestamp));
    if (age > 5 * 60_000) {
      response.status(401).json({ error: 'REQUEST_EXPIRED' });
      return;
    }
    const fallbackBody = request.body === undefined ? '' : JSON.stringify(request.body);
    const raw = (request as RawBodyRequest).rawBody ?? Buffer.from(fallbackBody);
    const payload = `${timestamp}.${raw.toString('utf8')}`;
    if (
      !signature ||
      !verifyHmac(
        payload,
        signature,
        env.SALES_BOT_API_KEY.length > 0 ? env.SALES_BOT_API_KEY : env.INTERNAL_API_KEY,
      )
    ) {
      response.status(401).json({ error: 'INVALID_SIGNATURE' });
      return;
    }
    next();
  };
}
