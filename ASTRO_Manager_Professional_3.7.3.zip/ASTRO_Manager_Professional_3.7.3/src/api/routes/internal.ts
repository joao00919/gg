import { Router, type RequestHandler } from 'express';
import type { Env } from '../../config/env.js';
import type { SalesIntegrationService } from '../../integrations/sales-bot/sales-service.js';
import { salesPurchaseSchema } from '../../integrations/sales-bot/sales-schema.js';
import type { LicenseService } from '../../services/licenses/license-service.js';
import { internalAuth } from '../middlewares/internal-auth.js';

export function internalRouter(
  env: Env,
  sales: SalesIntegrationService,
  licenses: LicenseService,
): Router {
  const router = Router();
  router.use(internalAuth(env));

  const purchaseHandler: RequestHandler = async (request, response) => {
    const input = salesPurchaseSchema.parse(request.body);
    const result = await sales.provision(input);
    response.status(result.idempotent ? 200 : 201).json({
      ok: true,
      released: true,
      ...result,
      nextCommand: '/apps',
    });
  };

  // Endpoint principal e aliases para facilitar a integração de bots de venda existentes.
  router.post('/purchases', purchaseHandler);
  router.post('/sales/purchases', purchaseHandler);
  router.post('/purchases/approved', purchaseHandler);

  router.get('/integration/status', (_request, response) => {
    response.json({
      ok: true,
      service: 'vision-manager-sales-integration',
      version: 1,
      purchaseEndpoints: [
        '/internal/v1/purchases',
        '/internal/v1/sales/purchases',
        '/internal/v1/purchases/approved',
      ],
    });
  });

  router.post('/licenses/validate', async (request, response) => {
    const body = request.body as Record<string, unknown>;
    const key = typeof body.key === 'string' ? body.key : '';
    const guildId = typeof body.guildId === 'string' ? body.guildId : undefined;
    const valid = key ? await licenses.validate(key, guildId) : false;
    response.status(valid ? 200 : 403).json({ valid });
  });

  return router;
}
