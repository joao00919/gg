import { Router } from 'express';
import type { PrismaClient } from '@prisma/client';

export function healthRouter(prisma: PrismaClient): Router {
  const router = Router();
  router.get('/', async (_request, response) => {
    await prisma.$queryRaw`SELECT 1`;
    response.json({ status: 'ok', database: 'connected', timestamp: new Date().toISOString() });
  });
  return router;
}
