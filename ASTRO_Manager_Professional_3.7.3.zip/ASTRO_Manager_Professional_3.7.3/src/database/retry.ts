const TRANSIENT_DATABASE_CODES = new Set([
  'ETIMEDOUT',
  'ECONNRESET',
  'ECONNREFUSED',
  'EHOSTUNREACH',
  'ENETUNREACH',
  'EPIPE',
  'P1001',
  'P1002',
  'P2024',
  '08000',
  '08001',
  '08003',
  '08004',
  '08006',
  '08007',
  '08P01',
  '53300',
  '57P01',
  '57P02',
  '57P03',
]);

const TRANSIENT_MESSAGE_PATTERNS = [
  /timed?\s*out/i,
  /connection.*(?:closed|reset|refused|terminated)/i,
  /server closed the connection/i,
  /can't reach database server/i,
  /could not connect to server/i,
  /temporary failure/i,
  /network is unreachable/i,
];

export interface DatabaseRetryOptions {
  attempts: number;
  baseDelayMs: number;
  maxDelayMs: number;
  operation: string;
  onRetry?: (details: {
    attempt: number;
    attempts: number;
    delayMs: number;
    operation: string;
    error: unknown;
  }) => void;
}

function readErrorCode(error: unknown): string | undefined {
  if (!error || typeof error !== 'object') return undefined;
  const record = error as Record<string, unknown>;
  if (typeof record.code === 'string') return record.code;
  if (record.cause && record.cause !== error) return readErrorCode(record.cause);
  return undefined;
}

function readErrorMessage(error: unknown): string {
  if (error instanceof Error) return error.message;
  if (typeof error === 'string') return error;
  return '';
}

export function isTransientDatabaseError(error: unknown): boolean {
  const code = readErrorCode(error);
  if (code && TRANSIENT_DATABASE_CODES.has(code.toUpperCase())) return true;

  const message = readErrorMessage(error);
  return TRANSIENT_MESSAGE_PATTERNS.some((pattern) => pattern.test(message));
}

function delayForAttempt(attempt: number, baseDelayMs: number, maxDelayMs: number): number {
  const exponential = baseDelayMs * 2 ** Math.max(0, attempt - 1);
  return Math.min(exponential, maxDelayMs);
}

function sleep(milliseconds: number): Promise<void> {
  return new Promise((resolve) => setTimeout(resolve, milliseconds));
}

export async function retryDatabaseOperation<T>(
  callback: () => Promise<T>,
  options: DatabaseRetryOptions,
): Promise<T> {
  const attempts = Math.max(1, Math.trunc(options.attempts));

  for (let attempt = 1; attempt <= attempts; attempt += 1) {
    try {
      return await callback();
    } catch (error) {
      const canRetry = attempt < attempts && isTransientDatabaseError(error);
      if (!canRetry) throw error;

      const delayMs = delayForAttempt(attempt, options.baseDelayMs, options.maxDelayMs);
      options.onRetry?.({
        attempt,
        attempts,
        delayMs,
        operation: options.operation,
        error,
      });
      await sleep(delayMs);
    }
  }

  throw new Error(`Falha inesperada ao executar ${options.operation}.`);
}
