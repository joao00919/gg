import { PrismaPg } from '@prisma/adapter-pg';
import { PrismaClient } from '@prisma/client';
import type { PoolConfig } from 'pg';

import { parsePostgresConnection } from './connection.js';

const databaseUrl = process.env.DATABASE_URL;
if (!databaseUrl) throw new Error('DATABASE_URL não foi configurada.');

const { connectionString, schema } = parsePostgresConnection(databaseUrl);

function readPositiveInteger(name: string, fallback: number): number {
  const value = Number(process.env[name]);
  return Number.isInteger(value) && value > 0 ? value : fallback;
}

const poolConfig: PoolConfig = {
  connectionString,
  connectionTimeoutMillis: readPositiveInteger('DATABASE_CONNECT_TIMEOUT_MS', 15000),
  idleTimeoutMillis: 30000,
  keepAlive: true,
  max: readPositiveInteger('DATABASE_POOL_MAX', 10),
};

export const prisma = new PrismaClient({
  adapter: new PrismaPg(poolConfig, { schema }),
  log: process.env.NODE_ENV === 'development' ? ['warn', 'error'] : ['error'],
});
