export interface ParsedPostgresConnection {
  connectionString: string;
  schema: string;
}

export function parsePostgresConnection(databaseUrl: string): ParsedPostgresConnection {
  const parsed = new URL(databaseUrl);
  const schema = parsed.searchParams.get('schema')?.trim() ?? 'public';
  parsed.searchParams.delete('schema');

  // pg currently treats sslmode=require as verify-full and emits a migration warning.
  // Make that behavior explicit so future pg versions do not silently weaken TLS checks.
  if (parsed.searchParams.get('sslmode') === 'require') {
    parsed.searchParams.set('sslmode', 'verify-full');
  }

  return {
    connectionString: parsed.toString(),
    schema,
  };
}
