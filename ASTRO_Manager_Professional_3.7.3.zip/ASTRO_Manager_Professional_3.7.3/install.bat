@echo off
setlocal
cd /d "%~dp0"
where node >nul 2>nul || (echo Node.js nao foi encontrado. Instale o Node.js LTS 20 ou superior.& pause & exit /b 1)
if not exist .env copy .env.example .env >nul

> .npmrc echo registry=https://registry.npmjs.org/
>> .npmrc echo fund=false
>> .npmrc echo audit=true
call npm config set registry https://registry.npmjs.org/ --location=project

call npm install --registry=https://registry.npmjs.org/
if errorlevel 1 goto :error
call npm run prisma:generate
if errorlevel 1 goto :error
call npm run build
if errorlevel 1 goto :error
echo.
echo Instalacao concluida. Edite o arquivo .env antes de iniciar.
pause
exit /b 0
:error
echo.
echo A instalacao falhou. Revise o erro acima.
pause
exit /b 1
