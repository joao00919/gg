@echo off
setlocal
cd /d "%~dp0"
echo.
echo ASTRO Manager 3.2 - preparacao
if not exist .env (
  echo AVISO: arquivo .env nao encontrado. Copie .env.example para .env e configure.
)
call npm install --registry=https://registry.npmjs.org/
if errorlevel 1 goto :erro
call npm run prisma:generate
if errorlevel 1 goto :erro
call npm run build
if errorlevel 1 goto :erro
echo.
echo Atualizacao concluida. Para ligar, execute: npm run dev
pause
exit /b 0
:erro
echo.
echo A atualizacao falhou. Revise o erro acima.
pause
exit /b 1
