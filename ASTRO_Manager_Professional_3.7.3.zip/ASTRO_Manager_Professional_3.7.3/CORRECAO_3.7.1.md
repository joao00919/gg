# Correção 3.7.1 — estabilidade das interações

- Remove o texto de carregamento antigo ao abrir qualquer painel por `editReply` ou `update`.
- `/apps` usa uma única resposta de carregamento e substitui corretamente todo o conteúdo.
- Botões comuns são reconhecidos imediatamente com `deferUpdate`, reduzindo falhas por tempo limite.
- Transferência valida usuário, bloqueia bots/contas de sistema e verifica pagamentos e cooldown antes da confirmação.
- Troca de proprietário usa atualização atômica para impedir duas transferências concorrentes.
- Falhas em slash commands substituem a tela de carregamento em vez de criar uma mensagem separada.
- `.env.example` inicia em modo `mock` e não ativa webhook incompleto por padrão.
