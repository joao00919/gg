# Relatório de validação — ASTRO Manager 3.2

Data: 16/07/2026

## Correção principal

Foi corrigido o erro do Discord:

```text
COMPONENT_INVALID_EMOJI
components[0].components[0].options[*].emoji.name: Invalid emoji
```

A causa era o envio de nomes incorretos ou numéricos dentro do objeto de emoji de botões e select menus.

## Mudanças validadas

- componente personalizado usa somente o ID autoritativo do emoji;
- menções textuais com nome numérico são normalizadas para um nome sintaticamente válido;
- opções de período e adicionais usam emojis Unicode seguros;
- botão de copiar PIX usa emoji Unicode seguro;
- emoji personalizado do carrinho permanece no título do embed;
- emoji animado de carregamento permanece na mensagem textual;
- painel não fica vazio quando os emojis do `.env` têm nomes incorretos.

## Testes executados

```text
Test Files: 17 passed
Tests: 59 passed
```

Inclui testes de regressão específicos para:

- emoji com nome numérico;
- emoji animado com nome numérico;
- normalização da menção textual;
- ausência de IDs personalizados inválidos nos componentes críticos do carrinho;
- renderização do emoji personalizado do carrinho no embed.

## Outras validações

- ESLint passou nos módulos de normalização e segurança de emojis;
- os JavaScript atualizados em `dist/` passaram em `node --check`;
- o pacote não contém `.env`, tokens ou senhas;
- `node_modules` não é incluído no ZIP.

## Limitação do ambiente

A geração do Prisma Client não pôde ser repetida porque `binaries.prisma.sh` não respondeu no ambiente de validação. Isso não afetou os 59 testes, que passaram. No computador de instalação, execute `npm run prisma:generate` após `npm install`.
