@echo off
chcp 65001 >nul
title ASTRO Manager Professional 3.6.1 - Atualizacao
cd /d "%~dp0"

echo.
echo ================================================
echo   ASTRO Manager Professional 3.6.1
echo ================================================
echo Feche o bot antes de continuar.
echo.

if not exist ".env" (
  echo ERRO: O arquivo .env nao foi encontrado.
  echo Copie o .env da sua instalacao anterior para esta pasta e execute novamente.
  goto :erro
)

echo [1/6] Instalando dependencias...
call npm install
if errorlevel 1 goto :erro

echo [2/6] Gerando o cliente Prisma...
call npm run prisma:generate
if errorlevel 1 goto :erro

echo [3/6] Validando o banco de dados...
call npm run prisma:validate
if errorlevel 1 goto :erro

echo [4/6] Criando ou atualizando as tabelas da ASTRO WALLET...
call npm run prisma:push
if errorlevel 1 goto :erro

echo [5/6] Compilando o projeto...
call npm run build
if errorlevel 1 goto :erro

echo [6/6] Registrando os comandos no servidor de desenvolvimento...
call npm run commands:dev
if errorlevel 1 goto :erro

echo.
echo Atualizacao 3.6.1 concluida com sucesso.
echo Agora execute ligar.bat.
pause
exit /b 0

:erro
echo.
echo A atualizacao falhou. Leia a mensagem acima antes de fechar esta janela.
pause
exit /b 1
