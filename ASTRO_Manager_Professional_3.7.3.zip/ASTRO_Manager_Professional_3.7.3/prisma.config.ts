import 'dotenv/config';
import { PrismaPg } from '@prisma/adapter-pg';
import { defineConfig, env } from 'prisma/config';

function adapterFromDatabaseUrl(databaseUrl: string): PrismaPg {
  const parsed = new URL(databaseUrl);
  const schema = parsed.searchParams.get('schema')?.trim() ?? 'public';
  parsed.searchParams.delete('schema');
  return new PrismaPg({ connectionString: parsed.toString() }, { schema });
}

export default defineConfig({
  experimental: { adapter: true },
  schema: 'prisma/schema.prisma',
  migrations: { path: 'prisma/migrations' },
  engine: 'js',
  adapter: async () => adapterFromDatabaseUrl(env('DATABASE_URL')),
});
