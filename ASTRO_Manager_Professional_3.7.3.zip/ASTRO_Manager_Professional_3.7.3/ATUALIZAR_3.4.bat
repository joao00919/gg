@echo off
chcp 65001 >nul
cd /d "%~dp0"
echo Gerando Prisma...
call npm run prisma:generate
if errorlevel 1 goto erro
echo Compilando...
call npm run build
if errorlevel 1 goto erro
echo.
echo Atualizacao 3.4 validada com sucesso.
pause
exit /b 0
:erro
echo.
echo A validacao falhou. Revise o erro acima.
pause
exit /b 1
