# Arquitetura — ASTRO BOT Manager Reference UI Edition

## Objetivo

Reproduzir a experiência funcional observada nas referências: vitrine pública, comandos com autocomplete, abertura de carrinho privado, compra configurável, PIX automático e gerenciamento operacional da aplicação. A identidade visual permanece própria e configurável.

## Domínios

### Discord

`src/bot` concentra comandos, autocomplete, roteamento, mensagens tradicionais do Discord e criação dos tópicos privados.

- `public-panels.ts`: Central de Comandos e Central de Compras;
- `apps-panel.ts`: gerenciamento da aplicação;
- `payment-panel.ts`: carrinho e PIX;
- `cart-flow.ts`: verificações, persistência e ACL do carrinho;
- handlers de buttons/selects/modals: navegação persistente sem collectors frágeis.

### Aplicações e hospedagem

`ApplicationService` mantém estado do serviço e aciona `HostingProvider`. O domínio não depende da Square Cloud ou de um processo local específico. Start, stop, restart e restore possuem trava e auditoria.

### Produtos, planos e adicionais

`Plan`, `PlanPrice`, `Addon` e tabelas de associação permitem montar a vitrine e o carrinho sem valores fixos na interface. `PlanService.seedDefaults()` oferece uma configuração inicial editável.

### Carrinhos

Um `Cart` representa compra nova, renovação ou adicional. Carrinhos concorrentes do mesmo usuário são bloqueados. `CartAddon` preserva preço e seleção no momento da compra.

### Pagamentos

`PaymentProvider` define criação, consulta, cancelamento suportado e validação de webhook. O adaptador PromissePay segue a API fornecida. O código PIX é criptografado e o QR Code é gerado em PNG.

`PaymentService` cria a idempotency key antes da chamada externa e processa aprovação dentro de transação. Constraints únicas impedem aplicação, renovação ou adicional duplicados.

### Licenças

A chave completa não é persistida. O banco armazena hash e sufixo mascarado. Jobs marcam expiração e suspendem a aplicação. Renovação ativa soma o período ao vencimento atual; renovação vencida parte da aprovação.

### Sessões de componentes

`InteractionSession` guarda proprietário, entidade, ação, estado, nonce e expiração. Embeds, selects e botões usam `custom_id` compacto com assinatura HMAC. Alteração, uso por outro usuário ou sessão expirada são recusados.

### API interna

A integração do Bot de Vendas exige API key, assinatura HMAC, timestamp e idempotência. Aceita `planSlug` ou UUID, cria o cliente, a aplicação, a assinatura, a licença ativa e o vínculo de servidor em uma transação. A liberação aparece imediatamente no `/apps`.

## Persistência e isolamento na Shard

O banco usa PostgreSQL com Prisma. A URL deve conter `schema=vision_manager`.

- `prisma.push.config.ts`: engine clássico para `db push` e migrations;
- `prisma.config.ts`: Schema Engine JavaScript para geração/validação;
- `src/database/connection.ts`: remove `schema` da connection string entregue ao `pg` e envia o schema explicitamente ao `PrismaPg`.

Esse desenho evita a introspecção problemática do adapter durante `db push` e impede o Manager de operar no schema `public` de outro bot.

## Fluxo de compra

1. Usuário seleciona produto no painel público.
2. Manager responde ephemeral com carregamento e verificações.
3. `CartService` cria o carrinho.
4. O bot abre tópico privado ou canal privado.
5. O carrinho mostra produto, plano, período, total e adicionais.
6. Finalização cria `Payment` e cobrança PIX.
7. A mesma mensagem é editada para processamento e depois para QR Code.
8. Webhook ou polling confirma o status.
9. Transação atualiza pagamento, carrinho, aplicação, licença, adicionais, eventos e auditoria.
10. Mensagem é atualizada e o carrinho pode ser arquivado.

## Segurança

- Zod para ambiente e payloads;
- AES-256-GCM para PIX e outros segredos persistidos;
- SHA-256 para licenças;
- HMAC e nonce para componentes;
- redaction de tokens, senha, Authorization e códigos sensíveis;
- controle por proprietário, guild e cargos;
- rate limit na API;
- idempotência e constraints PostgreSQL;
- graceful shutdown;
- nenhuma credencial real no repositório.
