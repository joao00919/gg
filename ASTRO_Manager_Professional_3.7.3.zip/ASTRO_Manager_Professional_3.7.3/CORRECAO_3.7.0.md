# ASTRO Manager Professional 3.7.1

- Integração privada real com o Bot de Vendas Vision na Shard.
- HMAC-SHA256 em todas as ações de hospedagem.
- Carrinho com expiração padrão de 10 minutos e tempo restante visível.
- Remoção das mensagens textuais intermediárias durante a abertura do carrinho.
- Suporte a status, reinício, suspensão, ativação e logs via API privada.
- `.env.example` limpo e pronto para Discloud.
