# Correção do carrinho privado — versão 3.1.0

Esta edição corrige o caso em que o tópico privado era criado, o cliente era adicionado, mas o painel não aparecia.

## Comportamento novo

1. O Manager confirma a interação imediatamente.
2. Valida as permissões do canal pai.
3. Cria o tópico privado.
4. Envia imediatamente a mensagem animada de carregamento.
5. Registra o canal e a mensagem no PostgreSQL.
6. Monta o painel do carrinho.
7. Edita a mensagem de carregamento para o painel completo.
8. Retorna ao cliente a confirmação “Carrinho aberto com sucesso!”.

Se uma etapa falhar, o tópico não fica vazio: a mensagem é substituída por um erro objetivo. Se nem a primeira mensagem puder ser enviada, o tópico incompleto é removido.

## Permissões obrigatórias no canal definido em CART_PARENT_CHANNEL_ID

- Ver canal
- Enviar mensagens
- Criar tópicos privados
- Enviar mensagens em tópicos
- Gerenciar tópicos
- Inserir links
- Anexar arquivos

## Emojis configurados

```env
CUSTOM_EMOJI_LOADING=<a:1389945080172904539:1527386782776164392>
CUSTOM_EMOJI_CART_OPENED=<:1389945083419426816:1527388353044156546>
```

Emojis usados em botões e selects são verificados quando o bot conecta. Caso um ID não pertença ao servidor do Manager ou aos emojis da aplicação, ele é removido daquele componente e o painel usa fallback, evitando `Invalid Form Body`.

## Período inicial

```env
DEFAULT_PLAN_PERIOD_DAYS=1
```

O seed já contém o preço de 1 dia por R$ 1,00.
