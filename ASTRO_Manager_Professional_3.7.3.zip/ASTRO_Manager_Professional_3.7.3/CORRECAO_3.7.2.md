# Correção 3.7.2

- Corrige os 17 erros de `content: null` sem alterar o comportamento necessário para apagar o conteúdo anterior da interação.
- Usa conversão de tipo localizada para manter `null` em tempo de execução e compatibilidade com `BaseMessageOptions`.
- Corrige `replaceInteractionMessage` com `NonNullable<Parameters<ButtonInteraction['update']>[0]>`, eliminando o tipo `undefined`.
- Adiciona `ATUALIZAR_3.7.2.bat` em CRLF e somente ASCII, eliminando o erro `'tle' não é reconhecido`.
- Mantém as verificações de transferência e a revogação de sessões antigas.
- Resultado: 75 de 75 testes aprovados.
