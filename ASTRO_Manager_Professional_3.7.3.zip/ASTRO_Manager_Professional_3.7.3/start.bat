@echo off
setlocal
cd /d "%~dp0"
if not exist .env (
  copy .env.example .env >nul
  echo O arquivo .env foi criado. Configure-o e execute novamente.
  notepad .env
  pause
  exit /b 1
)
if not exist node_modules (
  echo Dependencias ausentes. Execute install.bat primeiro.
  pause
  exit /b 1
)
call npm run build
if errorlevel 1 goto :error
call npm start
set EXIT_CODE=%ERRORLEVEL%
echo.
echo O Manager foi encerrado com codigo %EXIT_CODE%.
pause
exit /b %EXIT_CODE%
:error
echo.
echo Nao foi possivel compilar o projeto.
pause
exit /b 1
