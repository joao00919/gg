@echo off
setlocal
cd /d "%~dp0"
call npm run prisma:generate || goto :error
call npm run prisma:validate || goto :error
call npm run build || goto :error
call npm run lint || goto :error
call npm test || goto :error
echo.
echo Todas as validacoes passaram.
pause
exit /b 0
:error
echo.
echo Uma validacao falhou. Revise o erro acima.
pause
exit /b 1
