# Relatório de validação — ASTRO Manager 3.7.1

- JavaScript emitido em `dist/` validado com `node --check`.
- 6 testes unitários dos painéis, PIX e limpeza de carrinho aprovados.
- Integração HMAC Manager → Bot de Vendas testada contra servidor local compatível.
- Arquivos JSON validados.
- ZIP sem `.env`, tokens, senhas, `node_modules`, fontes privadas ou dados de clientes.

Observação: a regeneração local do Prisma Client não foi concluída no ambiente de empacotamento porque o download dos binários do Prisma estava bloqueado. O `dist/` já está incluído; na hospedagem, execute `npm install` e `npm run prisma:generate` com acesso à internet antes do primeiro início.
