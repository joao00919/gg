# ASTRO Manager Professional 3.6.1

## Correção aplicada

O compilador TypeScript estava interrompendo a atualização porque o teste do carrinho acessava diretamente `buttons[0]` e `buttons[1]` com `noUncheckedIndexedAccess` habilitado.

A versão 3.6.1 agora:

- valida explicitamente a quantidade de botões antes do acesso;
- impede o erro `TS2532: Object is possibly 'undefined'`;
- preserva a seta personalizada somente em **Finalizar Compra**;
- preserva **Cancelar Compra** sem emoji;
- mantém todos os recursos da ASTRO WALLET e da versão 3.6.0.

## Atualização

1. Feche o bot.
2. Preserve seu arquivo `.env`.
3. Extraia esta versão em uma pasta nova.
4. Execute `ATUALIZAR_3.6.1.bat`.
5. Depois execute `ligar.bat`.
