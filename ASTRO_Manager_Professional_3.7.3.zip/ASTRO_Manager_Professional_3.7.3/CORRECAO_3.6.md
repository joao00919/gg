# ASTRO Manager Professional 3.6.0

## Alterações principais

- Corrigido **Gerenciar servidores**: quando a aplicação possui o ID do bot configurado, o painel exibe o botão **Adicionar aplicação** com o convite OAuth2 para bot e comandos.
- Adicionada a **ASTRO WALLET**, com saldo individual, histórico de movimentações e consulta pelo comando `/wallet`.
- Adicionados comandos administrativos para consultar, adicionar e remover saldo por menção ou ID do Discord:
  - `/admin wallet saldo`
  - `/admin wallet adicionar`
  - `/admin wallet remover`
- Adicionada renovação automática usando o saldo da ASTRO WALLET. O sistema verifica aplicações próximas do vencimento, debita o valor de forma transacional e prorroga licença e adicionais.
- A tela de renovação mostra vencimento, saldo disponível e estado da renovação automática.
- Aplicados os emojis personalizados enviados para carteira, energia, recarregar, salvar, iniciar, pausar, servidores, equipe, transferência e demais ações.
- O botão **Finalizar Compra** usa o emoji `<:1242906048994742393:1527441682545770567>`.
- Os botões **Cancelar Compra**, **Voltar** e **Cancelar** nas telas de cancelamento permanecem sem emoji.
- O cancelamento do carrinho encerra e apaga o tópico; se o Discord impedir a exclusão, o tópico é bloqueado e arquivado.
- Corrigida a renovação rápida para selecionar realmente o período de 30 dias, mesmo quando o período padrão do projeto é diferente.
- Proteção adicional contra emojis de componente inválidos ou indisponíveis para o bot.

## Atualização

1. Feche o bot.
2. Extraia a versão 3.6.0 sobre uma pasta nova.
3. Preserve as configurações corretas do arquivo `.env`.
4. Execute `ATUALIZAR_3.6.bat`.
5. Execute `ligar.bat`.

O atualizador executa `prisma:push` porque a ASTRO WALLET adiciona tabelas e campos ao banco de dados.
