@echo off
chcp 65001 >nul
title ASTRO Manager - Atualização 3.5.1
cd /d "%~dp0"
echo.
echo [1/5] Instalando dependencias...
call npm install
if errorlevel 1 goto :erro
echo [2/5] Gerando Prisma...
call npm run prisma:generate
if errorlevel 1 goto :erro
echo [3/5] Compilando projeto...
call npm run build
if errorlevel 1 goto :erro
echo [4/5] Registrando comandos no servidor de desenvolvimento...
call npm run commands:dev
if errorlevel 1 goto :erro
echo [5/5] Atualizacao concluida.
echo.
echo Agora execute ligar.bat
pause
exit /b 0
:erro
echo.
echo Ocorreu um erro durante a atualizacao. Verifique a mensagem acima.
pause
exit /b 1
