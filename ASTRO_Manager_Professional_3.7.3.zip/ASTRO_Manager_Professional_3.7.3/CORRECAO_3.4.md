# Correção 3.4

Corrige o último erro de TypeScript no teste `cart-component-emoji-regression.test.ts`.

O mock do plano agora inclui `previewUrl: null`, campo exigido pelo modelo Prisma atual.

Não há alteração no banco de dados nem no fluxo do bot.
