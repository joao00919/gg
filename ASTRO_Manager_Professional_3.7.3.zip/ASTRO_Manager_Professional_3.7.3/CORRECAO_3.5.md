# ASTRO Manager 3.5 — Painéis, carrinho e administração

Esta edição reorganiza o fluxo comercial e administrativo da Astro Applications, mantendo PostgreSQL, Prisma, PIX e a integração com o Bot de Vendas.

## Painel de aquisição

O painel público agora usa o título **Painel de Aquisição - Astro Applications** e apresenta somente os produtos comerciais principais:

- **Bot de Vendas:** automatização do catálogo até a entrega.
- **Bot de Ticket:** suporte ao cliente com IA e automação avançada.

Os emojis personalizados de robô e dinheiro são usados nos componentes compatíveis do Discord.

## Central de comandos

O painel **Central de Comandos - Astro Applications** lista os comandos destinados ao cliente:

- `/apps`
- `/renovar`
- `/restore`
- `/imagem_url`

A Dashboard OAuth2 continua disponível como opção complementar.

## Cancelamento do carrinho

- O botão de cancelamento usa o emoji personalizado de pagamento cancelado.
- O pagamento é marcado como cancelado antes do encerramento.
- A mensagem final de cancelamento é exibida.
- O tópico privado ou canal do carrinho é excluído após o atraso configurado.
- Se o Discord impedir a exclusão de um tópico, o sistema tenta bloqueá-lo e arquivá-lo como contingência.
- Cancelamentos detectados por sincronização administrativa ou atualização automática também encerram o carrinho.

Atraso configurável no `.env`:

```env
CART_DELETE_DELAY_SECONDS=3
```

## Administração simplificada

### Entregar bot a um cliente

Use:

```text
/admin aplicacao entregar
```

O cliente pode ser informado por `@menção` ou pelo ID do Discord. O administrador escolhe o plano e a duração; o nome do bot é opcional. O sistema cria ou atualiza o cadastro do cliente, gera a aplicação e ativa a licença.

### Aprovar pedido manualmente

Use:

```text
/admin pagamento aprovar
```

É possível informar:

- o ID do pagamento; ou
- o cliente por `@menção`; ou
- o ID do Discord do cliente.

Ao usar um usuário, o sistema localiza o pedido pendente mais recente e executa o mesmo fluxo de liberação da aprovação automática, incluindo auditoria administrativa.

### Sincronizar pagamento

Use:

```text
/admin pagamento sincronizar
```

Esse comando consulta o provedor configurado e atualiza o pagamento sem forçar uma aprovação manual.

## Novas variáveis de emoji

```env
CUSTOM_EMOJI_APP=<:robot:1525692202288676927>
CUSTOM_EMOJI_DOLLAR=<:dollar:1525692051969020024>
CUSTOM_EMOJI_PAYMENT_CANCELLED=<:1389945083419426816:1527388353044156546>
```

O bot valida os emojis no servidor. Caso um emoji não esteja acessível, utiliza um fallback seguro para evitar componentes inválidos.
