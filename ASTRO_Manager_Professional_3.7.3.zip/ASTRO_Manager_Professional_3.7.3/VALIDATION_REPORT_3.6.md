# Relatório de validação — ASTRO Manager Professional 3.6.0

Validações executadas antes do empacotamento:

- Geração do Prisma Client.
- Validação do schema Prisma.
- Compilação TypeScript.
- ESLint sem avisos.
- Suíte completa: **21 arquivos de teste e 71 testes aprovados, sem falhas**.
- Testes específicos do emoji de Finalizar Compra.
- Testes dos botões de cancelamento sem emoji.
- Testes do painel de renovação pela ASTRO WALLET.
- Teste do link OAuth2 de Gerenciar servidores.

Observação: `prisma:push` não é executado durante a validação local porque depende do banco PostgreSQL configurado pelo usuário. O comando está incluído no `ATUALIZAR_3.6.bat`.

Resultados finais:

- Prisma Client: gerado com sucesso.
- Schema Prisma: válido.
- TypeScript: compilado sem erros.
- ESLint: aprovado sem avisos.
- Vitest: 21/21 arquivos e 71/71 testes aprovados.
