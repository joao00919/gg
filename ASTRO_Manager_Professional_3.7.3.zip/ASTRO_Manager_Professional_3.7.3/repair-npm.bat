@echo off
setlocal
cd /d "%~dp0"

echo Corrigindo o registry do npm neste projeto...
> .npmrc echo registry=https://registry.npmjs.org/
>> .npmrc echo fund=false
>> .npmrc echo audit=true

call npm config set registry https://registry.npmjs.org/ --location=project
call npm config delete proxy --location=project >nul 2>nul
call npm config delete https-proxy --location=project >nul 2>nul

echo.
echo Removendo instalacao incompleta...
if exist node_modules rmdir /s /q node_modules
if exist package-lock.json del /f /q package-lock.json
if exist node_modules (
  echo Nao foi possivel remover node_modules.
  echo Feche VS Code, terminais e processos Node abertos nesta pasta e execute novamente.
  pause
  exit /b 1
)

echo.
echo Limpando cache e instalando dependencias do registry publico...
call npm cache verify
call npm install --registry=https://registry.npmjs.org/
if errorlevel 1 goto :error

call npm run prisma:generate
if errorlevel 1 goto :error

call npm run build
if errorlevel 1 goto :error

echo.
echo Reparo concluido. Agora execute start.bat.
pause
exit /b 0

:error
echo.
echo O reparo falhou. Revise o erro exibido acima.
pause
exit /b 1
