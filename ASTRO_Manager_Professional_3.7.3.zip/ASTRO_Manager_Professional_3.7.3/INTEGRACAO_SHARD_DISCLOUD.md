# ASTRO Manager + Bot de Vendas Vision

- ASTRO Manager: hospede na Discloud.
- Bot de Vendas Vision: hospede na Shard.
- Os bots não compartilham token do Discord.
- A comunicação usa API privada com `SALES_BOT_API_KEY` e assinatura HMAC.
- Use a mesma `SALES_BOT_API_KEY` nos dois projetos.
- No Bot de Vendas, configure `MANAGER_API_URL` e `MANAGER_INTERNAL_API_KEY` para provisionar a licença após pagamento aprovado.
- No Manager, configure `SALES_BOT_API_URL` para consultar status, reiniciar, suspender, ativar e ler logs do bot na Shard.

O carrinho expira em 10 minutos e mostra o tempo restante no painel.
