# Correção 3.5.1

- Corrigido `COMPONENT_INVALID_EMOJI` ao abrir `/apps`.
- O símbolo textual `✎`, rejeitado pelo Discord em opções de menu, foi substituído por `📝`.
- O parser de componentes agora aceita somente emojis Unicode válidos, IDs de emojis personalizados ou menções personalizadas válidas.
- Símbolos comuns como `✎` e `↻` deixam de ser enviados no campo `emoji`, evitando que uma mensagem inteira falhe.
