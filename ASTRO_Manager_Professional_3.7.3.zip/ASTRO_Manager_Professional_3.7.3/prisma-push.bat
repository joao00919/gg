@echo off
setlocal
cd /d "%~dp0"
if not exist .env (
  echo Arquivo .env nao encontrado.
  pause
  exit /b 1
)
call npm run prisma:generate
if errorlevel 1 goto :error
call npm run prisma:push
if errorlevel 1 goto :error
echo.
echo Banco sincronizado no schema vision_manager.
pause
exit /b 0
:error
echo.
echo Falha ao sincronizar o banco. Confirme DATABASE_URL e schema=vision_manager.
pause
exit /b 1
