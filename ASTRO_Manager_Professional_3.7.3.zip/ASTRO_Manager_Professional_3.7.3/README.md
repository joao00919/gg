# ASTRO BOT Manager — Reference UI Edition

Bot Manager comercial para Discord, desenvolvido em Node.js, TypeScript, Discord.js, PostgreSQL e Prisma. Esta edição foi reconstruída a partir das capturas e do vídeo de referência enviados, reproduzindo a organização funcional e a sequência de navegação sem incluir marca, logotipo, banners, código ou ativos proprietários de terceiros.

## Fluxo reproduzido

```text
/painel comandos ou /painel bots
→ painel público de produtos
→ usuário seleciona o bot
→ criação direta do carrinho privado
→ botão “Ir para carrinho”
→ período e adicionais
→ “Finalizar Compra”
→ processamento
→ QR Code
→ “Copiar Código QR” ou “Cancelar”
→ confirmação automática
→ aplicação e licença liberadas
```

O gerenciamento segue o mesmo padrão observado na referência:

```text
/apps app:<autocomplete>
→ painel da aplicação
→ Iniciar / Reiniciar / Parar
→ configurações, equipe, servidores e transferência
→ adicionais
→ renovação rápida ou personalizada
```

## Recursos implementados

- mensagens tradicionais do Discord nas telas principais: embeds, selects, botões e attachments;
- painel público de comandos e painel público de produtos;
- autocomplete para `/apps`, `/renovar` e `/restore`;
- confirmação ephemeral somente após o carrinho privado estar pronto;
- tópicos privados para carrinhos, com fallback para canal privado;
- produtos, períodos e adicionais persistidos no PostgreSQL;
- PIX PromissePay com QR Code PNG e código copia-e-cola protegido;
- mensagem PIX com somente **Copiar Código QR** e **Cancelar**;
- webhook e polling automático, sem botão de verificação manual;
- criação de aplicação, renovação e ativação de adicionais após aprovação;
- start, stop, restart e restore por `HostingProvider` desacoplado;
- licenças com hash, máscara, expiração e suspensão automática;
- sessões persistentes e `custom_id` assinado por HMAC;
- idempotência para carrinho, cobrança, webhook e entrega;
- API interna assinada para integração com Bot de Vendas;
- comandos administrativos, auditoria e logs com redaction;
- Docker, PM2, Vitest, ESLint e Prettier.


## Preços padrão desta edição

Ao iniciar, o seed atualiza os produtos ativos com os períodos abaixo:

| Período | Valor |
|---|---:|
| 1 dia | R$ 1,00 |
| 7 dias | R$ 3,99 |
| 15 dias | R$ 5,99 |
| 30 dias | R$ 8,99 |
| 365 dias | R$ 79,99 |

Os adicionais **Suporte Prioritário**, **Remover Anúncio** e **QRCode Personalizável** custam R$ 4,00 cada. O carrinho responde imediatamente aos selects para impedir o aviso “o aplicativo não respondeu”.

## Estrutura

```text
src/
  bot/
    commands/          comandos, autocomplete e painéis públicos
    flows/             abertura do carrinho
    interactions/      buttons, selects e modals
    panels/            embeds e componentes tradicionais
  api/                 health, API interna e webhooks
  config/              validação Zod, marca e logger
  database/            Prisma e configuração PostgreSQL
  integrations/        PromissePay, hospedagem e Bot de Vendas
  jobs/                pagamentos pendentes e vencimentos
  services/            aplicações, planos, carrinhos, licenças etc.
prisma/schema.prisma
scripts/register-commands.ts
tests/
```

Leia também [ARCHITECTURE.md](./ARCHITECTURE.md) e [references/REFERENCE_ANALYSIS.md](./references/REFERENCE_ANALYSIS.md).


## Integração Discloud + Shard

O Manager deve usar `HOSTING_PROVIDER=sales-api`. Configure `SALES_BOT_API_URL` com a URL pública privada do Bot de Vendas na Shard e use a mesma `SALES_BOT_API_KEY` nos dois projetos. A comunicação usa HMAC-SHA256 e não compartilha tokens do Discord. O carrinho expira em 10 minutos e mostra o tempo restante.

## Requisitos

- Node.js LTS 20, 22 ou superior;
- npm 10 ou superior;
- PostgreSQL 15 ou superior, local, Docker ou Shard Cloud;
- aplicação exclusiva no Discord Developer Portal;
- chave de API PromissePay para cobranças reais.

## Instalação no Windows

Extraia o projeto em uma pasta definitiva. Não mova entre várias cópias depois de instalar.

```bat
cd /d "C:\caminho\ASTRO_Manager_Reference"
install.bat
```

O instalador:

1. força o registry oficial do npm;
2. instala dependências;
3. gera o Prisma Client;
4. compila o TypeScript;
5. cria `.env` a partir de `.env.example` quando necessário.

Gere os segredos:

```bat
generate-secrets.bat
```

Abra o ambiente:

```bat
notepad .env
```

## Configuração mínima do `.env`

```env
NODE_ENV=development
MANAGER_BOT_TOKEN=NOVO_TOKEN_DO_MANAGER
MANAGER_CLIENT_ID=ID_DA_APLICACAO
MANAGER_GUILD_ID=ID_DO_SERVIDOR

DATABASE_URL=postgresql://usuario:senha@host:porta/database?sslmode=verify-full&schema=vision_manager

MANAGER_PUBLIC_API_URL=https://manager.seu-dominio.com

INTERNAL_API_KEY=SEGREDO_GERADO
ENCRYPTION_KEY=SEGREDO_GERADO
CUSTOM_ID_SECRET=SEGREDO_GERADO

PAYMENT_PROVIDER=promisse
PAYMENT_API_URL=https://api.promisse.com.br
PAYMENT_ACCESS_TOKEN=CHAVE_DA_PROMISSEPAY

OWNER_IDS=SEU_ID_DE_USUARIO
CART_PARENT_CHANNEL_ID=ID_DA_CATEGORIA_OU_CANAL_DE_TOPICOS

BRAND_NAME=Vision Applications
COMMANDS_BANNER_URL=https://seu-dominio/banner-comandos.png
STORE_BANNER_URL=https://seu-dominio/banner-produtos.png
DASHBOARD_URL=https://seu-dominio/dashboard
PREVIEW_BOTS_URL=https://seu-dominio/preview
```

Use URLs HTTPS válidas para imagens. IDs múltiplos em `OWNER_IDS` e `ADMIN_ROLE_IDS` são separados por vírgula, sem colchetes.

Nunca envie token do Discord, chave PromissePay ou URL completa do banco em mensagens públicas. Caso um token tenha sido exposto, redefina-o no Discord Developer Portal.

## PostgreSQL na Shard Cloud

Use a **Connection URL externa** da Shard. Acrescente `schema=vision_manager` à query da URL para isolar o Manager das tabelas de outro bot.

Exemplos:

```env
# URL sem parâmetros
DATABASE_URL=postgresql://user:pass@host:5432/database?schema=vision_manager

# URL que já possui SSL
DATABASE_URL=postgresql://user:pass@host:5432/database?sslmode=verify-full&schema=vision_manager
```

Não use `localhost` quando o PostgreSQL estiver na Shard.

Não reutilize `schema=public` de um Bot de Vendas existente. O Manager usa `vision_manager`, evitando tentativas de excluir tabelas como `orders`, `products`, `wallets` e outras do sistema anterior.

Sincronize o schema:

```bat
prisma-push.bat
```

Ou:

```bat
npm run prisma:generate
npm run prisma:push
```

O runtime com `@prisma/adapter-pg` recebe explicitamente o schema extraído da URL. O `db push` usa uma configuração separada com engine clássico para evitar a incompatibilidade de introspecção observada com o adapter.

## Discord Developer Portal

Crie um bot exclusivo para o Manager.

1. **General Information**: copie Application ID para `MANAGER_CLIENT_ID`.
2. **Bot**: gere o token para `MANAGER_BOT_TOKEN`.
3. **OAuth2 URL Generator**: marque `bot` e `applications.commands`.
4. Permissões recomendadas:
   - View Channels;
   - Send Messages;
   - Manage Channels;
   - Create Private Threads;
   - Manage Threads;
   - Read Message History;
   - Attach Files;
   - Use Application Commands.

Registre os comandos no servidor de desenvolvimento:

```bat
commands-dev.bat
```

Ou:

```bat
npm run commands:dev
```

Registro global:

```bat
npm run commands:global
```

## Publicar os painéis

Com uma conta em `OWNER_IDS` ou cargo em `ADMIN_ROLE_IDS`:

```text
/painel tipo:comandos
/painel tipo:bots
```

O painel de produtos contém select de bots e link de preview. Banners e links vêm do `.env`.

Outros comandos de referência:

```text
/apps app:<aplicação>
/renovar app:<aplicação>
/restore app:<aplicação>
/imagem_url imagem:<arquivo>
```

## Planos e adicionais iniciais

O seed automático cria produtos configuráveis equivalentes às categorias observadas:

- Bot de Vendas;
- Bot de Ticket;
- Bot de Roblox;
- Bot de Divulgação;
- Bot de Verificação.

Também cria períodos e adicionais de demonstração. Valores, descrições e disponibilidade ficam no banco e podem ser alterados por serviço administrativo ou Prisma Studio:

```bat
npm run prisma:studio
```

## Pagamento PIX

O adaptador PromissePay usa:

- `POST /transactions` para criar a cobrança;
- `GET /transactions/:id` para consultar;
- header `Authorization`;
- valores em centavos.

A tela segue a referência:

- mensagem de processamento;
- instruções objetivas;
- QR Code branco e preto em PNG;
- botão **Copiar Código QR**;
- botão **Cancelar**;
- nenhuma ação manual de “verificar pagamento”.

Sem URL pública de webhook, o polling continuará consultando a cobrança automaticamente. Em produção, configure `PAYMENT_WEBHOOK_URL` e `PAYMENT_WEBHOOK_SECRET`.

A documentação recebida não expõe endpoint de cancelamento remoto. O cancelamento bloqueia a entrega no Manager, encerra a sessão e para o monitoramento; o adaptador não afirma cancelar o PIX no provedor quando essa operação não está disponível.

## Bot de Vendas

A API interna aceita uma entrega já paga e cria usuário, aplicação, assinatura e licença ativa automaticamente. O Bot de Vendas pode usar `planSlug` em vez de UUID, e o cliente recebe acesso imediato ao `/apps`. Consulte [docs/SALES_BOT_API.md](./docs/SALES_BOT_API.md).

Com o Manager ligado, valide a conexão assinada sem criar compra:

```bat
npm run integration:check
```

## Hospedagem

`HOSTING_PROVIDER=mock` permite testar o painel sem API externa. Para reiniciar bots reais, implemente um adaptador da interface `HostingProvider` para Square Cloud, VPS, Docker remoto ou outro fornecedor.

## Iniciar

Depois de banco e comandos configurados:

```bat
start.bat
```

Durante desenvolvimento:

```bat
npm run dev
```

Para desligar, use `Ctrl + C`.

## Validação

Execute tudo:

```bat
verify.bat
```

Ou:

```bat
npm run check
```

Os resultados obtidos neste pacote estão em [VALIDATION_REPORT.md](./VALIDATION_REPORT.md).

## Docker

```bat
npm run docker:up
```

O Compose cria banco local e usa o schema `vision_manager`. Para usar apenas o banco da Shard, não suba o serviço `database`; execute o Manager no Windows ou adapte o Compose com sua URL externa.

Parar:

```bat
npm run docker:down
```

## PM2

```bash
npm run build
npx pm2 start ecosystem.config.cjs
npx pm2 save
```

## Diagnóstico rápido

**`ERR_MODULE_NOT_FOUND: zod`**: instalação incompleta. Execute `repair-npm.bat`.

**Tipos Prisma inexistentes**: execute `npm run prisma:generate` antes do build.

**`ECONNREFUSED`**: host/porta do PostgreSQL não estão acessíveis; com Shard, use a URL externa.

**Prisma tenta apagar tabelas de outro sistema**: a URL está em `schema=public`. Troque para `schema=vision_manager` e não confirme operações destrutivas no schema antigo.

**Comandos aparecem, mas o bot não inicia**: registro de slash commands não testa a conexão do banco. Verifique `DATABASE_URL` e rode `npm run prisma:push`.

## Limitações reais

A validação local cobre schema, compilação, lint e regras de domínio. Login real no Discord, cobrança PromissePay, webhook público, banco da Shard e hospedagem real dependem das credenciais e serviços do proprietário e não são declarados como testados sem essas condições.


## Correção de tópico vazio — versão 3.1.0

Adicione ao `.env`:

```env
CUSTOM_EMOJI_LOADING=<a:1389945080172904539:1527386782776164392>
CUSTOM_EMOJI_CART_OPENED=<:1389945083419426816:1527388353044156546>
DEFAULT_PLAN_PERIOD_DAYS=1
```

No canal definido em `CART_PARENT_CHANNEL_ID`, permita ao Manager: **Criar tópicos privados**, **Enviar mensagens em tópicos** e **Gerenciar tópicos**. O Manager valida essas permissões e remove emojis inacessíveis de botões/selects para impedir que o Discord rejeite o painel. Consulte `CORRECAO_CARRINHO.md`.
