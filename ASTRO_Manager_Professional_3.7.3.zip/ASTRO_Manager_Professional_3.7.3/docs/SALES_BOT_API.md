# Integração automática com o Bot de Vendas

Configure `MANAGER_PUBLIC_API_URL` com a URL pública do Manager quando ele estiver hospedado.

O Bot de Vendas deve chamar o Manager **somente depois que o pagamento estiver aprovado**. O Manager então cria o cliente, a aplicação, a licença ativa, o vínculo do servidor e libera o comando `/apps` automaticamente.

## Endpoint

```text
POST /internal/v1/purchases
```

Aliases aceitos:

```text
POST /internal/v1/sales/purchases
POST /internal/v1/purchases/approved
```

## Autenticação

Headers obrigatórios:

```text
x-api-key: INTERNAL_API_KEY
x-timestamp: timestamp Unix em milissegundos
x-signature: HMAC-SHA256 Base64URL de timestamp.rawBody
content-type: application/json
```

A assinatura usa `SALES_BOT_API_KEY`. Quando ela estiver vazia, usa `INTERNAL_API_KEY`.

O timestamp tem validade máxima de cinco minutos. `idempotencyKey` impede que a mesma venda crie duas aplicações.

## Payload recomendado

O campo `planSlug` é mais simples que o UUID interno do plano. Os slugs padrões são `vendas`, `ticket`, `roblox`, `divulgacao` e `verificacao`.

```json
{
  "idempotencyKey": "order_98421_payment_551",
  "buyerDiscordId": "123456789012345678",
  "buyerUsername": "cliente",
  "applicationName": "ASTRO BOT",
  "discordApplicationId": "123456789012345678",
  "linkedGuildId": "123456789012345678",
  "planSlug": "vendas",
  "periodDays": 30,
  "paymentExternalId": "promisse_transaction_id",
  "amountInCents": 899,
  "currency": "BRL",
  "paymentProvider": "promisse",
  "autoActivate": true
}
```

Também é possível enviar `planId` no lugar de `planSlug`.

## Exemplo Node.js/TypeScript

```ts
import { createHmac } from "node:crypto";

const managerUrl = process.env.MANAGER_API_URL!;
const apiKey = process.env.MANAGER_INTERNAL_API_KEY!;
const signatureSecret = process.env.MANAGER_SALES_API_KEY || apiKey;

const payload = {
  idempotencyKey: `order_${order.id}`,
  buyerDiscordId: order.discordUserId,
  buyerUsername: order.username,
  applicationName: order.applicationName,
  discordApplicationId: order.discordApplicationId,
  linkedGuildId: order.guildId,
  planSlug: "vendas",
  periodDays: 30,
  paymentExternalId: order.paymentId,
  amountInCents: order.amountInCents,
  currency: "BRL",
  paymentProvider: "promisse",
  autoActivate: true,
};

const rawBody = JSON.stringify(payload);
const timestamp = String(Date.now());
const signature = createHmac("sha256", signatureSecret)
  .update(`${timestamp}.${rawBody}`)
  .digest("base64url");

const response = await fetch(`${managerUrl}/internal/v1/purchases`, {
  method: "POST",
  headers: {
    "content-type": "application/json",
    "x-api-key": apiKey,
    "x-timestamp": timestamp,
    "x-signature": signature,
  },
  body: rawBody,
});

if (!response.ok) {
  throw new Error(`Manager recusou a entrega: ${response.status} ${await response.text()}`);
}

const result = await response.json();
console.log(result.applicationId, result.licenseStatus, result.expiresAt);
```

## Resposta

```json
{
  "ok": true,
  "released": true,
  "applicationId": "uuid",
  "paymentId": "uuid",
  "licenseId": "uuid",
  "status": "ONLINE",
  "licenseStatus": "ACTIVE",
  "expiresAt": "2026-08-15T12:00:00.000Z",
  "idempotent": false,
  "nextCommand": "/apps"
}
```

Se o Bot de Vendas repetir a mesma requisição com a mesma `idempotencyKey`, o Manager devolve a entrega existente sem duplicar aplicação, pagamento ou licença.

## Teste de conexão

Com o Manager ligado:

```bat
npm run integration:check
```

Esse comando consulta o endpoint protegido de diagnóstico sem criar compra.

## Validação de licença pelo bot do cliente

```text
POST /internal/v1/licenses/validate
```

Payload:

```json
{
  "key": "CHAVE_DA_LICENCA",
  "guildId": "123456789012345678"
}
```

A resposta é `200 { "valid": true }` quando a licença estiver ativa e dentro do limite de servidores. A chave completa nunca deve ser registrada em logs.
