@echo off
setlocal
cd /d "%~dp0"

echo.
echo ASTRO Manager 3.7.2
echo.

if not exist .env (
  echo ERRO: o arquivo .env nao foi encontrado.
  echo Copie seu .env da versao anterior para esta pasta antes de continuar.
  pause
  exit /b 1
)

echo [1/6] Instalando dependencias...
call npm install
if errorlevel 1 goto erro

echo [2/6] Gerando Prisma Client...
call npm run prisma:generate
if errorlevel 1 goto erro

echo [3/6] Sincronizando banco de dados...
call npm run prisma:push
if errorlevel 1 goto erro

echo [4/6] Compilando projeto...
call npm run build
if errorlevel 1 goto erro

echo [5/6] Executando testes...
call npm test
if errorlevel 1 goto erro

echo [6/6] Registrando comandos no servidor de desenvolvimento...
call npm run commands:dev
if errorlevel 1 goto erro

echo.
echo Atualizacao concluida com sucesso.
echo Execute start.bat para ligar o Manager.
pause
exit /b 0

:erro
echo.
echo A atualizacao falhou. Veja o erro exibido acima.
pause
exit /b 1
