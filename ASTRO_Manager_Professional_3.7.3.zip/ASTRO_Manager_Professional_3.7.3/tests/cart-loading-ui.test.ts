import { describe, expect, it } from 'vitest';
import type { BrandConfig } from '../src/config/brand.js';
import { cartOpenedPanel } from '../src/bot/panels/action-panels.js';
import { loadingPanel, plainLoadingMessage } from '../src/bot/panels/common-panels.js';

const brand: BrandConfig = {
  name: 'ASTRO BOT',
  description: 'Manager',
  primaryColor: 0x00a8ff,
  secondaryColor: 0x2b2d31,
  emojis: {
    loading: '<a:astro_loading:1527386782776164392>',
    cartOpened: '<:astro_cart_opened:1527388353044156546>',
  },
};

describe('feedback visual da abertura do carrinho', () => {
  it('usa o emoji animado de carregamento sem duplicar o símbolo antigo', () => {
    expect(loadingPanel(brand).content).toBe(
      '<a:astro_loading:1527386782776164392> Carregando...',
    );
    expect(plainLoadingMessage(brand, '◔ Iniciando verificações necessárias...').content).toBe(
      '<a:astro_loading:1527386782776164392> Iniciando verificações necessárias...',
    );
  });

  it('usa o emoji informado na confirmação de carrinho aberto', () => {
    const payload = cartOpenedPanel(brand, 'https://discord.com/channels/1/2/3');
    expect(payload.content).toBe(
      '<:astro_cart_opened:1527388353044156546> Carrinho aberto com sucesso!',
    );
    expect(payload.components).toHaveLength(1);
  });
});
