import { describe, expect, it } from 'vitest';
import { addDays, calculateRenewalExpiry, formatRemaining } from '../src/utils/time.js';

describe('regras de vencimento', () => {
  it('soma o período ao vencimento atual quando a licença ainda está ativa', () => {
    const approvedAt = new Date('2026-07-15T12:00:00.000Z');
    const currentExpiry = new Date('2026-08-01T12:00:00.000Z');
    expect(calculateRenewalExpiry(currentExpiry, approvedAt, 30).toISOString()).toBe(
      '2026-08-31T12:00:00.000Z',
    );
  });

  it('soma o período à aprovação quando a licença está vencida', () => {
    const approvedAt = new Date('2026-07-15T12:00:00.000Z');
    const currentExpiry = new Date('2026-07-01T12:00:00.000Z');
    expect(calculateRenewalExpiry(currentExpiry, approvedAt, 30).toISOString()).toBe(
      '2026-08-14T12:00:00.000Z',
    );
  });

  it('preserva horário UTC ao adicionar dias', () => {
    expect(addDays(new Date('2026-01-31T23:30:00.000Z'), 1).toISOString()).toBe(
      '2026-02-01T23:30:00.000Z',
    );
  });

  it('identifica licença vencida no texto restante', () => {
    expect(
      formatRemaining(new Date('2026-01-01T00:00:00.000Z'), new Date('2026-01-02T00:00:00.000Z')),
    ).toBe('Vencida');
  });
});
