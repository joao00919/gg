import type { PrismaClient } from '@prisma/client';
import { describe, expect, it, vi } from 'vitest';
import { CartService } from '../src/services/carts/cart-service.js';
import type { PlanService } from '../src/services/plans/plan-service.js';

function setup(
  options: {
    applicationFound?: boolean;
    existingCart?: boolean;
    amount?: number;
    discount?: number;
  } = {},
) {
  const prisma = {
    user: { upsert: vi.fn(async () => ({ id: 'user-1' })) },
    application: {
      findFirst: vi.fn(async () => (options.applicationFound === false ? null : { id: 'app-1' })),
    },
    cart: {
      findFirst: vi.fn(async () => (options.existingCart ? { id: 'existing' } : null)),
      create: vi.fn(async ({ data }: { data: Record<string, unknown> }) => ({
        id: 'cart-1',
        ...data,
      })),
      update: vi.fn(),
    },
  };
  const plans = {
    getPrice: vi.fn(async () => ({
      amountInCents: options.amount ?? 1000,
      discountInCents: options.discount ?? 100,
    })),
  };
  return {
    service: new CartService(prisma as unknown as PrismaClient, plans as unknown as PlanService),
    prisma,
  };
}

const baseInput = {
  discordUserId: '123456789012345678',
  username: 'cliente',
  guildId: '123456789012345678',
  planId: 'plan-1',
  periodDays: 30,
  applicationId: 'app-1',
  kind: 'RENEWAL' as const,
  expiresAt: new Date(Date.now() + 60_000),
};

describe('CartService', () => {
  it('cria carrinho com desconto e valor em centavos', async () => {
    const { service } = setup({ amount: 1500, discount: 200 });
    await expect(service.create(baseInput)).resolves.toMatchObject({ amountInCents: 1300 });
  });

  it('aplica mínimo operacional de 50 centavos', async () => {
    const { service } = setup({ amount: 40, discount: 30 });
    await expect(service.create(baseInput)).resolves.toMatchObject({ amountInCents: 50 });
  });

  it('recusa aplicação de outro proprietário', async () => {
    const { service } = setup({ applicationFound: false });
    await expect(service.create(baseInput)).rejects.toMatchObject({
      code: 'APPLICATION_FORBIDDEN',
    });
  });

  it('impede carrinho ou pagamento pendente duplicado', async () => {
    const { service } = setup({ existingCart: true });
    await expect(service.create(baseInput)).rejects.toMatchObject({ code: 'CART_ALREADY_OPEN' });
  });
});
