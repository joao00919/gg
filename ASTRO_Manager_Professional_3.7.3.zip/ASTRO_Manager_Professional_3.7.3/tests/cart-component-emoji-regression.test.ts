import { describe, expect, it } from 'vitest';
import type { BrandConfig } from '../src/config/brand.js';
import { cartPanel } from '../src/bot/panels/payment-panel.js';

const brand: BrandConfig = {
  name: 'ASTRO BOT',
  description: 'Manager',
  primaryColor: 0x00a8ff,
  secondaryColor: 0x2b2d31,
  emojis: {
    cart: '<:astro_cart:1527389252315385876>',
    dollar: '<:nome_errado:1525583610915323966>',
    settings: '<:nome_errado:1525583710000000000>',
    pix: '<:nome_errado:1525583610915323966>',
  },
};

const sessions = {
  buildCustomId: (_session: { id: string; version: number }, action: string) => `test:${action}`,
} as never;

describe('regressão de emoji inválido no carrinho', () => {
  it('serializa emojis personalizados apenas pelo ID nos componentes do carrinho', () => {
    const payload = cartPanel(
      brand,
      {
        id: 'cart',
        kind: 'NEW_APPLICATION',
        periodDays: 1,
        amountInCents: 100,
        application: null,
        plan: {
          id: 'plan',
          name: 'Vendas',
          slug: 'vendas',
          description: 'Bot de vendas',
          features: [],
          serverLimit: 1,
          userLimit: 1,
          active: true,
          displayOrder: 1,
          createdAt: new Date(),
          updatedAt: new Date(),
          deletedAt: null,
          storeDescription: 'Bot de Vendas & Ticket',
          previewUrl: null,
          prices: [
            {
              id: 'price',
              planId: 'plan',
              label: '1 dia',
              periodDays: 1,
              amountInCents: 100,
              discountInCents: 0,
              active: true,
              createdAt: new Date(),
              updatedAt: new Date(),
            },
          ],
        },
        addons: [],
        availableAddons: [
          {
            id: 'addon',
            name: 'Suporte',
            slug: 'suporte',
            description: 'Suporte',
            amountInCents: 400,
            active: true,
            displayOrder: 1,
            createdAt: new Date(),
            updatedAt: new Date(),
            deletedAt: null,
          },
        ],
      },
      { id: 'session', version: 1 },
      sessions,
    );

    const serialized = JSON.stringify(payload);
    expect(serialized).toContain('1525583610915323966');
    expect(serialized).toContain('1525583710000000000');
    expect(serialized).not.toContain('nome_errado');
    expect(serialized).toContain('1527389252315385876');
    expect(serialized).toContain('"id":"1525583610915323966"');
    expect(serialized).toContain('"id":"1525583710000000000"');
  });
});
