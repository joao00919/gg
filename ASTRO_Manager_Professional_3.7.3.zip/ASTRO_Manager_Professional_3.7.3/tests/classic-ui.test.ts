import { ComponentType } from 'discord.js';
import { describe, expect, it } from 'vitest';
import type { BrandConfig } from '../src/config/brand.js';
import type { SessionService } from '../src/services/sessions/session-service.js';
import { storePublicPanel } from '../src/bot/panels/public-panels.js';
import { cartPanel, pixPanel } from '../src/bot/panels/payment-panel.js';

const brand: BrandConfig = {
  name: 'Vision Applications',
  description: 'Manager',
  primaryColor: 0x00a8ff,
  secondaryColor: 0x2b2d31,
  emojis: {},
};
const sessions = {
  buildCustomId: (_session: unknown, action: string) => `vm.${action}`,
} as unknown as SessionService;
const session = { id: '00000000-0000-4000-8000-000000000000', version: 1 };
const plan = {
  id: '10000000-0000-4000-8000-000000000000',
  slug: 'vendas',
  name: 'Vendas',
  description: 'Automatize vendas.',
  storeDescription: 'Bot de Vendas',
  features: [],
  serverLimit: 1,
  userLimit: 1,
  active: true,
  displayOrder: 1,
  previewUrl: null,
  createdAt: new Date(),
  updatedAt: new Date(),
  deletedAt: null,
};
const price = {
  id: '20000000-0000-4000-8000-000000000000',
  planId: plan.id,
  label: 'Mensal',
  periodDays: 30,
  amountInCents: 899,
  discountInCents: 0,
  active: true,
  createdAt: new Date(),
  updatedAt: new Date(),
};

describe('interface tradicional do Discord', () => {
  it('painel público usa embed e apenas Action Rows tradicionais', () => {
    const payload = storePublicPanel(brand, [{ ...plan, prices: [price], addons: [] }]);
    expect(payload.embeds).toHaveLength(1);
    const componentTypes = payload.components?.map((component) =>
      'toJSON' in component ? component.toJSON().type : undefined,
    );
    expect(componentTypes?.every((type) => type === ComponentType.ActionRow)).toBe(true);
  });

  it('carrinho usa embed e componentes normais', () => {
    const payload = cartPanel(
      brand,
      {
        id: '30000000-0000-4000-8000-000000000000',
        kind: 'NEW_APPLICATION',
        periodDays: 30,
        amountInCents: 899,
        application: null,
        plan: { ...plan, prices: [price] },
        addons: [],
        availableAddons: [],
      },
      session,
      sessions,
    );
    expect(payload.embeds).toHaveLength(1);
    expect(JSON.stringify(payload)).not.toContain('IsComponentsV2');
  });

  it('PIX mantém somente copiar e cancelar', () => {
    const payload = pixPanel(brand, session, sessions);
    const serialized = JSON.stringify(
      payload.components?.map((row) => ('toJSON' in row ? row.toJSON() : row)),
    );
    expect(serialized).toContain('Copiar Código QR');
    expect(serialized).toContain('Cancelar');
    expect(serialized).not.toContain('Verificar pagamento');
  });
});
