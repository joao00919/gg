import { describe, expect, it } from 'vitest';
import { commandPayloads } from '../src/bot/commands/definitions.js';

interface CommandOptionView {
  name: string;
  required?: boolean;
  autocomplete?: boolean;
  options?: CommandOptionView[];
}

interface CommandView {
  name: string;
  options?: CommandOptionView[];
}

const commands = commandPayloads as unknown as readonly CommandView[];

function adminCommand(): CommandView {
  const admin = commands.find((command) => command.name === 'admin');
  if (!admin) throw new Error('Comando admin não encontrado.');
  return admin;
}

function group(name: string): CommandOptionView {
  const found = adminCommand().options?.find((option) => option.name === name);
  if (!found) throw new Error(`Grupo ${name} não encontrado.`);
  return found;
}

function subcommand(parent: CommandOptionView, name: string): CommandOptionView {
  const found = parent.options?.find((option) => option.name === name);
  if (!found) throw new Error(`Subcomando ${name} não encontrado.`);
  return found;
}

describe('facilidade dos comandos administrativos', () => {
  it('permite entregar bot por menção ou ID do Discord', () => {
    const deliver = subcommand(group('aplicacao'), 'entregar');
    const optionNames = deliver.options?.map((option) => option.name) ?? [];

    expect(optionNames).toEqual(
      expect.arrayContaining(['plano', 'dias', 'nome', 'cliente', 'usuario_id']),
    );
    expect(deliver.options?.find((option) => option.name === 'plano')).toMatchObject({
      required: true,
      autocomplete: true,
    });
  });

  it('permite aprovar pedido pelo pagamento, @cliente ou ID do usuário', () => {
    const paymentGroup = group('pagamento');
    const approve = subcommand(paymentGroup, 'aprovar');
    const optionNames = approve.options?.map((option) => option.name) ?? [];

    expect(optionNames).toEqual(expect.arrayContaining(['id', 'usuario', 'usuario_id']));
    expect(paymentGroup.options?.some((option) => option.name === 'sincronizar')).toBe(true);
  });
});
