import { describe, expect, it, vi } from 'vitest';

import {
  isTransientDatabaseError,
  retryDatabaseOperation,
} from '../src/database/retry.js';

describe('database retry', () => {
  it('repete uma operação após ETIMEDOUT e retorna o resultado', async () => {
    const callback = vi
      .fn<() => Promise<string>>()
      .mockRejectedValueOnce(Object.assign(new Error('connect ETIMEDOUT'), { code: 'ETIMEDOUT' }))
      .mockResolvedValue('ok');
    const onRetry = vi.fn();

    await expect(
      retryDatabaseOperation(callback, {
        attempts: 3,
        baseDelayMs: 1,
        maxDelayMs: 1,
        operation: 'teste',
        onRetry,
      }),
    ).resolves.toBe('ok');

    expect(callback).toHaveBeenCalledTimes(2);
    expect(onRetry).toHaveBeenCalledTimes(1);
  });

  it('não repete erros permanentes', async () => {
    const error = Object.assign(new Error('unique constraint'), { code: 'P2002' });
    const callback = vi.fn<() => Promise<void>>().mockRejectedValue(error);

    await expect(
      retryDatabaseOperation(callback, {
        attempts: 4,
        baseDelayMs: 1,
        maxDelayMs: 1,
        operation: 'teste',
      }),
    ).rejects.toBe(error);

    expect(callback).toHaveBeenCalledTimes(1);
  });

  it('reconhece timeout encapsulado como falha temporária', () => {
    const error = new Error('Prisma request failed', {
      cause: Object.assign(new Error('socket timed out'), { code: 'ETIMEDOUT' }),
    });
    expect(isTransientDatabaseError(error)).toBe(true);
  });
});
