import { randomUUID } from 'node:crypto';
import { describe, expect, it } from 'vitest';
import { decryptText, encryptText, signHmac, verifyHmac } from '../src/utils/crypto.js';
import { createCustomId, parseCustomId } from '../src/utils/custom-id.js';
import { redactText } from '../src/utils/redact.js';

const secret = 's'.repeat(32);

describe('segurança e custom IDs', () => {
  it('criptografa e descriptografa texto sensível', () => {
    const encrypted = encryptText('000201-codigo-pix', secret);
    expect(encrypted).not.toContain('000201-codigo-pix');
    expect(decryptText(encrypted, secret)).toBe('000201-codigo-pix');
  });

  it('rejeita descriptografia com chave incorreta', () => {
    const encrypted = encryptText('segredo', secret);
    expect(() => decryptText(encrypted, 'x'.repeat(32))).toThrow();
  });

  it('valida assinatura HMAC e rejeita conteúdo alterado', () => {
    const signature = signHmac('payload', secret);
    expect(verifyHmac('payload', signature, secret)).toBe(true);
    expect(verifyHmac('payload-alterado', signature, secret)).toBe(false);
  });

  it('gera custom ID persistente dentro do limite do Discord', () => {
    const id = createCustomId(
      { action: 'renew', sessionId: randomUUID(), version: 1, nonce: 'nonce123' },
      secret,
    );
    expect(id.length).toBeLessThanOrEqual(100);
    expect(parseCustomId(id, secret).action).toBe('renew');
  });

  it('rejeita custom ID adulterado', () => {
    const id = createCustomId(
      { action: 'renew', sessionId: randomUUID(), version: 1, nonce: 'nonce123' },
      secret,
    );
    expect(() => parseCustomId(id.replace('renew', 'delete'), secret)).toThrow('adulterado');
  });

  it('rejeita versão inválida', () => {
    const id = createCustomId(
      { action: 'renew', sessionId: randomUUID(), version: 0, nonce: 'nonce123' },
      secret,
    );
    expect(() => parseCustomId(id, secret)).toThrow('Versão');
  });

  it('remove tokens, senhas e código PIX de logs', () => {
    const text =
      'authorization: Bearer abc token=supersecreto password=123 000201' + 'A'.repeat(60);
    const redacted = redactText(text);
    expect(redacted).not.toContain('supersecreto');
    expect(redacted).not.toContain('000201');
    expect(redacted.match(/\[REDACTED\]/g)?.length).toBeGreaterThanOrEqual(3);
  });
});
