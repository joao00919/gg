import { describe, expect, it } from 'vitest';
import type { BaseMessageOptions } from 'discord.js';
import type { BrandConfig } from '../src/config/brand.js';
import { paymentFinalPanel } from '../src/bot/panels/payment-panel.js';
import { commandsPublicPanel, storePublicPanel } from '../src/bot/panels/public-panels.js';

const brand: BrandConfig = {
  name: 'Astro Applications',
  description: 'Manager',
  primaryColor: 0x5865f2,
  secondaryColor: 0x2b2d31,
  emojis: {
    app: '<:robot:1525692202288676927>',
    dollar: '<:dollar:1525692051969020024>',
    paymentCancelled: '<:payment_cancelled:1527388353044156546>',
  },
};

const basePlan = {
  features: [],
  serverLimit: 1,
  userLimit: 1,
  active: true,
  previewUrl: null,
  createdAt: new Date(),
  updatedAt: new Date(),
  deletedAt: null,
  prices: [],
  addons: [],
};

function serializeItem(item: unknown): unknown {
  if (typeof item === 'object' && item !== null && 'toJSON' in item) {
    return (item as { toJSON(): unknown }).toJSON();
  }
  return item;
}

function serialize(payload: BaseMessageOptions): string {
  return JSON.stringify({
    content: payload.content,
    embeds: payload.embeds?.map(serializeItem),
    components: payload.components?.map(serializeItem),
  });
}

describe('painéis solicitados da Astro Applications', () => {
  it('usa o título e os dois produtos definidos para aquisição', () => {
    const payload = storePublicPanel(brand, [
      {
        ...basePlan,
        id: '10000000-0000-4000-8000-000000000000',
        slug: 'vendas',
        name: 'Vendas',
        description: 'Automatize todo o processo de vendas, do catálogo à entrega.',
        storeDescription: 'Bot de Vendas',
        displayOrder: 1,
      },
      {
        ...basePlan,
        id: '20000000-0000-4000-8000-000000000000',
        slug: 'ticket',
        name: 'Ticket',
        description: 'Gerencie o suporte ao cliente com IA e automação avançada.',
        storeDescription: 'Bot de Ticket',
        displayOrder: 2,
      },
    ]);
    const output = serialize(payload);

    expect(output).toContain('Painel de Aquisição - Astro Applications');
    expect(output).toContain('Bot de Vendas');
    expect(output).toContain('Bot de Ticket');
    expect(output).toContain('1525692202288676927');
  });

  it('mantém a central de comandos com os quatro comandos públicos', () => {
    const output = serialize(commandsPublicPanel(brand));
    expect(output).toContain('Central de Comandos - Astro Applications');
    for (const command of ['/apps', '/renovar', '/restore', '/imagem_url']) {
      expect(output).toContain(command);
    }
  });

  it('usa o emoji próprio no pagamento cancelado', () => {
    expect(paymentFinalPanel(brand, 'CANCELLED').content).toContain(
      '<:payment_cancelled:1527388353044156546>',
    );
  });
});
