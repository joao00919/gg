import { describe, expect, it } from 'vitest';
import type { BrandConfig } from '../src/config/brand.js';
import type { SessionService } from '../src/services/sessions/session-service.js';
import { pixPanel } from '../src/bot/panels/payment-panel.js';

const brand: BrandConfig = {
  name: 'Vision',
  description: 'Manager',
  primaryColor: 0x5865f2,
  secondaryColor: 0x2b2d31,
  emojis: {},
};

const sessions = {
  buildCustomId: (_session: unknown, action: string) => `vm.${action}`,
} as unknown as SessionService;

describe('painel PIX', () => {
  it('possui exatamente os botões Copiar Código QR e Cancelar', () => {
    const payload = pixPanel(
      brand,
      { id: '00000000-0000-4000-8000-000000000000', version: 1 },
      sessions,
    );
    const serialized = JSON.stringify({
      content: payload.content,
      embeds: payload.embeds?.map((item) => ('toJSON' in item ? item.toJSON() : item)),
      components: payload.components?.map((item) => ('toJSON' in item ? item.toJSON() : item)),
    });
    expect(serialized).toContain('Copiar Código QR');
    expect(serialized).toContain('Cancelar');
    expect(serialized).not.toMatch(/Verificar pagamento|Já paguei|Atualizar status/i);
    const buttonCount = (serialized.match(/"type":2/g) ?? []).length;
    expect(buttonCount).toBe(2);
  });

  it('apresenta QR Code como attachment direto', () => {
    const payload = pixPanel(
      brand,
      { id: '00000000-0000-4000-8000-000000000000', version: 1 },
      sessions,
    );
    const serialized = JSON.stringify({
      content: payload.content,
      components: payload.components?.map((item) => ('toJSON' in item ? item.toJSON() : item)),
    });
    expect(serialized).toContain('Leia as informações abaixo');
  });
});
