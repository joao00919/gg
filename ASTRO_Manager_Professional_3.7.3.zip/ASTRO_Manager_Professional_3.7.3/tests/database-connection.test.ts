import { describe, expect, it } from 'vitest';

import { parsePostgresConnection } from '../src/database/connection.js';

describe('parsePostgresConnection', () => {
  it('separa o schema Prisma da URL entregue ao driver pg', () => {
    const result = parsePostgresConnection(
      'postgresql://vision:secret@example.com:5432/database?sslmode=require&schema=vision_manager',
    );

    expect(result.schema).toBe('vision_manager');
    expect(result.connectionString).toContain('sslmode=verify-full');
    expect(result.connectionString).not.toContain('schema=');
  });

  it('usa public quando o schema não foi especificado', () => {
    const result = parsePostgresConnection('postgresql://vision:secret@localhost:5432/database');
    expect(result.schema).toBe('public');
  });
});
