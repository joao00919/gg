import { describe, expect, it } from 'vitest';
import type { BrandConfig } from '../src/config/brand.js';
import { removeUnavailableComponentEmojis } from '../src/bot/client/manager-client.js';
import { normalizeDisplayEmoji, parseCustomEmoji } from '../src/bot/components/helpers.js';

function brand(): BrandConfig {
  return {
    name: 'ASTRO BOT',
    description: 'Manager',
    primaryColor: 0x00a8ff,
    secondaryColor: 0x2b2d31,
    emojis: {
      loading: '<a:loading:1527386782776164392>',
      cartOpened: '<:cart:1527388353044156546>',
      dollar: '<:dollar:1525583610915323966>',
      settings: '<:settings:1525583710000000000>',
      start: '▶️',
    },
  };
}

describe('segurança de emojis em componentes', () => {
  it('aceita emoji com nome numérico sem enviar nome inválido ao componente', () => {
    expect(parseCustomEmoji('<:1243275863827546224:1527389252315385876>')).toEqual({
      animated: false,
      id: '1527389252315385876',
    });
    expect(parseCustomEmoji('<a:1389945080172904539:1527386782776164392>')).toEqual({
      animated: true,
      id: '1527386782776164392',
    });
  });


  it('recusa símbolos de texto que o Discord não aceita como emoji de componente', () => {
    expect(parseCustomEmoji('✎')).toBeUndefined();
    expect(parseCustomEmoji('↻')).toBeUndefined();
    expect(parseCustomEmoji('📝')).toEqual({ name: '📝' });
    expect(parseCustomEmoji('⚙️')).toEqual({ name: '⚙️' });
  });

  it('normaliza nome numérico para menção textual válida', () => {
    expect(
      normalizeDisplayEmoji(
        '<:1243275863827546224:1527389252315385876>',
        '🛒',
        'astro_cart',
      ),
    ).toBe('<:astro_cart:1527389252315385876>');
  });

  it('remove custom emoji inacessível de botão/select e preserva emoji textual', () => {
    const config = brand();
    const removed = removeUnavailableComponentEmojis(
      config,
      new Set(['1525583610915323966']),
    );
    expect(config.emojis.dollar).toBe('<:dollar:1525583610915323966>');
    expect(config.emojis.settings).toBeUndefined();
    expect(config.emojis.loading).toBe('<a:loading:1527386782776164392>');
    expect(config.emojis.cartOpened).toBe('<:cart:1527388353044156546>');
    expect(removed).toEqual(['settings']);
  });
});
