import type { PrismaClient } from '@prisma/client';
import { describe, expect, it, vi } from 'vitest';
import { TransferService } from '../src/services/transfers/transfer-service.js';
import type { AuditService } from '../src/services/audit/audit-service.js';

function setup(
  options: {
    source?: boolean;
    pending?: boolean;
    recent?: boolean;
    conflict?: boolean;
  } = {},
) {
  const tx = {
    transfer: { create: vi.fn(async () => ({ id: 'transfer-1', status: 'COMPLETED' })) },
    application: {
      updateMany: vi.fn(async () => ({ count: options.conflict ? 0 : 1 })),
    },
    interactionSession: { updateMany: vi.fn(async () => ({ count: 2 })) },
  };
  const prisma = {
    application: {
      findFirst: vi.fn(async () =>
        options.source === false
          ? null
          : {
              id: 'app-1',
              name: 'ASTRO BOT',
              ownerId: 'from-db',
              payments: options.pending ? [{ id: 'pay-1' }] : [],
            },
      ),
    },
    transfer: { findFirst: vi.fn(async () => (options.recent ? { id: 'recent' } : null)) },
    user: { upsert: vi.fn(async () => ({ id: 'to-db' })) },
    $transaction: vi.fn(async (callback: (value: typeof tx) => Promise<unknown>) => callback(tx)),
  };
  const audit = { record: vi.fn(async () => undefined) };
  return {
    service: new TransferService(
      prisma as unknown as PrismaClient,
      audit as unknown as AuditService,
    ),
    tx,
    audit,
  };
}

describe('TransferService', () => {
  it('recusa transferência para o mesmo usuário', async () => {
    const { service } = setup();
    await expect(service.transfer('app-1', '123', '123')).rejects.toMatchObject({
      code: 'TRANSFER_SAME_USER',
    });
  });

  it('recusa transferência com pagamento pendente', async () => {
    const { service } = setup({ pending: true });
    await expect(service.transfer('app-1', '123', '456')).rejects.toMatchObject({
      code: 'TRANSFER_PAYMENT_PENDING',
    });
  });

  it('aplica intervalo mínimo entre transferências', async () => {
    const { service } = setup({ recent: true });
    await expect(service.transfer('app-1', '123', '456')).rejects.toMatchObject({
      code: 'TRANSFER_COOLDOWN',
    });
  });

  it('valida a transferência antes de mostrar a confirmação', async () => {
    const { service } = setup();
    await expect(service.assertCanTransfer('app-1', '123', '456')).resolves.toEqual({
      applicationName: 'ASTRO BOT',
    });
  });

  it('impede duas transferências concorrentes', async () => {
    const { service, audit } = setup({ conflict: true });
    await expect(service.transfer('app-1', '123', '456')).rejects.toMatchObject({
      code: 'TRANSFER_CONFLICT',
    });
    expect(audit.record).not.toHaveBeenCalled();
  });

  it('troca proprietário, revoga sessões e audita em transação', async () => {
    const { service, tx, audit } = setup();
    await expect(service.transfer('app-1', '123', '456')).resolves.toMatchObject({
      status: 'COMPLETED',
    });
    expect(tx.application.updateMany).toHaveBeenCalledWith(
      expect.objectContaining({
        where: expect.objectContaining({ ownerId: 'from-db' }),
        data: { ownerId: 'to-db' },
      }),
    );
    expect(tx.interactionSession.updateMany).toHaveBeenCalledWith(
      expect.objectContaining({ data: { status: 'REVOKED' } }),
    );
    expect(audit.record).toHaveBeenCalled();
  });
});
