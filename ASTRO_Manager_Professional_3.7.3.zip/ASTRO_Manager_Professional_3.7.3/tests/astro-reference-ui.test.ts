import { describe, expect, it } from 'vitest';
import type { Addon, Plan, PlanPrice } from '@prisma/client';
import type { BrandConfig } from '../src/config/brand.js';
import type { SessionService } from '../src/services/sessions/session-service.js';
import { applicationPanel } from '../src/bot/panels/apps-panel.js';
import { cartPanel, paymentProcessingPanel, pixPanel } from '../src/bot/panels/payment-panel.js';

const brand: BrandConfig = {
  name: 'ASTRO BOT',
  description: 'Manager',
  primaryColor: 0x00a8ff,
  secondaryColor: 0x2b2d31,
  emojis: {
    app: '<:robot:1525583719157596170>',
    dollar: '<:dollar:1525583610915323966>',
    start: '<:play:1525583703395401871>',
    stop: '<:power:1525583707576991856>',
  },
};
const sessions = {
  buildCustomId: (_session: unknown, action: string) => `vm.${action}`,
} as unknown as SessionService;
const session = { id: '00000000-0000-4000-8000-000000000000', version: 1 };

const plan: Plan = {
  id: '10000000-0000-4000-8000-000000000000',
  slug: 'vendas',
  name: 'Vendas',
  description: 'Automatize vendas.',
  storeDescription: 'Bot de Vendas & Ticket',
  features: [],
  serverLimit: 1,
  userLimit: 1,
  active: true,
  displayOrder: 1,
  previewUrl: null,
  createdAt: new Date(),
  updatedAt: new Date(),
  deletedAt: null,
};
const prices: PlanPrice[] = [
  [1, 100, '1 dia'],
  [7, 399, '7 dias'],
  [15, 599, '15 dias'],
  [30, 899, '30 dias'],
  [365, 7999, '365 dias'],
].map(([periodDays, amountInCents, label], index) => ({
  id: `20000000-0000-4000-8000-00000000000${index}`,
  planId: plan.id,
  label: String(label),
  periodDays: Number(periodDays),
  amountInCents: Number(amountInCents),
  discountInCents: 0,
  active: true,
  createdAt: new Date(),
  updatedAt: new Date(),
}));
const addon: Addon = {
  id: '30000000-0000-4000-8000-000000000000',
  slug: 'suporte-prioritario',
  name: 'Suporte Prioritário',
  description: 'Prioridade no suporte.',
  amountInCents: 400,
  active: true,
  displayOrder: 1,
  createdAt: new Date(),
  updatedAt: new Date(),
  deletedAt: null,
};

function serialize(payload: { content?: unknown; embeds?: readonly unknown[]; components?: readonly unknown[] }): string {
  return JSON.stringify({
    content: payload.content,
    embeds: payload.embeds?.map((item) =>
      typeof item === 'object' && item !== null && 'toJSON' in item
        ? (item as { toJSON(): unknown }).toJSON()
        : item,
    ),
    components: payload.components?.map((item) =>
      typeof item === 'object' && item !== null && 'toJSON' in item
        ? (item as { toJSON(): unknown }).toJSON()
        : item,
    ),
  });
}

describe('edição ASTRO baseada no fluxo de referência', () => {
  it('oferece um dia por exatamente R$ 1,00 e os períodos de referência', () => {
    const payload = cartPanel(
      brand,
      {
        id: '40000000-0000-4000-8000-000000000000',
        kind: 'NEW_APPLICATION',
        periodDays: 30,
        amountInCents: 899,
        application: null,
        plan: { ...plan, prices },
        addons: [],
        availableAddons: [addon],
      },
      session,
      sessions,
    );
    const output = serialize(payload);
    expect(output).toContain('Adquirir 1 dia');
    expect(output).toContain('R$ 1,00');
    expect(output).toContain('Adquirir 7 dias');
    expect(output).toContain('Adquirir 15 dias');
    expect(output).toContain('Adquirir 30 dias');
    expect(output).toContain('Adquirir 365 dias');
  });

  it('mantém os textos e controles principais do carrinho', () => {
    const payload = cartPanel(
      brand,
      {
        id: '40000000-0000-4000-8000-000000000000',
        kind: 'NEW_APPLICATION',
        periodDays: 30,
        amountInCents: 899,
        application: null,
        plan: { ...plan, prices },
        addons: [],
        availableAddons: [addon],
      },
      session,
      sessions,
    );
    const output = serialize(payload);
    expect(output).toContain('Realizar Compra');
    expect(output).toContain('Selecione o plano desejado');
    expect(output).toContain('Produto');
    expect(output).toContain('Plano');
    expect(output).toContain('Valor Total:');
    expect(output).toContain('Finalizar Compra');
    expect(output).toContain('Cancelar Compra');
    expect(output).toContain('[ADICIONAL] Suporte Prioritário');
  });

  it('usa mensagem comum durante o processamento e somente dois botões no PIX', () => {
    expect(paymentProcessingPanel(brand).embeds).toEqual([]);
    const output = serialize(pixPanel(brand, session, sessions));
    expect(output).toContain('Leia as informações abaixo para concluir o pagamento');
    expect(output).toContain('Copiar Código QR');
    expect(output).toContain('Cancelar');
    expect((output.match(/"type":2/g) ?? []).length).toBe(2);
    expect(output).not.toMatch(/Verificar pagamento|Já paguei|Atualizar status/i);
  });

  it('expõe no /apps as mesmas categorias funcionais do painel de referência', () => {
    const application = {
      id: '50000000-0000-4000-8000-000000000000',
      ownerId: '60000000-0000-4000-8000-000000000000',
      planId: plan.id,
      name: 'ASTRO FORN',
      discordApplicationId: '123456789012345678',
      bio: null,
      botTokenEncrypted: null,
      trustedUserId: null,
      status: 'ONLINE' as const,
      autoRenew: false,
      autoRenewPeriodDays: 30,
      hostingProvider: 'mock',
      hostingExternalId: null,
      linkedGuildId: null,
      version: '1.0.0',
      lastRestartAt: null,
      deletedAt: null,
      createdAt: new Date(),
      updatedAt: new Date(),
      owner: { discordId: '123456789012345678' },
      plan: { ...plan, prices, addons: [{ planId: plan.id, addonId: addon.id, addon }] },
      license: null,
      instances: [],
      addons: [],
      payments: [],
    };
    const output = serialize(applicationPanel(brand, application, session, sessions, 'Nagato'));
    for (const text of [
      'Gerenciamento - Vendas',
      'Iniciar',
      'Reiniciar',
      'Parar',
      'Gerenciar renovação',
      'Alterar nome do BOT',
      'Alterar BIO do BOT',
      'Alterar token do BOT',
      'Alterar pessoa de confiança',
      'Gerenciar equipe',
      'Gerenciar servidores',
      'Transferir posse',
      'Deletar aplicação permanente',
      'Adquira um adicional para sua aplicação',
    ]) expect(output).toContain(text);
  });
});
