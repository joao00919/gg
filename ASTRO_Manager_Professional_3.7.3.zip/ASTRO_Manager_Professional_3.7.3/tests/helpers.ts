import { parseEnv, type Env } from '../src/config/env.js';
import type { Logger } from '../src/config/logger.js';

export function createTestEnv(
  overrides: Partial<Record<keyof NodeJS.ProcessEnv, string>> = {},
): Env {
  return parseEnv({
    NODE_ENV: 'test',
    MANAGER_BOT_TOKEN: 'test-bot-token',
    MANAGER_CLIENT_ID: '123456789012345678',
    MANAGER_GUILD_ID: '123456789012345678',
    DATABASE_URL: 'postgresql://postgres:postgres@localhost:5432/test?schema=vision_manager',
    INTERNAL_API_KEY: 'i'.repeat(32),
    ENCRYPTION_KEY: 'e'.repeat(32),
    CUSTOM_ID_SECRET: 'c'.repeat(32),
    OWNER_IDS: '123456789012345678',
    ADMIN_ROLE_IDS: '',
    PAYMENT_PROVIDER: 'mock',
    ...overrides,
  });
}

export const silentLogger = {
  debug: () => undefined,
  info: () => undefined,
  warn: () => undefined,
  error: () => undefined,
  fatal: () => undefined,
} as unknown as Logger;
