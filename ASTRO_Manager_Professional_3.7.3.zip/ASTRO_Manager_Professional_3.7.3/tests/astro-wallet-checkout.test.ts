import { describe, expect, it } from 'vitest';
import type { BrandConfig } from '../src/config/brand.js';
import type { SessionService } from '../src/services/sessions/session-service.js';
import { cartCancellationPanel } from '../src/bot/panels/action-panels.js';
import { applicationPanel } from '../src/bot/panels/apps-panel.js';
import { cartPanel } from '../src/bot/panels/payment-panel.js';
import { renewalManagementPanel } from '../src/bot/panels/renewal-panel.js';

const brand: BrandConfig = {
  name: 'Astro Applications',
  description: 'Manager',
  primaryColor: 0x00a8ff,
  secondaryColor: 0x2b2d31,
  emojis: {
    checkout: '<:1242906048994742393:1527441682545770567>',
    cart: '<:cart:1525692023540154520>',
    dollar: '<:dollar:1525692051969020024>',
    wallet: '<:wallet:1525692260879175791>',
    power: '<:power:1525692188229373972>',
    plus: '<:plus:1525692182701281321>',
    rocket: '<:rocket:1525692203622600774>',
  },
};

const sessions = {
  buildCustomId: (_session: unknown, action: string) => `astro.${action}`,
} as unknown as SessionService;
const session = { id: '00000000-0000-4000-8000-000000000000', version: 1 };

interface SerializedButton {
  label?: string;
  emoji?: { id?: string; name?: string; animated?: boolean };
}

interface SerializedRow {
  components: SerializedButton[];
}

function rows(payload: { components?: readonly unknown[] }): SerializedRow[] {
  return (payload.components ?? []).map((component) =>
    (component as { toJSON(): SerializedRow }).toJSON(),
  );
}

const plan = {
  id: '10000000-0000-4000-8000-000000000000',
  slug: 'vendas',
  name: 'Vendas',
  description: 'Automatize vendas.',
  storeDescription: 'Bot de Vendas',
  features: [],
  serverLimit: 1,
  userLimit: 1,
  active: true,
  displayOrder: 1,
  previewUrl: null,
  createdAt: new Date(),
  updatedAt: new Date(),
  deletedAt: null,
  prices: [
    {
      id: '20000000-0000-4000-8000-000000000000',
      planId: '10000000-0000-4000-8000-000000000000',
      label: '30 dias',
      periodDays: 30,
      amountInCents: 899,
      discountInCents: 0,
      active: true,
      createdAt: new Date(),
      updatedAt: new Date(),
    },
  ],
};

describe('ASTRO WALLET e acabamento do carrinho 3.6', () => {
  it('usa a seta solicitada apenas em Finalizar Compra e deixa Cancelar Compra sem emoji', () => {
    const payload = cartPanel(
      brand,
      {
        id: 'cart',
        kind: 'NEW_APPLICATION',
        periodDays: 30,
        amountInCents: 899,
        application: null,
        plan,
        addons: [],
        availableAddons: [],
      },
      session,
      sessions,
    );

    const components = rows(payload);
    const buttons = components[components.length - 1]?.components ?? [];
    expect(buttons).toHaveLength(2);

    const finalizeButton = buttons[0];
    const cancelButton = buttons[1];
    if (!finalizeButton || !cancelButton) {
      throw new Error('Os botões esperados do carrinho não foram gerados.');
    }

    expect(finalizeButton.label).toBe('Finalizar Compra');
    expect(finalizeButton.emoji).toEqual({
      id: '1527441682545770567',
      animated: false,
    });
    expect(cancelButton.label).toBe('Cancelar Compra');
    expect(cancelButton.emoji).toBeUndefined();
  });

  it('mantém os dois botões da confirmação de cancelamento sem emoji', () => {
    const payload = cartCancellationPanel(brand, 'astro.confirm', 'astro.back');
    const buttons = rows(payload)[0]?.components ?? [];
    expect(buttons.map((item) => item.label)).toEqual([
      'Voltar',
      'Cancelar Compra',
    ]);
    expect(buttons.every((item) => item.emoji === undefined)).toBe(true);
  });

  it('exibe saldo e renovação automática pela ASTRO WALLET', () => {
    const application = {
      id: '30000000-0000-4000-8000-000000000000',
      ownerId: '40000000-0000-4000-8000-000000000000',
      planId: plan.id,
      name: 'ASTRO FORN',
      discordApplicationId: '123456789012345678',
      bio: null,
      botTokenEncrypted: null,
      trustedUserId: null,
      status: 'ONLINE',
      autoRenew: true,
      autoRenewPeriodDays: 30,
      hostingProvider: 'mock',
      hostingExternalId: null,
      linkedGuildId: null,
      version: '1.0.0',
      lastRestartAt: null,
      deletedAt: null,
      createdAt: new Date(),
      updatedAt: new Date(),
      plan,
      license: {
        id: '50000000-0000-4000-8000-000000000000',
        applicationId: '30000000-0000-4000-8000-000000000000',
        planId: plan.id,
        keyPrefix: 'ASTRO',
        keyHash: 'hash',
        status: 'ACTIVE',
        activatedAt: new Date(),
        expiresAt: new Date('2026-08-13T12:00:00Z'),
        lastValidatedAt: null,
        validationCount: 0,
        serverLimit: 1,
        autoRenew: true,
        createdAt: new Date(),
        updatedAt: new Date(),
      },
    } as never;

    const serialized = JSON.stringify(
      renewalManagementPanel(brand, application, 1, session, sessions),
    );
    expect(serialized).toContain('ASTRO WALLET');
    expect(serialized).toContain('Valor disponível');
    expect(serialized).toContain('Renovação automática');
    expect(serialized).toContain('Renovar 30d');
    expect(serialized).toContain('1525692260879175791');
  });

  it('gera link OAuth2 para adicionar a aplicação ao servidor', () => {
    const application = {
      id: '30000000-0000-4000-8000-000000000000',
      ownerId: '40000000-0000-4000-8000-000000000000',
      planId: plan.id,
      name: 'ASTRO FORN',
      discordApplicationId: '123456789012345678',
      bio: null,
      botTokenEncrypted: null,
      trustedUserId: null,
      status: 'ONLINE',
      autoRenew: false,
      autoRenewPeriodDays: 30,
      hostingProvider: 'mock',
      hostingExternalId: null,
      linkedGuildId: null,
      version: '1.0.0',
      lastRestartAt: null,
      deletedAt: null,
      createdAt: new Date(),
      updatedAt: new Date(),
      owner: { discordId: '999999999999999999' },
      plan: { ...plan, addons: [] },
      license: null,
      instances: [],
      addons: [],
      payments: [],
    } as never;

    const serialized = JSON.stringify(
      applicationPanel(brand, application, session, sessions, 'Nagato'),
    );
    expect(serialized).toContain('Adicionar aplicação');
    expect(serialized).toContain('client_id=123456789012345678');
    expect(serialized).toContain('scope=bot%20applications.commands');
  });
});
