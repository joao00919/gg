import type { PrismaClient } from '@prisma/client';
import { describe, expect, it, vi } from 'vitest';
import { SessionService } from '../src/services/sessions/session-service.js';
import { createCustomId } from '../src/utils/custom-id.js';

const secret = 'c'.repeat(32);

function createPrisma() {
  const records = new Map<string, Record<string, unknown>>();
  const prisma = {
    user: {
      upsert: vi.fn(async ({ where }: { where: { discordId: string } }) => ({
        id: 'user-db-id',
        discordId: where.discordId,
      })),
    },
    interactionSession: {
      create: vi.fn(async ({ data }: { data: Record<string, unknown> }) => {
        const record = {
          ...data,
          version: 1,
          status: 'ACTIVE',
          consumedAt: null,
          createdAt: new Date(),
          updatedAt: new Date(),
        };
        records.set(String(data.id), record);
        return record;
      }),
      findUnique: vi.fn(async ({ where }: { where: { id: string } }) => {
        const record = records.get(where.id);
        return record
          ? { ...record, user: { id: 'user-db-id', discordId: '123456789012345678' } }
          : null;
      }),
      updateMany: vi.fn(async () => ({ count: 1 })),
    },
  };
  return { prisma: prisma as unknown as PrismaClient, records, raw: prisma };
}

describe('InteractionSession persistente', () => {
  it('cria e valida uma sessão do proprietário', async () => {
    const { prisma } = createPrisma();
    const service = new SessionService(prisma, secret);
    const session = await service.create(
      '123456789012345678',
      'APPLICATION',
      'Application',
      'app-1',
    );
    const customId = service.buildCustomId(session, 'renew');
    const result = await service.validate(customId, '123456789012345678');
    expect(result).toMatchObject({ action: 'renew', entityId: 'app-1', kind: 'APPLICATION' });
  });

  it('recusa clique de outro usuário', async () => {
    const { prisma } = createPrisma();
    const service = new SessionService(prisma, secret);
    const session = await service.create('123456789012345678', 'APPLICATION');
    await expect(
      service.validate(service.buildCustomId(session, 'renew'), '999999999999999999'),
    ).rejects.toMatchObject({ code: 'INTERACTION_FORBIDDEN' });
  });

  it('recusa nonce diferente mesmo com assinatura válida', async () => {
    const { prisma } = createPrisma();
    const service = new SessionService(prisma, secret);
    const session = await service.create('123456789012345678', 'APPLICATION');
    const forged = createCustomId(
      { action: 'renew', sessionId: session.id, version: 1, nonce: 'outroNonce' },
      secret,
    );
    await expect(service.validate(forged, '123456789012345678')).rejects.toMatchObject({
      code: 'INTERACTION_NONCE_INVALID',
    });
  });

  it('recusa sessão expirada', async () => {
    const { prisma, records } = createPrisma();
    const service = new SessionService(prisma, secret);
    const session = await service.create('123456789012345678', 'APPLICATION');
    const record = records.get(session.id);
    if (record) record.expiresAt = new Date(Date.now() - 1);
    await expect(
      service.validate(service.buildCustomId(session, 'renew'), '123456789012345678'),
    ).rejects.toMatchObject({ code: 'INTERACTION_EXPIRED' });
  });

  it('consome a sessão uma única vez conforme update atômico', async () => {
    const { prisma, raw } = createPrisma();
    raw.interactionSession.updateMany
      .mockResolvedValueOnce({ count: 1 })
      .mockResolvedValueOnce({ count: 0 });
    const service = new SessionService(prisma, secret);
    await expect(service.consume('session-id')).resolves.toBe(true);
    await expect(service.consume('session-id')).resolves.toBe(false);
  });
});
