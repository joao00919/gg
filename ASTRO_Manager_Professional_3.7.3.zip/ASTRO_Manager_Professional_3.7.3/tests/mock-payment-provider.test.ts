import { describe, expect, it } from 'vitest';
import { MockPaymentProvider } from '../src/integrations/payment/mock-provider.js';

function input() {
  return {
    amountInCents: 1490,
    currency: 'BRL',
    idempotencyKey: 'test-key',
    expiresAt: new Date(Date.now() + 60_000),
    description: 'Teste',
  };
}

describe('MockPaymentProvider e QR Code', () => {
  it('cria cobrança PIX pendente com PNG de alta resolução', async () => {
    const provider = new MockPaymentProvider();
    const pix = await provider.createPixPayment(input());
    expect(pix.status).toBe('PENDING');
    expect(pix.qrCodeText).toContain('000201');
    expect(pix.qrCodeImage.subarray(0, 8).toString('hex')).toBe('89504e470d0a1a0a');
    expect(pix.qrCodeImage.length).toBeGreaterThan(1000);
  });

  it('consulta pagamento criado', async () => {
    const provider = new MockPaymentProvider();
    const pix = await provider.createPixPayment(input());
    expect((await provider.getPayment(pix.externalPaymentId)).amountInCents).toBe(1490);
  });

  it('simula aprovação automática', async () => {
    const provider = new MockPaymentProvider();
    const pix = await provider.createPixPayment(input());
    provider.setStatus(pix.externalPaymentId, 'APPROVED');
    const result = await provider.getPayment(pix.externalPaymentId);
    expect(result.status).toBe('APPROVED');
    expect(result.approvedAt).toBeInstanceOf(Date);
  });

  it('cancela cobrança', async () => {
    const provider = new MockPaymentProvider();
    const pix = await provider.createPixPayment(input());
    const result = await provider.cancelPayment(pix.externalPaymentId);
    expect(result).toMatchObject({ status: 'CANCELLED', supported: true });
  });

  it('valida webhook com ID externo', async () => {
    const provider = new MockPaymentProvider();
    const result = await provider.validateWebhook({
      rawBody: Buffer.from('{"externalPaymentId":"mock_1"}'),
      headers: {},
      payload: { externalPaymentId: 'mock_1' },
    });
    expect(result.valid).toBe(true);
    expect(result.externalPaymentId).toBe('mock_1');
  });

  it('rejeita webhook sem ID externo', async () => {
    const provider = new MockPaymentProvider();
    const result = await provider.validateWebhook({
      rawBody: Buffer.from('{}'),
      headers: {},
      payload: {},
    });
    expect(result.valid).toBe(false);
  });
});
