import { describe, expect, it } from 'vitest';
import { commandPayloads } from '../src/bot/commands/definitions.js';

describe('registro de slash commands', () => {
  it('não possui nomes duplicados', () => {
    const names = commandPayloads.map((command) => command.name);
    expect(new Set(names).size).toBe(names.length);
  });

  it('inclui os comandos obrigatórios do cliente e administração', () => {
    expect(commandPayloads.map((command) => command.name)).toEqual(
      expect.arrayContaining(['apps', 'app', 'licenca', 'pagamento', 'admin']),
    );
  });

  it('gera payload JSON aceito pelo builder sem valores undefined', () => {
    expect(() => JSON.stringify(commandPayloads)).not.toThrow();
    expect(JSON.stringify(commandPayloads)).not.toContain('undefined');
  });
});
