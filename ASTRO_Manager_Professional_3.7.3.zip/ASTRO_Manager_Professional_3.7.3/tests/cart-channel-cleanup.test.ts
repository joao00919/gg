import { describe, expect, it, vi } from 'vitest';
import type { Client } from 'discord.js';
import type { Logger } from '../src/config/logger.js';
import { deleteCartChannel } from '../src/bot/flows/cart-channel-cleanup.js';

const logger = {
  warn: vi.fn(),
} as unknown as Logger;

describe('encerramento do canal do carrinho', () => {
  it('exclui o tópico privado quando a compra é cancelada', async () => {
    const remove = vi.fn().mockResolvedValue(undefined);
    const client = {
      channels: {
        fetch: vi.fn().mockResolvedValue({
          isThread: () => true,
          delete: remove,
        }),
      },
    } as unknown as Client;

    const deleted = await deleteCartChannel(client, '123', logger, 'Compra cancelada', 0);

    expect(deleted).toBe(true);
    expect(remove).toHaveBeenCalledWith('Compra cancelada');
  });

  it('bloqueia e arquiva o tópico quando a exclusão for negada', async () => {
    const lock = vi.fn().mockResolvedValue(undefined);
    const archive = vi.fn().mockResolvedValue(undefined);
    const client = {
      channels: {
        fetch: vi.fn().mockResolvedValue({
          isThread: () => true,
          delete: vi.fn().mockRejectedValue(new Error('Sem permissão')),
          setLocked: lock,
          setArchived: archive,
        }),
      },
    } as unknown as Client;

    const deleted = await deleteCartChannel(client, '123', logger, 'Compra cancelada', 0);

    expect(deleted).toBe(false);
    expect(lock).toHaveBeenCalledWith(true, 'Compra cancelada');
    expect(archive).toHaveBeenCalledWith(true, 'Compra cancelada');
  });
});
