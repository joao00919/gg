import { describe, expect, it } from 'vitest';
import { confirmationPanel, transferSelectPanel } from '../src/bot/panels/action-panels.js';
import { applicationPanel } from '../src/bot/panels/apps-panel.js';
import { createTestEnv } from './helpers.js';
import { buildBrand } from '../src/config/brand.js';

const brand = buildBrand(createTestEnv());
const sessions = {
  buildCustomId: () => 'vm.test.session.1.nonce.signature',
};

const application = {
  id: 'app-1',
  name: 'ASTRO BOT',
  bio: null,
  status: 'ONLINE',
  lastRestartAt: new Date(),
  updatedAt: new Date(),
  discordApplicationId: null,
  owner: { discordId: '123456789012345678', wallet: null },
  planId: 'plan-1',
  plan: { name: 'Mensal', prices: [], addons: [] },
  license: null,
  instances: [],
  addons: [],
  payments: [],
} as never;

describe('limpeza de conteúdo ao trocar painéis', () => {
  it('o painel principal remove a mensagem de carregamento anterior', () => {
    const panel = applicationPanel(
      brand,
      application,
      { id: 'session', version: 1 },
      sessions as never,
      'cliente',
    );
    expect(panel.content).toBeNull();
  });

  it('a seleção e a confirmação de transferência removem conteúdo antigo', () => {
    const select = transferSelectPanel(brand, { id: 'session', version: 1 }, sessions as never);
    const confirmation = confirmationPanel(
      brand,
      'Confirmar transferência',
      'Descrição',
      'confirm',
      'cancel',
    );
    expect(select.content).toBeNull();
    expect(confirmation.content).toBeNull();
  });
});
