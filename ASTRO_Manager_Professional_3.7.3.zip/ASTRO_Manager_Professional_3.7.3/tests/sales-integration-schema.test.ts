import { describe, expect, it } from 'vitest';
import { salesPurchaseSchema } from '../src/integrations/sales-bot/sales-schema.js';

describe('integração com Bot de Vendas', () => {
  it('aceita payload simples por slug e ativa automaticamente', () => {
    const parsed = salesPurchaseSchema.parse({
      idempotencyKey: 'order_12345678',
      buyerDiscordId: '123456789012345678',
      buyerUsername: 'cliente',
      applicationName: 'ASTRO BOT',
      planSlug: 'vendas',
      periodDays: 30,
      paymentExternalId: 'pix_123',
      amountInCents: 899,
    });
    expect(parsed.planSlug).toBe('vendas');
    expect(parsed.autoActivate).toBe(true);
    expect(parsed.currency).toBe('BRL');
  });

  it('mantém compatibilidade com o payload estruturado', () => {
    const parsed = salesPurchaseSchema.parse({
      idempotencyKey: 'order_87654321',
      buyer: { discordId: '123456789012345678', username: 'cliente' },
      product: { name: 'ASTRO BOT' },
      plan: { slug: 'vendas' },
      periodDays: 30,
      amountInCents: 899,
      payment: { externalId: 'pix_456', status: 'APPROVED', provider: 'promisse' },
      initialConfig: { guildId: '123456789012345678' },
    });
    expect(parsed.buyerDiscordId).toBe('123456789012345678');
    expect(parsed.paymentExternalId).toBe('pix_456');
  });

  it('recusa compra sem plano', () => {
    expect(() =>
      salesPurchaseSchema.parse({
        idempotencyKey: 'order_00000000',
        buyerDiscordId: '123456789012345678',
        applicationName: 'BOT',
        periodDays: 30,
        paymentExternalId: 'pix_789',
        amountInCents: 899,
      }),
    ).toThrow();
  });
});
