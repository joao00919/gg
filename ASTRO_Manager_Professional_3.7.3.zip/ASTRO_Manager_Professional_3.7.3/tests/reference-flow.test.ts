import { describe, expect, it } from 'vitest';
import type { BrandConfig } from '../src/config/brand.js';
import type { SessionService } from '../src/services/sessions/session-service.js';
import { commandBuilders } from '../src/bot/commands/definitions.js';
import { applicationPanel } from '../src/bot/panels/apps-panel.js';
import { cartPanel } from '../src/bot/panels/payment-panel.js';
import { commandsPublicPanel, storePublicPanel } from '../src/bot/panels/public-panels.js';

const brand: BrandConfig = {
  name: 'Vision Applications',
  description: 'Manager',
  primaryColor: 0x00a8ff,
  secondaryColor: 0x2b2d31,
  dashboardUrl: 'https://example.com/dashboard',
  previewBotsUrl: 'https://example.com/preview',
  storeBannerUrl: 'https://example.com/store.png',
  commandsBannerUrl: 'https://example.com/commands.png',
  emojis: {},
};
const sessions = {
  buildCustomId: (_session: unknown, action: string) => `vm.${action}`,
} as unknown as SessionService;
const session = { id: '00000000-0000-4000-8000-000000000000', version: 1 };

function serializeMessage(payload: { content?: unknown; embeds?: readonly unknown[]; components?: readonly unknown[] }): string {
  return JSON.stringify({
    content: payload.content,
    embeds: payload.embeds?.map((item) =>
      typeof item === 'object' && item !== null && 'toJSON' in item
        ? (item as { toJSON(): unknown }).toJSON()
        : item,
    ),
    components: payload.components?.map((item) =>
      typeof item === 'object' && item !== null && 'toJSON' in item
        ? (item as { toJSON(): unknown }).toJSON()
        : item,
    ),
  });
}

const plan = {
  id: '10000000-0000-4000-8000-000000000000',
  slug: 'vendas',
  name: 'Vendas',
  description: 'Automatize vendas.',
  storeDescription: 'Bot de Vendas & Ticket',
  features: [],
  serverLimit: 1,
  userLimit: 1,
  active: true,
  displayOrder: 1,
  previewUrl: null,
  createdAt: new Date(),
  updatedAt: new Date(),
  deletedAt: null,
};
const monthly = {
  id: '20000000-0000-4000-8000-000000000000',
  planId: plan.id,
  label: 'Mensal',
  periodDays: 30,
  amountInCents: 899,
  discountInCents: 0,
  active: true,
  createdAt: new Date(),
  updatedAt: new Date(),
};
const addon = {
  id: '30000000-0000-4000-8000-000000000000',
  slug: 'suporte',
  name: 'Suporte Prioritário',
  description: 'Prioridade no suporte.',
  amountInCents: 400,
  active: true,
  displayOrder: 1,
  createdAt: new Date(),
  updatedAt: new Date(),
  deletedAt: null,
};

describe('fluxo visual de referência', () => {
  it('registra os comandos principais com autocomplete de aplicação', () => {
    const json = commandBuilders.map((builder) => builder.toJSON());
    const names = json.map((command) => command.name);
    expect(names).toEqual(expect.arrayContaining(['apps', 'renovar', 'restore', 'imagem_url', 'painel']));
    for (const name of ['apps', 'renovar', 'restore']) {
      const command = json.find((item) => item.name === name);
      expect(command?.options?.[0]).toMatchObject({ name: 'app', autocomplete: true, required: true });
    }
  });

  it('painel público contém central, loja, seleção e links configuráveis', () => {
    const store = serializeMessage(
      storePublicPanel(brand, [{ ...plan, prices: [monthly], addons: [{ addon }] }]),
    );
    expect(store).toContain('Central de Compras');
    expect(store).toContain('Escolha o bot que deseja adquirir');
    expect(store).toContain('Preview Bots');
    const commands = serializeMessage(commandsPublicPanel(brand));
    expect(commands).toContain('Central de Comandos');
    expect(commands).toContain('Dashboard OAuth2');
  });

  it('painel de aplicação segue o gerenciamento com iniciar, reiniciar, parar e adicionais', () => {
    const application = {
      id: '40000000-0000-4000-8000-000000000000',
      ownerId: '50000000-0000-4000-8000-000000000000',
      planId: plan.id,
      name: 'ASTRO FORN',
      discordApplicationId: '123456789012345678',
      bio: null,
      botTokenEncrypted: null,
      trustedUserId: null,
      status: 'ONLINE' as const,
      autoRenew: false,
      autoRenewPeriodDays: 30,
      hostingProvider: 'mock',
      hostingExternalId: null,
      linkedGuildId: null,
      version: '1.0.0',
      lastRestartAt: null,
      deletedAt: null,
      createdAt: new Date(),
      updatedAt: new Date(),
      owner: { discordId: '123456789012345678' },
      plan: { ...plan, prices: [monthly], addons: [{ planId: plan.id, addonId: addon.id, addon }] },
      license: {
        id: '60000000-0000-4000-8000-000000000000',
        applicationId: '40000000-0000-4000-8000-000000000000',
        planId: plan.id,
        keyPrefix: 'VIS-',
        keyHash: 'hash',
        status: 'ACTIVE' as const,
        activatedAt: new Date(),
        expiresAt: new Date(Date.now() + 86400000),
        lastValidatedAt: null,
        validationCount: 0,
        serverLimit: 1,
        autoRenew: false,
        createdAt: new Date(),
        updatedAt: new Date(),
      },
      instances: [],
      addons: [],
      payments: [],
    };
    const serialized = serializeMessage(
      applicationPanel(brand, application, session, sessions, 'nagatomta'),
    );
    expect(serialized).toContain('Gerenciamento - Vendas');
    expect(serialized).toContain('Iniciar');
    expect(serialized).toContain('Reiniciar');
    expect(serialized).toContain('Parar');
    expect(serialized).toContain('Alterar nome do BOT');
    expect(serialized).toContain('Adquira um adicional para sua aplicação');
  });

  it('carrinho contém seleção de período, adicionais e apenas finalizar/cancelar', () => {
    const payload = cartPanel(
      brand,
      {
        id: '70000000-0000-4000-8000-000000000000',
        kind: 'NEW_APPLICATION',
        periodDays: 30,
        amountInCents: 1299,
        application: null,
        plan: { ...plan, prices: [monthly] },
        addons: [{ addonId: addon.id, amountInCents: 400, addon }],
        availableAddons: [addon],
      },
      session,
      sessions,
    );
    const serialized = serializeMessage(payload);
    expect(serialized).toContain('Realizar Compra');
    expect(serialized).toContain('Adquirir 30 dias');
    expect(serialized).toContain('Suporte Prioritário');
    expect(serialized).toContain('Finalizar Compra');
    expect(serialized).toContain('Cancelar Compra');
    expect(serialized).not.toContain('Verificar pagamento');
  });
});
