import type { PrismaClient } from '@prisma/client';
import { describe, expect, it, vi } from 'vitest';
import { LicenseExpirationJob } from '../src/jobs/license-expiration-job.js';
import type { HostingProvider } from '../src/types/hosting.js';
import type { NotificationService } from '../src/services/notifications/notification-service.js';
import { createTestEnv, silentLogger } from './helpers.js';

function setup(expiresAt: Date, status: 'ACTIVE' | 'EXPIRING' = 'ACTIVE') {
  const prisma = {
    license: {
      findMany: vi.fn(async () => [
        {
          id: 'license-1',
          applicationId: 'app-1',
          status,
          expiresAt,
          application: { name: 'Minha aplicação', owner: { discordId: '123456789012345678' } },
        },
      ]),
      update: vi.fn(async () => ({})),
    },
    application: { update: vi.fn(async () => ({})) },
    auditLog: { create: vi.fn(async () => ({})) },
    $transaction: vi.fn(async (operations: Promise<unknown>[]) => Promise.all(operations)),
  };
  const hosting = { suspendApplication: vi.fn(async () => undefined) };
  const notifications = { sendDiscord: vi.fn(async () => undefined) };
  const job = new LicenseExpirationJob(
    prisma as unknown as PrismaClient,
    hosting as unknown as HostingProvider,
    notifications as unknown as NotificationService,
    createTestEnv(),
    silentLogger,
  );
  return { job, prisma, hosting, notifications };
}

describe('suspensão automática', () => {
  it('expira licença, suspende aplicação e notifica', async () => {
    const { job, prisma, hosting, notifications } = setup(new Date('2026-07-01T00:00:00.000Z'));
    await job.tick(new Date('2026-07-15T00:00:00.000Z'));
    expect(prisma.license.update).toHaveBeenCalledWith(
      expect.objectContaining({ data: { status: 'EXPIRED' } }),
    );
    expect(hosting.suspendApplication).toHaveBeenCalledWith('app-1');
    expect(notifications.sendDiscord).toHaveBeenCalled();
  });

  it('marca como EXPIRING quando faltam até sete dias', async () => {
    const { job, prisma, hosting } = setup(new Date('2026-07-20T00:00:00.000Z'));
    await job.tick(new Date('2026-07-15T00:00:00.000Z'));
    expect(prisma.license.update).toHaveBeenCalledWith(
      expect.objectContaining({ data: { status: 'EXPIRING' } }),
    );
    expect(hosting.suspendApplication).not.toHaveBeenCalled();
  });
});
