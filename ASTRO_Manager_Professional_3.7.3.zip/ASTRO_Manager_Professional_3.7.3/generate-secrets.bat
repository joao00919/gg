@echo off
cd /d "%~dp0"
node -e "const c=require('crypto'); for(const k of ['INTERNAL_API_KEY','ENCRYPTION_KEY','CUSTOM_ID_SECRET']) console.log(k+'='+c.randomBytes(48).toString('base64url'))"
echo.
echo Copie as tres linhas para o arquivo .env.
pause
