# Correção 3.7.3

Esta versão corrige a interrupção do Manager causada por falha temporária de conexão com o PostgreSQL durante `prisma.plan.upsert()`.

## Alterações

- conexão inicial com PostgreSQL protegida por novas tentativas automáticas;
- cadastro dos planos padrão protegido por reconexão e repetição;
- atraso exponencial entre as tentativas para não sobrecarregar o banco;
- reconhecimento de `ETIMEDOUT`, erros Prisma `P1001`, `P1002`, `P2024` e códigos PostgreSQL transitórios;
- timeout de conexão e limite do pool configuráveis pelo `.env`;
- `keepAlive` habilitado no pool PostgreSQL;
- `sslmode=require` convertido para `sslmode=verify-full` em tempo de execução, eliminando o aviso de migração do driver sem reduzir a segurança;
- compatibilidade mantida com arquivos `.env` antigos por meio de valores padrão.

## Novas variáveis opcionais

```env
DATABASE_CONNECT_TIMEOUT_MS=15000
DATABASE_POOL_MAX=10
DATABASE_STARTUP_RETRIES=12
DATABASE_RETRY_BASE_MS=2000
DATABASE_RETRY_MAX_MS=15000
```

Não é obrigatório adicioná-las ao `.env` existente.
