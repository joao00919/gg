@echo off
setlocal
cd /d "%~dp0"
if not exist .env copy .env.example .env >nul
echo.
echo Gerando segredos. Copie as linhas para o .env se ainda estiverem vazias:
echo.
node -e "const c=require('crypto'); for(const k of ['INTERNAL_API_KEY','ENCRYPTION_KEY','CUSTOM_ID_SECRET']) console.log(k+'='+c.randomBytes(48).toString('base64url'))"
echo.
echo Lembrete: DATABASE_URL deve terminar com schema=vision_manager.
echo Nao compartilhe token, chave PIX ou URL do banco.
echo.
pause
notepad .env
