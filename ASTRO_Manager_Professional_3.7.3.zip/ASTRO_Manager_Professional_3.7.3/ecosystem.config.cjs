module.exports = {
  apps: [
    {
      name: 'vision-manager',
      script: 'dist/src/index.js',
      instances: 1,
      autorestart: true,
      max_memory_restart: '512M',
      env: { NODE_ENV: 'production' },
    },
  ],
};
