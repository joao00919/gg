@echo off
setlocal
cd /d "%~dp0"
echo Instalando dependencias...
call npm install --registry=https://registry.npmjs.org/
if errorlevel 1 goto :erro

echo Gerando Prisma Client...
call npm run prisma:generate
if errorlevel 1 goto :erro

echo Compilando projeto...
call npm run build
if errorlevel 1 goto :erro

echo.
echo Atualizacao 3.3 concluida. Para ligar, execute: npm run dev
pause
exit /b 0

:erro
echo.
echo A atualizacao falhou. Revise o erro acima.
pause
exit /b 1
