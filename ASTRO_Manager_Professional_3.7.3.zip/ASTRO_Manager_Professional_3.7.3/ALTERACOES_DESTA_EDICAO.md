# Alterações — ASTRO Reference UI Edition

- Carrinho clássico refeito para acompanhar o fluxo visual fornecido.
- Select de período responde imediatamente, eliminando o aviso “não respondeu a tempo”.
- Preços: 1 dia R$ 1,00; 7 dias R$ 3,99; 15 dias R$ 5,99; 30 dias R$ 8,99; 365 dias R$ 79,99.
- Adicionais de R$ 4,00: Suporte Prioritário, Remover Anúncio e QRCode Personalizável.
- Mensagem de processamento comum, QR Code como attachment e apenas dois botões no PIX.
- `/apps` com Iniciar, Reiniciar, Parar e select de gerenciamento detalhado.
- Nome, BIO, token criptografado, pessoa de confiança, equipe, servidores, transferência, licença e exclusão.
- API idempotente para o Bot de Vendas liberar aplicação/licença automaticamente.
- Emojis válidos fornecidos foram adicionados ao `.env.example`, com fallback quando inacessíveis.
- Identidade visual padrão alterada para ASTRO BOT; não são incluídos logotipo, banner ou marca de terceiros.

## Correção 3.1.0 — abertura de carrinho

- O tópico privado recebe uma mensagem de carregamento imediatamente após ser criado.
- A mensagem de carregamento é editada para o painel do carrinho; o tópico não fica mais vazio.
- Validação explícita de `Enviar mensagens em tópicos`, `Criar tópicos privados` e `Gerenciar tópicos`.
- Se a primeira mensagem falhar, o tópico incompleto é removido e o erro aparece de forma objetiva.
- Emoji animado de carregamento configurado por padrão.
- Emoji de carrinho aberto configurado por padrão.
- Período inicial alterado para 1 dia por R$ 1,00.
- Interações de select continuam sendo confirmadas antes das consultas ao PostgreSQL.


## Versão 3.5.0 — operação comercial simplificada

- Painel público alterado para **Painel de Aquisição - Astro Applications**.
- Produtos principais exibidos: Bot de Vendas e Bot de Ticket.
- Central de comandos reorganizada com `/apps`, `/renovar`, `/restore` e `/imagem_url`.
- Emojis personalizados de robô, dinheiro e pagamento cancelado.
- Cancelamento agora exclui o tópico/canal do carrinho após atualizar o status.
- Contingência para bloquear e arquivar tópicos que o Discord não permita excluir.
- `/admin aplicacao entregar` aceita cliente por menção ou ID.
- `/admin pagamento aprovar` aceita pagamento, menção ou ID do cliente.
- `/admin pagamento sincronizar` verifica o status diretamente no provedor.
- Autocomplete de planos e respostas administrativas mais objetivas.
- 66 testes automatizados aprovados.

## Versão 3.6.0 — ASTRO WALLET e gerenciamento completo

- Carteira integrada ASTRO WALLET com saldo e movimentações.
- Renovação automática transacional pela carteira.
- Administração de saldo por menção ou ID.
- Convite OAuth2 funcional em Gerenciar servidores.
- Emoji de seta no botão Finalizar Compra e cancelamento sem emojis nos botões.
- Novos emojis personalizados em toda a área de gerenciamento.
- Correções no cancelamento e na exclusão do tópico do carrinho.

## Versão 3.6.1 — Correção de compilação TypeScript

- Corrigido `TS2532` no teste do carrinho.
- Validação explícita dos botões antes do acesso por índice.
- Prisma, build, lint e 71 testes validados.
