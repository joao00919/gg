import { createHmac } from 'node:crypto';

export interface ApprovedPurchase {
  orderId: string;
  buyerDiscordId: string;
  buyerUsername?: string;
  applicationName: string;
  discordApplicationId?: string;
  linkedGuildId?: string;
  planSlug: 'vendas' | 'ticket' | 'roblox' | 'divulgacao' | 'verificacao';
  periodDays: 1 | 7 | 15 | 30 | 365;
  paymentExternalId: string;
  amountInCents: number;
}

export async function releaseApprovedPurchase(input: ApprovedPurchase): Promise<unknown> {
  const managerUrl = process.env.MANAGER_API_URL;
  const apiKey = process.env.MANAGER_INTERNAL_API_KEY;
  const signatureSecret = process.env.MANAGER_SALES_API_KEY ?? apiKey;
  if (!managerUrl || !apiKey || !signatureSecret) {
    throw new Error('Configure MANAGER_API_URL, MANAGER_INTERNAL_API_KEY e MANAGER_SALES_API_KEY.');
  }

  const payload = {
    idempotencyKey: `order_${input.orderId}`,
    buyerDiscordId: input.buyerDiscordId,
    buyerUsername: input.buyerUsername,
    applicationName: input.applicationName,
    discordApplicationId: input.discordApplicationId,
    linkedGuildId: input.linkedGuildId,
    planSlug: input.planSlug,
    periodDays: input.periodDays,
    paymentExternalId: input.paymentExternalId,
    amountInCents: input.amountInCents,
    currency: 'BRL',
    paymentProvider: 'promisse',
    autoActivate: true,
  };
  const rawBody = JSON.stringify(payload);
  const timestamp = String(Date.now());
  const signature = createHmac('sha256', signatureSecret)
    .update(`${timestamp}.${rawBody}`)
    .digest('base64url');

  const response = await fetch(`${managerUrl}/internal/v1/purchases`, {
    method: 'POST',
    headers: {
      'content-type': 'application/json',
      'x-api-key': apiKey,
      'x-timestamp': timestamp,
      'x-signature': signature,
    },
    body: rawBody,
  });
  if (!response.ok) throw new Error(`Manager recusou a entrega: ${response.status} ${await response.text()}`);
  return response.json();
}
