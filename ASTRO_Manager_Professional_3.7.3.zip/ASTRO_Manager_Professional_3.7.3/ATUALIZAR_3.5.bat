@echo off
chcp 65001 >nul
title ASTRO Manager 3.5 - Atualização

echo Instalando dependencias...
call npm install
if errorlevel 1 goto erro

echo Gerando cliente Prisma...
call npm run prisma:generate
if errorlevel 1 goto erro

echo Validando e compilando...
call npm run prisma:validate
if errorlevel 1 goto erro
call npm run build
if errorlevel 1 goto erro

echo Registrando comandos no servidor de desenvolvimento...
call npm run commands:dev
if errorlevel 1 goto erro

echo.
echo Atualizacao concluida. Reinicie o processo do bot.
pause
exit /b 0

:erro
echo.
echo A atualizacao falhou. Confira a mensagem acima.
pause
exit /b 1
